<?php
Route::group(['middleware'=>'auth'], function(){
    Route::get('/profile/komparasi', 'Profile\ProfileController@komparasi');
    Route::get('/profile/chart', 'Profile\ProfileController@chart');
});

?>