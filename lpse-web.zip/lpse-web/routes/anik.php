<?php
Route::group(['middleware'=>'auth'], function(){
	Route::get('/beranda', 'Beranda\BerandaController@index');
	Route::get('/peserta', 'Peserta\PesertaController@index');
	Route::get('/notifikasi', 'Notifikasi\NotifikasiController@index');
	Route::get('/notifikasi/setting', 'Notifikasi\NotifikasiController@setting');
	Route::post('/Notifikasi/sendNotifikasi', 'Notifikasi\NotifikasiController@sendNotification');
	//kao udah ada data diganti post
	Route::get('/notifikasi/editSetting{id}', 'Notifikasi\NotifikasiController@edit');
	Route::put('/notifikasi/editSetting{id}','Notifikasi\NotifikasiController@update');
	Route::delete ('/Notifikasi/setting{id_tender}', 'Notifikasi\NotifikasiController@destroy');

});
?>