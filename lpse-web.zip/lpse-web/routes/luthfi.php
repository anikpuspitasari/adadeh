<?php

Route::group(['middleware'=>'auth'], function(){
    Route::get('/profile', 'Profile\ProfileController@index');
    Route::get('/analisa', 'Analisa\AnalisaController@index');
    Route::get('/analisa/pencarian', 'Analisa\AnalisaController@pencarian');
    Route::get('/pencarian', 'Beranda\BerandaController@pencarian');
	Route::get('/peserta/detailPeserta', 'Peserta\PesertaController@detailPeserta');
    Route::get('/peserta/get', 'Peserta\PesertaController@coba'); // Ini buat coba dummy
});
?>
