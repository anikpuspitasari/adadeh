<?php
Route::group(['middleware'=>'auth'], function(){
	Route::get('/beranda', 'Beranda\BerandaController@index');
    Route::get('/beranda/pencarian','Beranda\BerandaController@pencarian');
});

?>