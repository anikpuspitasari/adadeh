<?php

namespace App\Http\Controllers\Analisa;

use Illuminate\Http\Request;
use GuzzleHttp\Client;
use App\Http\Controllers\Controller;

class AnalisaController extends Controller
{
  //isi controller
  	public function index(Request $request)
  	{
	  	$filter = $this->getFilter($request);
	    $ret['filter'] = $filter; 

	    return view('app.analisa.index', $ret);
  	}

    public function pencarian(Request $request)
    {
    	$filter = $this->getFilter($request);
	    $ret['filter'] = $filter;


	    //-------------jumlah tender---------------------
	    $params = [
	            "query" => [
	                "bool" => [
	                    "must" => [
	                        [
	                            "range" => [
	                                "tanggal_pembuatan" => [
	                                    "gte" => $filter->milisRange->gte,
	                                    "lte" => $filter->milisRange->lte
	                                ]
	                            ]
	                        ]
	                      //   [
	                      //   	"terms" => [
			                    //     "kualifikasi_usaha" => [
			                    //     	"Perusahaan Non Kecil"
			                    //     ]
			                    // ]
	                      //   ]
	                    ]
	                ]
	            ],
	            "aggs" => [
	                "tender_per_bulan" => [
	                    "date_histogram" => [
	                        "field" => "tanggal_pembuatan",
	                        "calendar_interval" => "day",
	                        "format" => "dd/MM/yyyy",
	                        "time_zone" => "+07:00"
	                    ]   
	                ]
	            ],
	            "track_total_hits"=> true,
	            "size"=> 0
	        ];

	        if($filter->daterangeDiff >= 5) {
	            $params['aggs']['tender_per_bulan']['date_histogram']['calendar_interval'] = "month";
	            $params['aggs']['tender_per_bulan']['date_histogram']['format'] = "MMM yy";
	        }

	        if($filter->tender) {
	            $query_string = [
	                "query_string" => [
	                    "default_field" => "search.nama_paket",
	                    "query" => '"'.$filter->tender.'"'
	                ]
	            ];

	            array_push($params['query']['bool']['must'], $query_string);
	        }

	        // if ($filter->kualifikasiUsaha==null) {
         //    $newTerms =
         //        [
         //            "terms" => [
         //                "kualifikasi_usaha" => $filter->kualifikasiUsaha
         //            ]

         //        ];
         //    array_push($params["query"]["bool"]["must"], $newTerms);
        	// }


	        

	        $data = $this->guzzleRequest('/lpse_project_pengumuman/_search', $params);
	        
	        $hasil = $data->aggregations->tender_per_bulan->buckets;
	        $chart = [];
	        for ($i=0; $i < count($hasil); $i++){
	        $tgl = $data->aggregations->tender_per_bulan->buckets[$i]->key_as_string;
	        $nilai = $data->aggregations->tender_per_bulan->buckets[$i]->doc_count;
	        array_push($chart, [$tgl, $nilai]);
	        }

	        $ret['chart'] = $chart;

	        //-------------tender teratas---------------------
	        $params = [
	            "size"=> 0,
				  "query"=> [
				    "bool"=> [
				      "must"=> [
				        [
				          "range"=> [
				            "tanggal_pembuatan"=> [
				                "gte" => $filter->milisRange->gte,
	                            "lte" => $filter->milisRange->lte
				            ]
				          ]
				        ]
				        // [
				        //   "match"=> [
				        //     "status_pemenang_akhir"=> "menang"
				        //   ]
				        // ]
				        // [
	           //              "terms" => [
			         //            "kualifikasi_usaha" => ["Perusahaan Kecil"]
			         //        ]
	           //          ]
				      ]
				    ]
				  ],
				  "aggs"=> [
				    "pemenang"=> [
				      "terms"=> [
				        "field"=> "nilai_hps",
				        "size"=> 5,
				        "order"=> [
				          "_key"=> "desc"
				        ]
				      ],
				      "aggs"=> [
				        "detail"=> [
				          "top_hits"=> [
				            "_source"=> [
				              "includes"=> [
				                "nama_paket",
				                "instansi",
				                "nilai_hps"
				              ]
				            ],
				            "size"=> 1
				          ]
				        ]
				      ]
				    ]
				  ]
	        ];


	        if($filter->daterangeDiff >= 5) {
	            $params['aggs']['tender_per_bulan']['date_histogram']['calendar_interval'] = "month";
	            $params['aggs']['tender_per_bulan']['date_histogram']['format'] = "MMM yy";
	        }

	        if($filter->tender) {
	            $query_string = [
	                "query_string" => [
	                    "default_field" => "search.nama_paket",
	                    "query" => '"'.$filter->tender.'"'
	                ]
	            ];

	            array_push($params['query']['bool']['must'], $query_string);
	        }
	        // if ($filter->kualifikasiUsaha!=null) {
         //    $newTerms =
         //        [
         //            "terms" => [
         //                "kualifikasi_usaha" => $filter->kualifikasiUsaha
         //            ]

         //        ];
         //    array_push($params["query"]["bool"]["must"], $newTerms);
        	// }

	        $data = $this->guzzleRequest('/lpse_project_pengumuman/_search', $params);
	        dd($data);

	        $tender_teratas = [];

	        $hasil_tender_teratas = $data->aggregations->pemenang->buckets;

	        $tabel_tender_teratas = [];
	        for ($i = 0; $i < count($hasil_tender_teratas); $i++) {
	        $nama_paket_tender = $hasil_tender_teratas[$i]->detail->hits->hits[0]->_source->nama_paket;

	        $instansi_tender = $hasil_tender_teratas[$i]->detail->hits->hits[0]->_source->instansi;
	        $hps = $hasil_tender_teratas[$i]->detail->hits->hits[0]->_source->nilai_hps;

	        array_push($tabel_tender_teratas, [$nama_paket_tender, $instansi_tender, $hps]);

	        }
	        $ret['tender_teratas'] = $tabel_tender_teratas;


	        //-------------kompetitor-------------------
	        $params = [
	            "query" => [
	                "bool" => [
	                    "must" => [
	                        [
	                            "range" => [
	                                "tanggal_pembuatan" => [
	                                    "gte" => $filter->milisRange->gte,
	                                    "lte" => $filter->milisRange->lte
	                                ]
	                            ]
	                        ],
	                         [
	                            "match" => [
	                                "status_pemenang_akhir" => "menang" 
	                            ] 
	                        ]
	                      //   [
	                      //   	"terms" => [
			                    //     "kualifikasi_usaha" => ["Perusahaan Kecil"]
			                    // ]
	                      //   ]
	                    ]
	                ]
	            ],
	            "aggs" => [
	                "pemenang" => [
	                    "terms" => [
	                        "field" => "nama_peserta", 
	                        "size" => 5
	                    ] 
	                ] 
	            ], 
	            // "aggs" => 
		           //  [
		           //      "tender_per_bulan" => [
		           //          "date_histogram" => [
		           //             "field" => "tanggal_pembuatan",
		           //              "calendar_interval" => "day",
		           //              "format" => "dd/MM/yyyy",
		           //              "time_zone" => "+07:00"
		           //          ]   
	            //     	]
	            // 	],
	            "track_total_hits"=> true,
	            "size"=> 0
	        ];

	        if($filter->daterangeDiff >= 5) {
	            $params['aggs']['tender_per_bulan']['date_histogram']['calendar_interval'] = "month";
	            $params['aggs']['tender_per_bulan']['date_histogram']['format'] = "MMM yy";
	        }

	        if($filter->tender) {
	            $query_string = [
	                "query_string" => [
	                    "default_field" => "search.nama_paket",
	                    "query" => '"'.$filter->tender.'"'
	                ]
	            ];

	            array_push($params['query']['bool']['must'], $query_string);
	        }

	        // if ($filter->kualifikasiUsaha!=null) {
         //    $newTerms =
         //        [
         //            "terms" => [
         //                "kualifikasi_usaha" => $filter->kualifikasiUsaha
         //            ]

         //        ];
         //    array_push($params["query"]["bool"]["must"], $newTerms);
        	// }



	        $data = $this->guzzleRequest('/lpse_project_hasilevaluasi/_search', $params);

	        $hasil = $data->aggregations->pemenang->buckets;

	        $tabel = [];
	        for ($i=0; $i < count($hasil); $i++){
	        $key = $hasil[$i]->key;
	        $doc_count = $hasil[$i]->doc_count;
	        array_push($tabel, [$key, $doc_count]);
	        }

	        $ret['tabel'] = $tabel;
    		
	        //-------------manual input filter-------------------
	        // $params = [
	        //     "query" => [
	        //         "bool" => [
	        //             "must" => [
	        //                 [
	        //                     "range" => [
	        //                         "tanggal_pembuatan" => [
	        //                             "gte" => $filter->milisRange->gte,
	        //                             "lte" => $filter->milisRange->lte
	        //                         ]
	        //                     ]
	        //                 ],
	        //                  [
	        //                     "match" => [
	        //                         "status_pemenang_akhir" => "menang" 
	        //                     ] 
	        //                 ] 
	        //             ]
	        //         ]
	        //     ],
	        //     "aggs" => [
	        //         "pemenang" => [
	        //             "terms" => [
	        //                 "field" => "nama_peserta", 
	        //                 "size" => 5
	        //             ] 
	        //         ] 
	        //     ], 
	        //     "track_total_hits"=> true,
	        //     "size"=> 0
	        // ];

	        // if($filter->daterangeDiff >= 5) {
	        //     $params['aggs']['tender_per_bulan']['date_histogram']['calendar_interval'] = "month";
	        //     $params['aggs']['tender_per_bulan']['date_histogram']['format'] = "MMM yy";
	        // }

	        // if($filter->tender) {
	        //     $query_string = [
	        //         "query_string" => [
	        //             "default_field" => "search.nama_paket",
	        //             "query" => '"'.$filter->tender.'"'
	        //         ]
	        //     ];

	        //     array_push($params['query']['bool']['must'], $query_string);
	        // }

	        // if ($filter->kualifikasiUsaha) {
         //    $newTerms =
         //        [
         //            "terms" => [
         //                "kualifikasi_usaha" => $filter->kualifikasiUsaha
         //            ]

         //        ];
         //    array_push($params["query"]["bool"]["must"], $newTerms);
        	// }

	        // $data = $this->guzzleRequest('/lpse_project_hasilevaluasi/_search', $params);

	        // $hasil = $data->aggregations->pemenang->buckets;

	        // $tabel = [];
	        // for ($i=0; $i < count($hasil); $i++){
	        // $key = $hasil[$i]->key;
	        // $doc_count = $hasil[$i]->doc_count;
	        // array_push($tabel, [$key, $doc_count]);
	        // }

	        // $ret['tabel'] = $tabel;

    		return view('app.analisa.pencarian', $ret);
    }

    //---------memfilter waktu--------------
    static function getAllMonth($range) {
        $dates = explode(" - ", $range);

        $startDate = explode("/", $dates[0]);
        $startDate = $startDate[2].'-'.$startDate[1].'-'.$startDate[0];

        $endDate = explode("/", $dates[1]);
        $endDate = $endDate[2].'-'.$endDate[1].'-'.$endDate[0];

        $months = [];

        while (strtotime($startDate) <= strtotime($endDate)) {
            $months[] = date('M Y', strtotime($startDate));

            $startDate = date('d M Y', strtotime($startDate.
                '+ 1 month'));
        }

        return $months;
    }


    static function getAllDate($range) {
        $dates = explode(" - ", $range);

        $startDate = explode("/", $dates[0]);
        $startDate = $startDate[2].'-'.$startDate[1].'-'.$startDate[0];

        $endDate = explode("/", $dates[1]);
        $endDate = $endDate[2].'-'.$endDate[1].'-'.$endDate[0];

        $months = [];

        while (strtotime($startDate) <= strtotime($endDate)) {
            $months[] = date('d/m/Y', strtotime($startDate));

            $startDate = date('d M Y', strtotime($startDate.
                '+ 1 day'));
        }

        return $months;
    }
}
