<?php

namespace App\Http\Controllers\Profile;

use Illuminate\Http\Request;
use GuzzleHttp\Client;
use App\Http\Controllers\Controller;

class ProfileController extends Controller
{
    public function index(Request $request)
    {
        $filter = $this->getFilter($request);
        $ret['filter'] = $filter;
        $namaperusahaan = "PT. Telekomunikasi Indonesia, Tbk.";

        if ($filter->namaPerusahaan) {
            $namaperusahaan = $filter->namaPerusahaan;
        }

        //-------------menampilkan biodata/profil tender--------------
        $params= [
            "query" => [
                "match_phrase" => [
                    "nama" => $namaperusahaan
                ]
            ]
        ];

        // dd($filter->namaPerusahaan);

        $body = $this->guzzleRequest('lpse_project_peserta/_search', $params);

        if ($body->hits->total->value != 0){
            $nama =  $body->hits->hits[0]->_source->nama;
            $npwp =  $body->hits->hits[0]->_source->npwp;
        } else{
            echo('data yang anda minta tidak ada');
        }


        $ret['nama'] = $nama;
        $ret['npwp'] = $npwp;

        $params = [
            "query" => [
                "nested" => [
                    "path" => "pemenang_berkontrak",
                    "query" => [
                        "bool" => [
                            "must" => [
                                [
                                    "match_phrase" => [
                                        "pemenang_berkontrak.nama_pemenang" => $namaperusahaan
                                    ]
                                ]
                            ]
                        ]
                    ]
                ]
            ]
        ];

        $body = $this->guzzleRequest('lpse_project_pemenangberkontrak/_search', $params);

        try {
            $kategori =  $body->hits->hits[0]->_source->kategori;
            $alamat = $body->hits->hits[0]->_source->pemenang_berkontrak[0]->alamat;
            $ret['kategori'] = $kategori;
            $ret['alamat'] = $alamat;
        } catch (\Throwable $th){
            $ret['kategori'] = "-";
            $ret['alamat'] = "-";
        }


        //------------------untuk menampilkan data hasil evaluasi------------------
        $params = [
            "query" => [
                "bool" => [
                    "must" => [
                        [
                            "terms" => [
                                "nama_peserta" => [
                                    $namaperusahaan
                                ]
                            ]
                        ],
                        [
                            "range" => [
                                "tanggal_pembuatan" => [
                                    "gte" => $filter->milisRange->gte,
                                    "lte" => $filter->milisRange->lte
                                ]
                            ]
                        ]

                    ]
                ]
            ],
            "aggs" => [
                "evaluasi_kualifikasi" => [
                    "filter" => [
                        "term" => [
                            "evaluasi_kualifikasi"=> "checked"
                        ]
                    ],
                    "aggs" => [
                        "nilai" => [
                            "terms" => [
                                "field" => "evaluasi_kualifikasi"
                            ]
                        ]
                    ]
                ],
                "pembuktian_kualifikasi" => [
                    "filter" => [
                        "term" => [
                            "pembuktian_kualifikasi"=> "checked"
                        ]
                    ],
                    "aggs" => [
                        "nilai" => [
                            "terms" => [
                                "field" => "pembuktian_kualifikasi"
                            ]
                        ]
                    ]
                ],
                "evaluasi_administrasi" => [
                    "filter" => [
                        "term" => [
                            "evaluasi_administrasi"=> "checked"
                        ]
                    ],
                    "aggs" => [
                        "nilai" => [
                            "terms" => [
                                "field" => "evaluasi_administrasi"
                            ]
                        ]
                    ]
                ],
                "evaluasi_teknis" => [
                    "filter" => [
                        "term" => [
                            "evaluasi_teknis"=> "checked"
                        ]
                    ],
                    "aggs" => [
                        "nilai" => [
                            "terms" => [
                                "field" => "evaluasi_teknis"
                            ]
                        ]
                    ]
                ],
                "hasil_kategori" => [
                    "terms" => [
                        "field" => "kategori"
                    ]
                ]
            ],
            "track_total_hits" => true,
            "size" => 0
        ];

        $body = $this->guzzleRequest('lpse_project_hasilevaluasi/_search', $params);

        foreach ($body->aggregations as $key => $val) {
            if($key == "hasil_kategori") {
                $total_tender_kategori = 0;

                foreach ($val->buckets as $var) {
                    $total_tender_kategori += $var->doc_count;
                }

                $ret['total_tender_kategori'] = $total_tender_kategori;
                $ret[$key] = $val->buckets;
            } else {
                if($val->doc_count == 0) {
                    $ret[$key] = 0;
                } else {
                    $ret[$key] = $val->nilai->buckets[0]->doc_count;
                }
            }
        }

        //-------------------untuk menampilkan data menang dan kalah----------------
        $params = [
            "query" => [
                "bool" => [
                    "must" => [
                        [
                            "term" => [
                                "nama_peserta" => $namaperusahaan
                            ]
                        ],
                        [
                            "range" => [
                                "tanggal_pembuatan" => [
                                    "gte" => $filter->milisRange->gte,
                                    "lte" => $filter->milisRange->lte
                                ]
                            ]
                        ]
                    ]
                ]
            ],
            "aggs" => [
                "status_akhir" => [
                    "terms" => [
                        // "default_field" => "search.nama_paket",
                        "field" => "status_pemenang_akhir"
                    ]
                ]
            ],
            "track_total_hits" => true,
            "size" => 10
        ];

        $body = $this->guzzleRequest('lpse_project_hasilevaluasi/_search', $params);
        $status_akhir = ["menang" => 0, "kalah" => 0];

        foreach ($body->aggregations->status_akhir->buckets as $key => $val) {
            $status_akhir[$val->key] = $val->doc_count;
        }

        $ret['status_akhir'] = (object)$status_akhir;

        //---------------untuk menampilkan proses dan selesai-----------
        $params = [
            "query" => [
                "bool" =>[
                    "must" =>[
                        [
                            "match_phrase" => [
                                "nama" => $namaperusahaan
                            ]
                        ],
                        [
                            "range" => [
                                "tanggal_pembuatan" => [
                                    "gte" => $filter->milisRange->gte,
                                    "lte" => $filter->milisRange->lte
                                ]
                            ]
                        ]
                    ]
                ]
            ],
            "aggs" => [
                "tahaptender" => [
                    "nested" => [
                        "path" => "tahap_tender_saat_ini"
                    ],
                    "aggs" => [
                        "tahap" => [
                            "terms" => [
                                "field" => "tahap_tender_saat_ini.info_tahap_tender",
                                "size" => 10
                            ]
                        ]
                    ]
                ]
            ],
            "track_total_hits" => true
        ];

        $body = $this->guzzleRequest('lpse_project_peserta/_search', $params);

        $diikuti = $body->aggregations->tahaptender->doc_count;
        $selesai = isset($body->aggregations->tahaptender->tahap->buckets[0]) ? $body->aggregations->tahaptender->tahap->buckets[0]->doc_count : 0;
        $dalamproses = $diikuti - $selesai;
        $dimenangkan = ($diikuti-$dalamproses) == 0 ? 0 : ($status_akhir['menang'] / ($diikuti-$dalamproses)) * 100;

        $ret['diikuti'] = $diikuti;
        $ret['selesai'] = $selesai;
        $ret['dalamproses'] = $dalamproses;
        $ret['dimenangkan'] = $dimenangkan;

        // -------------untuk rataan hps-----------------
        $params = [
            "query" => [
                "bool" => [
                    "must" => [
                       [
                            "terms" => [
                                "nama_peserta" => [
                                    $namaperusahaan
                                 ]
                            ]
                        ],
                        [
                            "match" => [
                                "status_pemenang_akhir" => "menang"
                            ]
                        ],
                        [
                            "range" => [
                                "tanggal_pembuatan" => [
                                    "gte" => $filter->milisRange->gte,
                                    "lte" => $filter->milisRange->lte
                                ]
                            ]
                        ]
                    ]
                ]
            ]
        ];

        $body = $this->guzzleRequest('lpse_project_hasilevaluasi/_search', $params);

        $nilai_hps = $body->hits->hits;

        $rataanhps = 0;

        for ($i=0; $i < count($nilai_hps) ; $i++) {
            if($body->hits->hits[$i]->_source->hasil_negosiasi != null){
                $hps[$i] = ($body->hits->hits[$i]->_source->hasil_negosiasi/$body->hits->hits[$i]->_source->nilai_hps)*100;

            }
            else{
                $hps[$i] = ($body->hits->hits[$i]->_source->penawaran_terkoreksi/$body->hits->hits[$i]->_source->nilai_hps)*100;
            }

            $rataanhps += $hps[$i]/count($nilai_hps);
        }

        $ret['rataanhps']= $rataanhps;

        //-------------tender teratas---------------------
        $params =  [
           "size" => 0,
               "query" => [
                    "bool" => [
                        "must" => [
                           [
                                "terms" => [
                                    "nama_peserta" => [
                                        $namaperusahaan
                                    ]
                                ]
                           ],
                           [
                               "match" => [
                                  "status_pemenang_akhir" => "menang"
                               ]
                            ],
                           [
                                "range" => [
                                    "tanggal_pembuatan" => [
                                        "gte" => $filter->milisRange->gte,
                                        "lte" => $filter->milisRange->lte
                                    ]
                                ]
                            ]
                        ]
                    ]
                ],
                "aggs" => [
                    "pemenang" => [
                        "terms" => [
                            "field" => "nilai_hps",
                            "size" => 5,
                            "order" => [
                               "_key" => "desc"
                            ]
                        ],
                        "aggs" => [
                            "detail" => [
                                "top_hits" => [
                                    "_source" => [
                                       "includes" => [
                                          "nama_paket",
                                          "instansi",
                                          "nilai_hps",
                                          "kode_paket"
                                       ]
                                    ],
                                    "size" => 1
                                ]
                            ]
                        ]
                    ]
                ]

        ];

        $data = $this->guzzleRequest('/lpse_project_hasilevaluasi/_search', $params);
        // dd($data);
        // $tender_teratas = [];

        $hasil_tender_teratas = $data->aggregations->pemenang->buckets;

        // $tabel_tender_teratas = [];
        // for ($i = 0; $i < count($hasil_tender_teratas); $i++) {
        //     $nama_paket_tender = $hasil_tender_teratas[$i]->detail->hits->hits[0]->_source->nama_paket;

        //     $hps = $hasil_tender_teratas[$i]->detail->hits->hits[0]->_source->nilai_hps;

        //     array_push($tabel_tender_teratas, [$nama_paket_tender, $hps]);

        // }
        $ret['tender_teratas'] = $hasil_tender_teratas;
        // dd($tender_teratas);


        // -------------kompetitor-------------------
        $params = [
            "query" => [
                "bool" => [
                    "must" => [
                        // [
                        //     "terms" => [
                        //         "nama_peserta" => [
                        //             $namaperusahaan
                        //         ]
                        //     ]
                        // ],
                        [
                            "terms" => [
                                "kategori" => [
                                    "Pengadaan Barang",
                                    "Pekerjaan Kontruksi",
                                    "Jasa Konsultasi Badan Usaha",
                                    "Jasa Konsultasi Perorangan",
                                    "Jasa Lainnya"
                                ]
                            ]
                        ],
                        [
                            "match" => [
                                "status_pemenang_akhir" => "menang"
                            ]
                        ],
                        [
                            "range" => [
                                "tanggal_pembuatan" => [
                                    "gte" => $filter->milisRange->gte,
                                    "lte" => $filter->milisRange->lte
                                ]
                            ]
                        ]
                    ]
                ]
            ],
            "aggs" => [
                "pemenang" => [
                    "terms" => [
                        "field" => "nama_peserta",
                        "size" => 10
                    ]
                ],
                "tender_per_bulan" => [
                    "date_histogram" => [
                        "field" => "tanggal_pembuatan",
                        "calendar_interval" => "day",
                        "format" => "dd/MM/yyyy",
                        "time_zone" => "+07:00"
                    ]
                ]
            ],
            "track_total_hits" => true,
            "size" => 0
        ];
        $body = $this->guzzleRequest('lpse_project_hasilevaluasi/_search', $params);

        $tabel = [];
        $hasil_kompetitor = $body->aggregations->pemenang->buckets;

        for ($i = 0; $i < count($hasil_kompetitor); $i++) {
            $key = $hasil_kompetitor[$i]->key;
            $doc_count = $hasil_kompetitor[$i]->doc_count;
            array_push($tabel, (object)["nama"=>$key, "menang" => $doc_count]);
        }

        $ret['tabel'] =$tabel;
        // return $ret;
        // dd($ret);

        if($filter->daterangeDiff >= 5) {
            $params['aggs']['tender_per_bulan']['date_histogram']['calendar_interval'] = "month";
            $params['aggs']['tender_per_bulan']['date_histogram']['format'] = "MMM yy";
        }

        if($filter->namaPerusahaan) {
            $query_string = [
                "query_string" => [
                    "default_field" => "search.nama_peserta",
                    "query" => '"'.$filter->namaPerusahaan.'"'
                ]
            ];

            array_push($params['query']['bool']['must'], $query_string);
        }

        if ($filter->kategori != null || $filter->namaPerusahaan != null) {
            $params = [
                "query" => [
                    "bool" => [
                        "must" => []
                    ]
                ],
                "aggs" => [
                    "pemenang" => [
                        "terms" => [
                            "field" => "status_pemenang_akhir",
                            "size" => 10
                        ],
                        "aggs" => [
                            "jumlahMenang" => [
                                "terms" => [
                                    "field" => "nama_peserta",
                                    "size" => 10
                                ]
                            ]
                        ]
                    ]
                ],
            ];
        }

        // dd($ret);

        return view('app.profile.index', $ret);
    }

    //----------function untuk chart aktif dan dimenangkan-------------------

    public function chart(Request $request)
    {
        $filter = $this->getFilter($request);
        $ret['filter'] = $filter;

        $namaperusahaan = "PT. Telekomunikasi Indonesia, Tbk.";
        if ($filter->namaPerusahaan) {
            $namaperusahaan = $filter->namaPerusahaan;
        }
/*
        // dd($namaperusahaan);
        //----------- untuk menampilkan tender aktif dari index peserta----------
        // $params = [
        //     "query" => [
        //         "bool" => [
        //             "must" => [
        //                 [
        //                     "query_string" => [
        //                         "default_field" => "search.nama_peserta",
        //                         "query" => $namaperusahaan
        //                     ]
        //                 ],
        //                 [
        //                     "term" => [
        //                         "progres" => "aktif"
        //                     ]
        //                 ],
        //                 [
        //                     "range" => [
        //                         "tanggal_pembuatan" => [
        //                             "gte" => $filter->milisRange->gte,
        //                             "lte" => $filter->milisRange->lte
        //                         ]
        //                     ]
        //                 ]
        //             ]
        //         ]
        //     ],
        //     "aggs" => [
        //         "tender_per_bulan" => [
        //             "date_histogram" => [
        //                 "field" => "tanggal_pembuatan",
        //                 "calendar_interval" => "day",
        //                 "format" => "dd/MM/yyyy",
        //                 "time_zone" => "+07:00"
        //             ]
        //         ]
        //     ],
        //     "track_total_hits" => true,
        //     "size" => 0
        // ];

        // // filter tanggal
        // if($filter->daterangeDiff >= 5) {
        //     $params['aggs']['tender_per_bulan']['date_histogram']['calendar_interval'] = "month";
        //     $params['aggs']['tender_per_bulan']['date_histogram']['format'] = "MMM Y";
        // }

        // if($filter->namaPerusahaan) {
        //     $query_string = [
        //         "query_string" => [
        //             "default_field" => "search.nama_peserta",
        //             "query" => '"'.$filter->namaPerusahaan.'"'
        //         ]
        //     ];

        //     array_push($params['query']['bool']['must'], $query_string);
        // }

        // $data = $this->guzzleRequest('lpse_project_peserta/_search', $params);
        // $tender_aktif = $data->aggregations->tender_per_bulan->buckets;
        // $chart_tender_aktif = [];

        // foreach ($tender_aktif as $key => $val) {
        // $chart_tender_aktif[$val->key_as_string] = $val->doc_count;
        // }
*/
        //-----------untuk menampilkan tender dimenangkan dari index pemenangberkontrak----------------
        $params = [
            "query" => [
                "bool" => [
                    "must" => [
                        [
                            "nested" => [
                                "path" => "pemenang_berkontrak",
                                "query" => [
                                    "bool" => [
                                        "must" => [
                                            [
                                                "match" => [
                                                    "pemenang_berkontrak.nama_pemenang" => $namaperusahaan
                                                ]
                                            ]
                                        ]
                                    ]
                                ]
                            ]
                        ],
                        [
                            "range" => [
                                "tanggal_pembuatan" => [
                                    "gte" => $filter->milisRange->gte,
                                    "lte" => $filter->milisRange->lte
                                ]
                            ]
                        ]
                    ]
                ]
            ],
            "aggs" => [
                "tender_per_bulan" => [
                    "date_histogram" => [
                        "field" => "tanggal_pembuatan",
                        "calendar_interval" => "day",
                        "format" => "dd/MM/yyyy",
                        "time_zone" => "+07:00"
                    ]
                ]
            ],
            "track_total_hits" => true,
            "size" => 0
        ];

        if($filter->daterangeDiff >= 5) {
            $params['aggs']['tender_per_bulan']['date_histogram']['calendar_interval'] = "month";
            $params['aggs']['tender_per_bulan']['date_histogram']['format'] = "MMM Y";
        }
/*
        if($filter->namaPerusahaan) {
            $query_string = [
                "query_string" => [
                    "default_field" => "search.nama_peserta",
                    "query" => '"'.$filter->namaPerusahaan.'"'
                ]
            ];

            array_push($params['query']['bool']['must'], $query_string);
        }
*/
        $data = $this->guzzleRequest('lpse_project_pemenangberkontrak/_search', $params);
        $tender_menang = $data->aggregations->tender_per_bulan->buckets;
        $chart_tender_menang = [];
        // dd($data);

        foreach ($tender_menang as $key => $val) {
            $chart_tender_menang[$val->key_as_string] = $val->doc_count;
        }

        if($filter->daterangeDiff >= 5) {
            $time = $this->getAllMonth($filter->daterange);
        } else {
            $time = $this->getAllDate($filter->daterange);
        }
        $chart = [];

        foreach ($time as $key => $val) {
            // $data_aktif = isset($chart_tender_aktif[$val]) ? $chart_tender_aktif[$val] : 0;
            $data_aktif = 0;
            $data_menang = isset($chart_tender_menang[$val]) ? $chart_tender_menang[$val] : 0;

            array_push($chart, [$val, $data_aktif, $data_menang]);
        }
        // dd($chart);
        return $chart;
    }


    public function komparasi(Request $request)
    {
        // dd($request);
        // $ret['perusahaan1'] = $perusahaan1;
        // $ret['perusahaan2'] = $perusahaan2;

        $filter = $this->getFilter($request);
        // dd($filter);
        $ret['filter'] = $filter;
        $namaperusahaan = "PT. Telekomunikasi Indonesia, Tbk.";

        if ($filter->namaPerusahaan) {
            $namaperusahaan = $filter->namaPerusahaan;
        }

        //-------------menampilkan biodata/profil tender--------------
        $params= [
            "query" => [
                "match_phrase" => [
                    "nama" => $namaperusahaan
                ]
            ]
        ];

        

        $body = $this->guzzleRequest('lpse_project_peserta/_search', $params);

        if ($body->hits->total->value != 0){
            $nama =  $body->hits->hits[0]->_source->nama;
            $npwp =  $body->hits->hits[0]->_source->npwp;
        } else{
            echo('data yang anda minta tidak ada');
        }


        $ret['nama'] = $nama;
        $ret['npwp'] = $npwp;

        $params = [
            "query" => [
                "nested" => [
                    "path" => "pemenang_berkontrak",
                    "query" => [
                        "bool" => [
                            "must" => [
                                [
                                    "match_phrase" => [
                                        "pemenang_berkontrak.nama_pemenang" => $namaperusahaan
                                    ]
                                ]
                            ]
                        ]
                    ]
                ]
            ]
        ];

        $body = $this->guzzleRequest('lpse_project_pemenangberkontrak/_search', $params);

        try {
            $kategori =  $body->hits->hits[0]->_source->kategori;
            $alamat = $body->hits->hits[0]->_source->pemenang_berkontrak[0]->alamat;
            $ret['kategori'] = $kategori;
            $ret['alamat'] = $alamat;
        } catch (\Throwable $th){
            $ret['kategori'] = "-";
            $ret['alamat'] = "-";
        }
        
        //------------------untuk menampilkan data hasil evaluasi------------------
        $params = [
            "query" => [
                "bool" => [
                    "must" => [
                        [
                            "terms" => [
                                "nama_peserta" => [
                                    $namaperusahaan
                                ]
                            ]
                        ],
                        [
                            "range" => [
                                "tanggal_pembuatan" => [
                                    "gte" => $filter->milisRange->gte,
                                    "lte" => $filter->milisRange->lte
                                ]
                            ]
                        ]

                    ]
                ]
            ],
            "aggs" => [
                "evaluasi_kualifikasi" => [
                    "filter" => [
                        "term" => [
                            "evaluasi_kualifikasi"=> "checked"
                        ]
                    ],
                    "aggs" => [
                        "nilai" => [
                            "terms" => [
                                "field" => "evaluasi_kualifikasi"
                            ]
                        ]
                    ]
                ],
                "pembuktian_kualifikasi" => [
                    "filter" => [
                        "term" => [
                            "pembuktian_kualifikasi"=> "checked"
                        ]
                    ],
                    "aggs" => [
                        "nilai" => [
                            "terms" => [
                                "field" => "pembuktian_kualifikasi"
                            ]
                        ]
                    ]
                ],
                "evaluasi_administrasi" => [
                    "filter" => [
                        "term" => [
                            "evaluasi_administrasi"=> "checked"
                        ]
                    ],
                    "aggs" => [
                        "nilai" => [
                            "terms" => [
                                "field" => "evaluasi_administrasi"
                            ]
                        ]
                    ]
                ],
                "evaluasi_teknis" => [
                    "filter" => [
                        "term" => [
                            "evaluasi_teknis"=> "checked"
                        ]
                    ],
                    "aggs" => [
                        "nilai" => [
                            "terms" => [
                                "field" => "evaluasi_teknis"
                            ]
                        ]
                    ]
                ],
                "hasil_kategori" => [
                    "terms" => [
                        "field" => "kategori"
                    ]
                ]
            ],
            "track_total_hits" => true,
            "size" => 0
        ];

        $body = $this->guzzleRequest('lpse_project_hasilevaluasi/_search', $params);

        foreach ($body->aggregations as $key => $val) {
            if($key == "hasil_kategori") {
                $total_tender_kategori = 0;

                foreach ($val->buckets as $var) {
                    $total_tender_kategori += $var->doc_count;
                }

                $ret['total_tender_kategori'] = $total_tender_kategori;
                $ret[$key] = $val->buckets;
            } else {
                if($val->doc_count == 0) {
                    $ret[$key] = 0;
                } else {
                    $ret[$key] = $val->nilai->buckets[0]->doc_count;
                }
            }
        }
        
        return view('app.profile.komparasi');
    }

    //---------memfilter waktu--------------
    static function getAllMonth($range) {
        $dates = explode(" - ", $range);

        $startDate = explode("/", $dates[0]);
        $startDate = $startDate[2].'-'.$startDate[1].'-'.$startDate[0];

        $endDate = explode("/", $dates[1]);
        $endDate = $endDate[2].'-'.$endDate[1].'-'.$endDate[0];

        $months = [];

        while (strtotime($startDate) <= strtotime($endDate)) {
            $months[] = date('M Y', strtotime($startDate));

            $startDate = date('d M Y', strtotime($startDate.
                '+ 1 month'));
        }

        return $months;
    }


    static function getAllDate($range) {
        $dates = explode(" - ", $range);

        $startDate = explode("/", $dates[0]);
        $startDate = $startDate[2].'-'.$startDate[1].'-'.$startDate[0];

        $endDate = explode("/", $dates[1]);
        $endDate = $endDate[2].'-'.$endDate[1].'-'.$endDate[0];

        $months = [];

        while (strtotime($startDate) <= strtotime($endDate)) {
            $months[] = date('d/m/Y', strtotime($startDate));

            $startDate = date('d M Y', strtotime($startDate.
                '+ 1 day'));
        }

        return $months;
    }
}
