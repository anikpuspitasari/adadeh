<?php

namespace App\Http\Controllers\Peserta;

use Illuminate\Http\Request;
use GuzzleHttp\Client;
use App\Http\Controllers\Controller;

class PesertaController extends Controller
{
    public function index(Request $request)
    {
        $filter = $this->getFilter($request);
        $ret['filter'] = $filter;
        $tipe = $request->query('tipe');
        $ret['tipe'] = $tipe;
        $ret['url'] = url()->full();
        $page = $request->query('page') ? $request->query('page') : 1;

        // dd($filter, $tipe);
        $kategori = $filter->kategori;

        $ret["PerusahaanKecil"] = null;
        $ret["PerusahaanNonKecil"] = null;

        if ($filter->kualifikasiUsaha) {
            $kualifikasiUsaha = $filter->kualifikasiUsaha;

            foreach ($kualifikasiUsaha as $array => $value) {
                $ret[(str_replace(" ", "", $value))] = $value;
            }

            array_push($filter->kualifikasiUsaha, "Perusahaan Kecil atau Non Kecil");
        }

        $ret['kategori'] = null;
        $ret['kategori'] = $kategori;


        if ($filter->kategori || $filter->kualifikasiUsaha || $filter->namaPerusahaan) {
            $ret['pagination'] = "&page=";
        } else {
            $ret['pagination'] = "?page=";
        }

        // dd($ret);
        return view('app.peserta.index', $ret);
    }

    public function detailPeserta(Request $request)
    {
        $filter = $this->getFilter($request);
        $tipe = $request->query('tipe');
        $kategori = $filter->kategori;
        $page = $request->query('page') ? $request->query('page') : 1;
        $ret["PerusahaanKecil"] = null;
        $ret["PerusahaanNonKecil"] = null;
        $totalData = 50;

        if ($kategori == "Semua Kategori") {
            $kategori = null;
        }
        if ($tipe == "Total HPS Tertinggi") {
            $params = [
                "size" => 0,
                "aggs" => [
                    "hpsTertinggi" => [
                        "terms" => [
                            "field" => "status_pemenang_akhir",
                            "size" => 10
                        ],
                        "aggs" => [
                            "nama" => [
                                "terms" => [
                                    "field" => "nama_peserta",
                                    "size" => $totalData
                                ],
                                "aggs" => [
                                    "totalHps" => [
                                        "sum" => [
                                            "field" => "hasil_negosiasi"
                                        ]
                                    ],
                                    "hasilNegosiasi" => [
                                        "filter" => [
                                            "query_string" => [
                                                "query" => "NOT _exists_  : hasil_negosiasi"
                                            ]
                                        ],
                                        "aggs" => [
                                            "totalNegosiasi" => [
                                                "sum" => [
                                                    "field" => "penawaran_terkoreksi"
                                                ]
                                            ]
                                        ]
                                    ],
                                    "penawaranTerkoreksi"  => [
                                        "sum" => [
                                            "field" => "penawaran_terkoreksi"
                                        ]
                                    ],
                                    "jumlah"  => [
                                        "bucket_script" => [
                                            "buckets_path" => [
                                                "var1"  => "totalHps",
                                                "var2"  => "hasilNegosiasi[totalNegosiasi]"
                                            ],
                                            "script" => "params.var1 + params.var2"
                                        ]
                                    ],
                                    "bucket sort"  => [
                                        "bucket_sort" => [
                                            "sort" => [["jumlah"  => ["order"  => "desc"]]],
                                            "size" => 10,
                                            "from" => (($page - 1) * 10)
                                        ]
                                    ]
                                ]
                            ]
                        ]
                    ]
                ]
            ];
        } else {
            $params = [
                "aggs" => [
                    "kemenanganTertinggi" => [
                        "terms" => [
                            "field" => "status_pemenang_akhir",
                            "size" => 10
                        ],
                        "aggs" => [
                            "jumlahMenang" => [
                                "terms" => [
                                    "field" => "nama_peserta",
                                    "size" => $totalData
                                ],
                                "aggs" => [
                                    "asdf" => [
                                        "bucket_sort" => [
                                            "sort" => [
                                                [
                                                    "_count" => [
                                                        "order" => "desc"
                                                    ]
                                                ]
                                            ],
                                            "from" => ($page - 1) * 10,
                                            // "from" => 10,
                                            "size" => 10
                                        ]
                                    ]
                                ]
                            ]
                        ]
                    ]
                ],
                "size" => 0
            ];
        }

        if ($filter->kategori != null || $filter->namaPerusahaan != null) {
            $params["query"]["bool"]["must"] = [];
        }

        if ($filter->kualifikasiUsaha[0] != null || $filter->kualifikasiUsaha[1] != null) {

            $kualifikasiUsaha = [];

            array_push($filter->kualifikasiUsaha, "Perusahaan Kecil atau Non Kecil");

            foreach ($filter->kualifikasiUsaha as $key => $value) {
                if ($value != null) {
                    array_push($kualifikasiUsaha, $filter->kualifikasiUsaha[$key]);
                }
            }

            foreach ($kualifikasiUsaha as $array => $value) {
                $ret[(str_replace(" ", "", $value))] = $value;
            }

            // dd($kualifikasiUsaha);

            $newTerms =
                [
                    "terms" => [
                        "kualifikasi_usaha" => $kualifikasiUsaha
                    ]

                ];
            array_push($params["query"]["bool"]["must"], $newTerms);
        }

        if ($kategori) {
            $newTerms = [
                "term" => [
                    "kategori" => $kategori
                ]
            ];

            array_push($params["query"]["bool"]["must"], $newTerms);
        }

        if ($filter->namaPerusahaan != "") {
            $newTerms = [
                "query_string" => [
                    "default_field" => "search.nama_peserta",
                    // "query" =>$filter->namaPerusahaan
                    "query" => $filter->namaPerusahaan  .' OR "'. $filter->namaPerusahaan . '" OR ' .
                        $filter->namaPerusahaan . ', OR ' .
                        $filter->namaPerusahaan . '.'
                ]
            ];
            array_push($params["query"]["bool"]["must"], $newTerms);
        }

        // dd($page);
        // dd($params, $filter);
        $data = $this->guzzleRequest('/lpse_project_hasilevaluasi/_search', $params);
        // dd($params, $data);

        $statusAkhir = "menang";
        if ($tipe == "Total HPS Tertinggi") {
            $statusAkhir = "hps";

            try {
                $hasil = $data->aggregations->hpsTertinggi->buckets[1]->nama->buckets;
                if ($data->aggregations->hpsTertinggi->buckets[1]->key != "menang") {
                    $statusAkhir = "hpsSementara";
                }
            } catch (\Throwable $th) {
                $hasil = $data->aggregations->hpsTertinggi->buckets[0]->nama->buckets;
            }
        } else {
            try {
                $agregasiAwal = $data->aggregations->kemenanganTertinggi->buckets[1];
                if ($agregasiAwal->key == "menang") {
                    $statusAkhir = $data->aggregations->kemenanganTertinggi->buckets[1]->key;
                } else {
                    $agregasiAwal = $data->aggregations->kemenanganTertinggi->buckets[2];
                }
            } catch (\Throwable $th) {
                $agregasiAwal = $data->aggregations->kemenanganTertinggi->buckets[0];
                $statusAkhir = $data->aggregations->kemenanganTertinggi->buckets[0]->key;
            }
            $hasil = $agregasiAwal->jumlahMenang->buckets;
            array_unique($hasil, SORT_REGULAR);
        }

        if ($statusAkhir == "menang") {
            $perusahaanKalah = $data->aggregations->kemenanganTertinggi->buckets[0]->jumlahMenang->buckets;
            for ($i = 0; $i < count($perusahaanKalah); $i++) {
                if (count($hasil) < 10) {
                    for ($j = 0; $j < ($hasil); $j++) {
                        if ($hasil[$j]->key == $perusahaanKalah[$i]->key) {
                            break;
                        } else {
                            $perusahaanKalah[$i]->doc_count = 0;
                            array_push($hasil, $perusahaanKalah[$i]);
                            break;
                        }
                    }
                }
            }
        }

        $paginator = (object)[];
        $paginator->current_page = (int)$page;
        $paginator->last_page = intval(ceil($totalData / 10));
        $paginator->total_data = $totalData;

        $ret['isi'] = $hasil;
        $ret['status'] = $statusAkhir;
        $ret['url'] = url('peserta/detailPeserta?tipe=' . $tipe . '&kategori=' . $filter->kategori . '&namaPerusahaan=' . $filter->namaPerusahaan . '&kualifikasiUsaha[]=' . $ret["PerusahaanKecil"] . '&kualifikasiUsaha[]=' . $ret["PerusahaanNonKecil"]);
        $ret['paginator'] = $paginator;
        // dd($ret);
        return view('app.peserta.detailPeserta', $ret);
    }
}
