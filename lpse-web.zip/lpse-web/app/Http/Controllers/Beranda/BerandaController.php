<?php

namespace App\Http\Controllers\Beranda;

use Illuminate\Http\Request;
use GuzzleHttp\Client;
use App\Http\Controllers\Controller;

class BerandaController extends Controller
{
    public function index(Request $request)
    {
        $filter = $this->getFilter($request);
        $ret['filter'] = $filter;
        // dd($filter);
        $params = [
            "query" => [
                "bool" => [
                    "must" => [
                        [
                            "range" => [
                                "tanggal_pembuatan" => [
                                    "gte" => $filter->milisRange->gte,
                                    "lte" => $filter->milisRange->lte
                                ]
                            ]
                        ]
                    ]
                ]
            ],
            "aggs" => [
                "pemenang" => [
                    "nested" => [
                        "path" => "pemenang_berkontrak"
                    ],
                    "aggs" => [
                        "perusahaan" => [
                            "terms" => [
                                "field" => "pemenang_berkontrak.nama_pemenang",
                                "size" => 5
                            ]
                        ]
                    ]
                ]
            ],
            "track_total_hits" => true,
            "size" => 0
        ];

        if ($filter->tender) {
            $query_string = [
                "query_string" => [
                    "default_field" => "search.nama_paket",
                    "query" => '"' . $filter->tender . '"'
                ]
            ];

            array_push($params['query']['bool']['must'], $query_string);
        }

        if ($filter->statusTender) {
            $query = [
                "terms" => [
                    "progres" => $filter->statusTender
                ]
            ];

            array_push($params['query']['bool']['must'], $query);
        }

        if ($filter->kategori) {
            $query = [
                "terms" => [
                    "kategori" => $filter->kategori
                ]
            ];

            array_push($params['query']['bool']['must'], $query);
        }

        if ($filter->kualifikasiUsaha) {
            $query = [
                "terms" => [
                    "kualifikasi_usaha" => $filter->kualifikasiUsaha
                ]
            ];

            array_push($params['query']['bool']['must'], $query);
        }

        if ($filter->hpsMinimum && $filter->hpsMaximum) {
            $query = [
                "range" => [
                    "hps" => [
                        "gte" => $filter->hpsMinimum,
                        "lte" => $filter->hpsMaximum
                    ]
                ]
            ];
            array_push($params['query']['bool']['must'], $query);
        } elseif ($filter->hpsMinimum) {
            $query = [
                "range" => [
                    "hps" => [
                        "gte" => $filter->hpsMinimum
                    ]
                ]
            ];
            array_push($params['query']['bool']['must'], $query);
        } elseif ($filter->hpsMaximum) {
            $query = [
                "range" => [
                    "hps" => [
                        "lte" => $filter->hpsMaximum
                    ]
                ]
            ];
            array_push($params['query']['bool']['must'], $query);
        }

        // dd($params);
        $data = $this->guzzleRequest('/lpse_project_pemenangberkontrak/_search', $params);
        $ret['perusahaan_teratas'] = $data->aggregations->pemenang->perusahaan->buckets;

        $params = [
            "query" => [
                "bool" => [
                    "must" => [
                        [
                            "range" => [
                                "tanggal_pembuatan" => [
                                    "gte" => $filter->milisRange->gte,
                                    "lte" => $filter->milisRange->lte
                                ]
                            ]
                        ]
                    ]
                ]
            ],
            "aggs" => [
                "status" => [
                    "terms" => [
                        "field" => "access_denied",
                        "size" => 2
                    ]
                ],
                "tender_per_bulan" => [
                    "date_histogram" => [
                        "field" => "tanggal_pembuatan",
                        "calendar_interval" => "day",
                        "format" => "dd/MM/yyyy",
                        "time_zone" => "+07:00"
                    ]
                ]
            ],
            "track_total_hits" => true,
            "size" => 0
        ];

        if ($filter->daterangeDiff >= 5) {
            $params['aggs']['tender_per_bulan']['date_histogram']['calendar_interval'] = "month";
            $params['aggs']['tender_per_bulan']['date_histogram']['format'] = "MMM yy";
        }

        if ($filter->tender) {
            $query_string = [
                "query_string" => [
                    "default_field" => "search.nama_paket",
                    "query" => '"' . $filter->tender . '"'
                ]
            ];

            array_push($params['query']['bool']['must'], $query_string);
        }

        if ($filter->statusTender) {
            $query = [
                "terms" => [
                    "progres" => $filter->statusTender
                ]
            ];

            array_push($params['query']['bool']['must'], $query);
        }

        if ($filter->kategori) {
            $query = [
                "terms" => [
                    "kategori" => $filter->kategori
                ]
            ];

            array_push($params['query']['bool']['must'], $query);
        }

        if ($filter->kualifikasiUsaha) {
            $query = [
                "terms" => [
                    "kualifikasi_usaha.keyword" => $filter->kualifikasiUsaha
                ]
            ];

            array_push($params['query']['bool']['must'], $query);
        }

        if ($filter->hpsMinimum && $filter->hpsMaximum) {
            $query = [
                "range" => [
                    "nilai_hps" => [
                        "gte" => $filter->hpsMinimum,
                        "lte" => $filter->hpsMaximum
                    ]
                ]
            ];
            array_push($params['query']['bool']['must'], $query);
        } elseif ($filter->hpsMinimum) {
            $query = [
                "range" => [
                    "nilai_hps" => [
                        "gte" => $filter->hpsMinimum
                    ]
                ]
            ];
            array_push($params['query']['bool']['must'], $query);
        } elseif ($filter->hpsMaximum) {
            $query = [
                "range" => [
                    "nilai_hps" => [
                        "lte" => $filter->hpsMaximum
                    ]
                ]
            ];
            array_push($params['query']['bool']['must'], $query);
        }

        // dd($params);

        $data = $this->guzzleRequest('/lpse_project_pengumuman/_search', $params);
        $hasil = $data->aggregations->tender_per_bulan->buckets;

        $chart = [];
        for ($i = 0; $i < count($hasil); $i++) {
            $tgl = $data->aggregations->tender_per_bulan->buckets[$i]->key_as_string;
            $nilai = $data->aggregations->tender_per_bulan->buckets[$i]->doc_count;
            array_push($chart, [$tgl, $nilai]);
        }
        $ret['chart'] = $chart;

        $tender_status = (object) [
            'total' => $data->hits->total->value,
            'aktif' => 0,
            'tidak_aktif' => 0
        ];
        foreach ($data->aggregations->status->buckets as $var) {
            if ($var->key_as_string == "false") {
                $tender_status->aktif = $var->doc_count;
            } else {
                $tender_status->tidak_aktif = $var->doc_count;
            }
        }
        // dd($data);
        // dd($data);
        $ret['tender_status'] = $tender_status;

        $params = [
            "query" => [
                "bool" => [
                    "must" => [
                        [
                            "range" => [
                                "tanggal_pembuatan" => [
                                    "gte" => $filter->milisRange->gte,
                                    "lte" => $filter->milisRange->lte
                                ]
                            ]
                        ]
                    ]
                ]
            ]
        ];

        if ($filter->tender) {
            $query_string = [
                "query_string" => [
                    "default_field" => "search.nama_paket",
                    "query" => '"' . $filter->tender . '"'
                ]
            ];

            array_push($params['query']['bool']['must'], $query_string);
        }

        if ($filter->statusTender) {
            $query = [
                "terms" => [
                    "progres" => $filter->statusTender
                ]
            ];

            array_push($params['query']['bool']['must'], $query);
        }

        if ($filter->kategori) {
            $query = [
                "terms" => [
                    "kategori" => $filter->kategori
                ]
            ];

            array_push($params['query']['bool']['must'], $query);
        }

        if ($filter->kualifikasiUsaha) {
            $query = [
                "terms" => [
                    "kualifikasi_usaha" => $filter->kualifikasiUsaha
                ]
            ];

            array_push($params['query']['bool']['must'], $query);
        }

        if ($filter->hpsMinimum && $filter->hpsMaximum) {
            $query = [
                "range" => [
                    "nilai_hps" => [
                        "gte" => $filter->hpsMinimum,
                        "lte" => $filter->hpsMaximum
                    ]
                ]
            ];
            array_push($params['query']['bool']['must'], $query);
        } elseif ($filter->hpsMinimum) {
            $query = [
                "range" => [
                    "nilai_hps" => [
                        "gte" => $filter->hpsMinimum
                    ]
                ]
            ];
            array_push($params['query']['bool']['must'], $query);
        } elseif ($filter->hpsMaximum) {
            $query = [
                "range" => [
                    "nilai_hps" => [
                        "lte" => $filter->hpsMaximum
                    ]
                ]
            ];
            array_push($params['query']['bool']['must'], $query);
        }

        $data = $this->guzzleRequest('/lpse_project_peserta/_count', $params);
        // $ret['total_peserta'] = $data;
        $ret['total_peserta'] = $data->count;

        $params = [
            "query" => [
                "bool" => [
                    "must" => [
                        [
                            "range" => [
                                "tanggal_pembuatan" => [
                                    "gte" => $filter->milisRange->gte,
                                    "lte" => $filter->milisRange->lte
                                ]
                            ]
                        ]
                    ]
                ]
            ],
            "aggs" => [
                "pemenang" => [
                    "terms" => [
                        "field" => "status_pemenang_akhir",
                        "size" => 10
                    ]
                ]
            ],
            "track_total_hits" => true,
            "size" => 10
        ];

        if ($filter->tender) {
            $query_string = [
                "query_string" => [
                    "default_field" => "search.nama_paket",
                    "query" => '"' . $filter->tender . '"'
                ]
            ];

            array_push($params['query']['bool']['must'], $query_string);
        }

        if ($filter->statusTender) {
            $query = [
                "terms" => [
                    "progres" => $filter->statusTender
                ]
            ];

            array_push($params['query']['bool']['must'], $query);
        }

        if ($filter->kategori) {
            $query = [
                "terms" => [
                    "kategori" => $filter->kategori
                ]
            ];

            array_push($params['query']['bool']['must'], $query);
        }

        if ($filter->kualifikasiUsaha) {
            $query = [
                "terms" => [
                    "kualifikasi_usaha" => $filter->kualifikasiUsaha
                ]
            ];

            array_push($params['query']['bool']['must'], $query);
        }

        if ($filter->hpsMinimum && $filter->hpsMaximum) {
            $query = [
                "range" => [
                    "nilai_hps" => [
                        "gte" => $filter->hpsMinimum,
                        "lte" => $filter->hpsMaximum
                    ]
                ]
            ];
            array_push($params['query']['bool']['must'], $query);
        } elseif ($filter->hpsMinimum) {
            $query = [
                "range" => [
                    "nilai_hps" => [
                        "gte" => $filter->hpsMinimum
                    ]
                ]
            ];
            array_push($params['query']['bool']['must'], $query);
        } elseif ($filter->hpsMaximum) {
            $query = [
                "range" => [
                    "nilai_hps" => [
                        "lte" => $filter->hpsMaximum
                    ]
                ]
            ];
            array_push($params['query']['bool']['must'], $query);
        }

        $data1 = $this->guzzleRequest('/lpse_project_hasilevaluasi/_search', $params);
        $hasil1 = $data1->aggregations->pemenang->buckets;
        $chart1 = [];
        $total = 0;
        $menang = 0;

        for ($i = 0; $i < count($hasil1); $i++) {
            $key = $data1->aggregations->pemenang->buckets[$i]->key;
            $nilai = $data1->aggregations->pemenang->buckets[$i]->doc_count;
            if ($key == 'kalah' || $key = 'menang') {
                $total += $nilai;
            }

            if ($key = 'menang') {
                $menang = $nilai;
            }
        }
        array_push($chart1, ['menang', $menang]);
        array_push($chart1, ['mengikuti', $total]);
        $ret['chart1'] = $chart1;

        $params = [
            "query" => [
                "bool" => [
                    "must" => [
                        [
                            "range" => [
                                "tanggal_pembuatan" => [
                                    "gte" => $filter->milisRange->gte,
                                    "lte" => $filter->milisRange->lte
                                ]
                            ]
                        ]
                    ]
                ]
            ]
        ];

        if ($filter->tender) {
            $query_string = [
                "query_string" => [
                    "default_field" => "search.nama_paket",
                    "query" => '"' . $filter->tender . '"'
                ]
            ];

            array_push($params['query']['bool']['must'], $query_string);
        }

        if ($filter->statusTender) {
            $query = [
                "terms" => [
                    "progres" => $filter->statusTender
                ]
            ];

            array_push($params['query']['bool']['must'], $query);
        }

        if ($filter->kategori) {
            $query = [
                "terms" => [
                    "kategori" => $filter->kategori
                ]
            ];

            array_push($params['query']['bool']['must'], $query);
        }

        if ($filter->kualifikasiUsaha) {
            $query = [
                "terms" => [
                    "kualifikasi_usaha.keyword" => $filter->kualifikasiUsaha
                ]
            ];

            array_push($params['query']['bool']['must'], $query);
        }

        if ($filter->hpsMinimum && $filter->hpsMaximum) {
            $query = [
                "range" => [
                    "nilai_hps" => [
                        "gte" => $filter->hpsMinimum,
                        "lte" => $filter->hpsMaximum
                    ]
                ]
            ];
            array_push($params['query']['bool']['must'], $query);
        } elseif ($filter->hpsMinimum) {
            $query = [
                "range" => [
                    "nilai_hps" => [
                        "gte" => $filter->hpsMinimum
                    ]
                ]
            ];
            array_push($params['query']['bool']['must'], $query);
        } elseif ($filter->hpsMaximum) {
            $query = [
                "range" => [
                    "nilai_hps" => [
                        "lte" => $filter->hpsMaximum
                    ]
                ]
            ];
            array_push($params['query']['bool']['must'], $query);
        }

        $data = $this->guzzleRequest('/lpse_project_pengumuman/_search', $params);
        $hasil_list_paket = $data->hits->hits;

        $ret['list_paket'] = $hasil_list_paket;

        $data = $this->guzzleRequest('/lpse_project_pengumuman/_search');
        $wilayah_lokasi = $data->hits->hits;
        $wilayah = [];
        for ($i = 0; $i < count($wilayah_lokasi); $i++) {
            $jenis_kontrak = $wilayah_lokasi[$i]->_source->jenis_kontrak;

            array_push($wilayah, [$jenis_kontrak]);

            $ret['wilayah'] = $wilayah;
        }

        // dd($ret);
        return view('app.beranda.beranda', $ret);
    }

    public function getGuzzleRequest()
    {
        $client = new \GuzzleHttp\Client();
        $request = $client->get('http://localhost:9211/lpse_project_peserta/_search');
        $response = $request->getBody()->getContents();
        $body = json_decode($response);
        $isi = $body->hits->hits[0]->_source->nama;
        return $isi;
    }

    public function pencarian()
    {
        return view('app.beranda.pencarian');
    }
}
