<?php

namespace App\Http\Controllers\Notifikasi;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Pusher\Pusher;
use Notification;
use App\User;
use App\Notifications\TenderNotification;

class NotifikasiController extends Controller
{
    public function index()
    {
        $ret['listnotifikasi'] = auth()->user()->notifications;
        
        $ret['unreadnotifikasi'] = auth()->user()->unreadNotifications;//belum dibaca
       
        $ret['readnotifikasi'] = auth()->user()->unreadNotifications->markAsRead(); //->udah dibaca
    	return view('app.notifikasi.index', $ret);

        // $user->unreadNotifications()->update(['read_at' => now()]);
    }
    public function setting()
    {
        $ret['listnotifikasi'] = auth()->user()->notifications;
    	return view('app.notifikasi.setting', $ret);
    }
    public function sendNotification(Request $request)
    {

        $user = User::first();
  
        $details = [
            'id_tender' => $request->id_tender,
            'nama_tender' => $request->nama_tender,
            'nilai_min' => $request->nilai_min,
            'nilai_max' => $request->nilai_max,
            'kualifikasi_usaha'=>$request->kualifikasi_usaha,
            'nilai_hps' => $request->nilai_hps,
            'status_notifikasi'=> $request->status_notifikasi,
            'nama_notifikasi' => $request->nama_notifikasi, //$request->nama_notifikasi
        ];
  
        Notification::send($user, new TenderNotification($details));

        //$ret['listnotifikasi'] = auth()->user()->notifications();//buat nampung data

        return redirect('/notifikasi');
        // return response()->json($details, 200);

    }

    // public function edit($id)
    // {
    //     $ret['listnotifikasi'] = Notifications::where('id_tender', $id_tender)->first();
    //     return view('app.setting', $ret);
    // }

    // public function update(Request $request, $id_tender)
    // {
    //     Notification::where('id_tender',decrypt($id_tender))->update([
    //         'id_tender' => $request->id_tender,
    //         'nama_tender' => $request->nama_tender,
    //         'nilai_min' => $request->nilai_min,
    //         'nilai_max' => $request->nilai_max,
    //         'kualifikasi_usaha'=>$request->kualifikasi_usaha,
    //         'nilai_hps' => $request->nilai_hps,
    //         'nama_notifikasi' => $request->nama_notifikasi,
    //         'status_notifikasi'=> $request->status_notifikasi
    //     ]);
    //     return redirect('/setting');
    // }

    // public function destroy(request $request)
    // {
    //     $status = \DB::kazee-lpse('notifications')->where('id_tender', $id_tender)->delete();
    //      if ($status)
    //     {
    //         return redirect('/setting')->with('success');
    //     }else
    //     {
    //         return redirect('/setting')->with('error');
    //     }
    // }
  
}