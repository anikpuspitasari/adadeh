<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use GuzzleHttp\Client;
use App\Http\Controllers\Controller;

class AjaxController extends Controller
{

    public function detailTender(Request $request)
    {
        $filter = $this->getFilter($request);
        $filter->nama_perusahaan = $request->query('nama-perusahaan');
        $status = $request->query('status');
        $page = $request->query('page') ? $request->query('page') : 1;

        $gte = $request->query('gte');
        $lte = $request->query('lte');

        if (!$filter->nama_perusahaan) {
            $filter->nama_perusahaan = 'PT. Telekomunikasi Indonesia, Tbk.';
        }

        if(($status == "menang") || ($status == "kalah")) {
            $params =  [
               "query" => [
                    "bool" => [
                        "must" => [
                             [
                                "terms" => [
                                    "nama_peserta" => [
                                        $filter->nama_perusahaan
                                    ]
                                ]
                            ],
                            [
                                "match" => [
                                  "status_pemenang_akhir" => $status
                                ]
                            ],
                            [
                                "range" => [
                                    "tanggal_pembuatan" => [
                                        "gte" => $gte ? $gte : $filter->milisRange->gte,
                                        "lte" => $lte ? $lte : $filter->milisRange->lte
                                    ]
                                ]
                            ]
                        ]
                    ]
                ],
                "size" => 10,
                "from" => ($page - 1) * 10,
                "sort" => [ [ "tanggal_pembuatan" => "desc" ] ],
                "track_total_hits" => true
            ];

            $data = $this->guzzleRequest('/lpse_project_hasilevaluasi/_search', $params);

            $ret['type'] = "evaluasi";
        }

        if($status == "selesai") {
            $params =  [
               "query" => [
                    "bool" => [
                        "must" => [
                            [
                                "match_phrase" => [
                                    "nama" => $filter->nama_perusahaan
                                ]
                            ],
                            [
                                "term" => [
                                    "progres" => "selesai"
                                ]
                            ],
                            [
                                "range" => [
                                    "tanggal_pembuatan" => [
                                        "gte" => $gte ? $gte : $filter->milisRange->gte,
                                        "lte" => $lte ? $lte : $filter->milisRange->lte
                                    ]
                                ]
                            ]
                        ]
                    ]
                ],
                "size" => 10,
                "from" => ($page - 1) * 10,
                "sort" => [ [ "tanggal_pembuatan" => "desc" ] ],
                "track_total_hits" => true
            ];

            $data = $this->guzzleRequest('/lpse_project_peserta/_search', $params);

            $ret['type'] = "selesai";
        }

        if(($status == "total_tender") || ($status == "total_aktif") || ($status == "total_tidak_aktif")) {
            $params = [
                "query" => [
                    "bool" => [
                        "must" => [
                            [
                                "range" => [
                                    "tanggal_pembuatan" => [
                                        "gte" => $gte ? $gte : $filter->milisRange->gte,
                                        "lte" => $lte ? $lte : $filter->milisRange->lte
                                    ]
                                ]
                            ]
                        ]
                    ]
                ],
                "size" => 10,
                "from" => ($page - 1) * 10,
                "sort" => [ [ "tanggal_pembuatan" => "desc" ] ],
                "track_total_hits" => true
            ];

            if($status == "total_aktif") {
                array_push(
                    $params['query']['bool']['must'],
                    [
                        "match_phrase" => [
                            "access_denied" => false
                        ]
                    ]
                );
            }

            if($status == "total_tidak_aktif") {
                array_push(
                    $params['query']['bool']['must'],
                    [
                        "match_phrase" => [
                            "access_denied" => true
                        ]
                    ]
                );
            }

            if($filter->tender) {
                $query_string = [
                    "query_string" => [
                        "default_field" => "search.nama_paket",
                        "query" => '"'.$filter->tender.'"'
                    ]
                ];

                array_push($params['query']['bool']['must'], $query_string);
            }

            $data = $this->guzzleRequest('/lpse_project_pengumuman/_search', $params);

            $ret['type'] = "pengumuman";
        }

        if($status == "total_peserta") {
            $params = [
                "query" => [
                    "bool" => [
                        "must" => [
                            [
                                "range" => [
                                    "tanggal_pembuatan" => [
                                        "gte" => $gte ? $gte : $filter->milisRange->gte,
                                        "lte" => $lte ? $lte : $filter->milisRange->lte
                                    ]
                                ]
                            ]
                        ]
                    ]
                ],
                "size" => 10,
                "from" => ($page - 1) * 10,
                "sort" => [ [ "tanggal_pembuatan" => "desc" ] ],
                "track_total_hits" => true
            ];

            if($filter->tender) {
                $query_string = [
                    "query_string" => [
                        "default_field" => "search.nama_paket",
                        "query" => '"'.$filter->tender.'"'
                    ]
                ];

                array_push($params['query']['bool']['must'], $query_string);
            }

            $data = $this->guzzleRequest('/lpse_project_peserta/_search', $params);

            $ret['type'] = "peserta";
        }

        $total =  $data->hits->total->value;

        $paginator = (object)[];
        $paginator->current_page = (int)$page;
        $paginator->last_page = intval(ceil($total / 10));
        $paginator->total_data = $total;

        $ret['total'] = $total;
        $ret['data'] = $data->hits->hits;
        $ret['params'] = (object)$params;
        $ret['paginator'] = $paginator;
        $ret['url'] = url('ajax/detail-tender?daterange='.$filter->daterange.'&nama-perusahaan='.$filter->nama_perusahaan.'&status='.$status);

        return view('app.ajax-components.detail-data', $ret);
    }

}