<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

use GuzzleHttp\Client;
use Carbon\Carbon;

use DateTime;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function getFilter($request) {
        $daterange = $request->query('daterange') ? $request->query('daterange')
                    : date("d/m/Y", strtotime('-3 months')).' - '.date("d/m/Y");

        $explodeDate = explode(' - ', $daterange);

        $gte = DateTime::createFromFormat('d/m/Y', $explodeDate[0])->getTimestamp() * 1000;
        $lte = DateTime::createFromFormat('d/m/Y', $explodeDate[1])->getTimestamp() * 1000;

        $start = Carbon::createFromFormat('d/m/Y', $explodeDate[0]);
        $end = Carbon::createFromFormat('d/m/Y', $explodeDate[1]);

        $diff = $end->diffInMonths($start);

        // $kategori = $request->preg_replace('/\//', '', $request->kategori);

        return (object)[
            'tender' => $request->query('tender') ? $request->query('tender') : null,
            'daterange' => $daterange,
            'milisRange' => (object)[
                'gte' => $gte,
                'lte' => $lte
            ],
            'daterangeDiff' => $diff,
            'kategori' => $request->query('kategori') ? $request->query('kategori') : null,
            'namaPerusahaan' => $request->query('namaPerusahaan') ? $request->query('namaPerusahaan') : null,
            'kualifikasiUsaha' => $request->query('kualifikasiUsaha') ? $request->query('kualifikasiUsaha') : null,
            'statusTender' => $request->query('statusTender') ? $request->query('statusTender') : null,
            'hpsMinimum' => $request->query('hpsMinimum') ? (int)$request->query('hpsMinimum') : null,
            'hpsMaximum' => $request->query('hpsMaximum') ? (int)$request->query('hpsMaximum') : null
        ];
    }

    public function guzzleRequest($endPoint, $params = null) {
        $client = new Client([
            'base_uri' => 'http://localhost:9211/',
            'headers' => ['Content-Type' => 'application/json', "Accept" => "application/json"],
            'verify' => false
        ]);

        if($params) {
            $response = $client->get($endPoint, ['body' => json_encode($params)]);
        } else {
            $response = $client->get($endPoint);
        }

        $body = $response->getBody()->getContents();
        $data = json_decode($body);

        return $data;
    }
}
