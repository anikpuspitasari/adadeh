// var mysql = require('mysql');

// var db = mysql.createConnection({
//     host: "localhost",
//     user: "root",
//     password: ""
// });

// db.connect(function(err) {
//     if (err) throw err;
//     console.log("Connected!");
// });

// var axios = require('axios');
//------------------------------------
// var config = {
//     headers: {
//         'Accept':'notifikasi/notifikasi.js',
//         }
// }
// axios.get('/notifikasi/sendNotifikasi', config)
//   .then(function(response) {
//     console.log(response.data);
//     console.log(response.status);
//     console.log(response.statusText);
//     console.log(response.headers);
//     console.log(response.config);
//   });

var mysql = require('mysql');

var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "kazee-lpse"
});

con.connect(function (sendNotifikasi){
    if(sendNotifikasi) throw sendNotifikasi;
});

module.exports = con;