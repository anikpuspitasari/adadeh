var customTheme = {
  "bar": {
    "defaultFontSettings": {"fontFamily": "Arial"}
  }
};
