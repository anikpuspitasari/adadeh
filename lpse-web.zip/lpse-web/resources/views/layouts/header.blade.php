<header class="site-header" style="background-color:white;">
    <div class="container-fluid">
        <a href="{{ url('beranda')}}" class="site-logo">
            <img class="hidden-md-down" src="{{url('public/img/favicon.png')}}" alt="">
            <img class="hidden-lg-up" src="{{url('public/img/favicon.png')}}" alt="">
            <span class="kz-title">LPSE Kazee</span>
        </a>
        <div class="site-header-content">
            <div class="site-header-content-in">
                <div class="site-header-shown">
                    <div class="dropdown user-menu">
                        <div class="pull-left">
                            <a class="fa fa-bell-o" href="{{ url('/notifikasi')}}"></a>
                        </div>
                        <button class="dropdown-toggle" id="dd-user-menu" type="button" data-toggle="dropdown" ria-haspopup="true" aria-expanded="false">
                            <span class="kz-username">{{ Auth::user()->name }}</span>
                            <img src="{{url('public/img/user(1).png')}}" alt="">
                        </button>
                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="{{ route('logout') }}"
                               onclick="event.preventDefault();
                                             document.getElementById('logout-form').submit();">
                                {{ __('Logout') }}
                            </a>

                            <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                @csrf
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <ul class="main-nav nav-inline kz-nav-inline" style="padding: 6px 0; text-align: center;">
            <div class="row">
            <li class="nav-item kz-nav-item col-md-3">
                <a class="nav-link kz-nav-link beranda" href="{{ url('/beranda') }}">
                    <i class="fa fa-home"></i>
                    <span>Beranda</span>
                </a>
            </li>
            <li class="nav-item kz-nav-item col-md-3">
                <a class="nav-link kz-nav-link peserta" href="{{ url('/peserta') }}">
                    <i class="fa fa-users"></i>
                    <span>Peserta</span>
                </a>
            </li>
            <li class="nav-item kz-nav-item col-md-3">
                <a class="nav-link kz-nav-link profil" href="{{ url('/profile') }}">
                    <i class="fa fa-user"></i>
                    <span>Profil</span>
                </a>
            </li>
            <li class="nav-item kz-nav-item col-md-3">
                <a class="nav-link kz-nav-link analisa" href="{{ url('/analisa') }}">
                    <i class="fa fa-bar-chart"></i>
                    <span>Analisa</span>
                </a>
            </li>
            </div>
        </ul>
    </div>
</header>
