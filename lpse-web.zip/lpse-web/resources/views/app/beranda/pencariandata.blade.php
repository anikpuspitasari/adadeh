@section('pencariandata')

<div class="card-header kz-border-0 p-b-0 text-center">
                        Peserta <label class="label label-white kz-rounded-circle">3</label>
                    </div>
                    <div class="card-block">
                        <div class="table">
                            <table class="table kz-table kz-table-striped kz-table-separated">
                                <tr class="kz-win">
                                    <td class="kz-profile-photo">
                                        <img src="{{url('public/')}}/img/photo-220-1.jpg" alt="" />
                                    </td>
                                    <td>
                                        <h5>Kurolangun Perkasa  <i class="fa fa-star kz-text-gold"></i></h5>
                                        <span>NPWP 21.084.549.1-432.000</span>
                                    </td>
                                </tr>
                                {{-- <tr>
                                    <td class="kz-profile-photo">
                                        <img src="{{url('public/')}}/img/photo-220-1.jpg" alt="" />
                                    </td>
                                    <td>
                                        <h5>REMBON KARYA NETWORK</h5>
                                        <span>NPWP 81.394.255.4-005.000</span>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="kz-profile-photo">
                                        <img src="{{url('public/')}}/img/photo-220-1.jpg" alt="" />
                                    </td>
                                    <td>
                                        <h5>PT.PARMUD JAYA PERKASA</h5>
                                        <span>NPWP 76.668.026.8-027.000</span>
                                    </td>
                                </tr> --}}
                            </table>
                        </div>
                    </div>
@endsection