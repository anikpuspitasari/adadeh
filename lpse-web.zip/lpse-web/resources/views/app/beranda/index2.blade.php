@extends('layouts.default')
@section('title', 'Pencarian')

@section('page-css')
@endsection

@section('styles')
<style>
    .kz-border-0 {
        border: 0 !important;
    }

    .kz-profile-photo {
        width: 50px !important;
    }

    .kz-profile-photo img {
        max-width: 50px !important;
        border-radius: 50px;
    }

    .kz-table tbody tr {
        margin: 10px 0 10px 0;
    }

    .kz-table-text-top tbody tr td:last-child{
        vertical-align: text-top !important;
    }

    .kz-table-separated {
        border-collapse: separate;
        border-spacing: 0 10px;
    }

    .kz-table-striped tbody tr:nth-of-type(odd) {
        /* background-color: rgba(0, 0, 0, 0.05); */
        background-color: #ddd;
        ;
    }

    .kz-table-striped tbody tr:nth-of-type(even) {
        background-color: #eee;
    }

    .kz-label {
        width: 100px;
    }
    .kz-win td{
        border-top:solid 3px gold;
        border-bottom:solid 3px gold;
    }
    .kz-win td:first-child{
        border:solid 3px gold;
        border-right: 0;
    }
    .kz-win td:last-child{
        border:solid 3px gold;
        border-left: 0;
    }

    .kz-text-gold{
        color: goldenrod;
    }

    .kz-rounded-circle{
        border-radius: 50px;
    }
</style>
@endsection

@section('content')
<div class="container">
    <div class="card">
        <div class="card-block">
            {{-- Kotak atas --}}
            <div class="col-md-12">
                <div class="row">
                    <div class="col-md-12">
                        <span>Pengadaan Jasa Konsultan Badan Usaha Data</span>
                        <span class="label kz-label label-success pull-right">Aktif</span>
                    </div>
                    <div class="col-md-12">
                        <a href="http://lpse.basarnas.go.id/eproc4/" target="_blank">http://lpse.basarnas.go.id/eproc4/</a>
                    </div>
                    <div class="col-md-3 semibold">
                        <div><label>Tahap</label></div>
                        <div><label>Kode</label></div>
                        <div><label>Nama Paket</label></div>
                        <div><label>Kategori</label></div>
                        <div><label>Akhir Pendaftaran</label></div>
                        <div><label>Instansi</label></div>
                        <div><label>Kualifikasi Usaha</label></div>
                        <div><label>Nilai HPS</label></div>
                        <div><label>Nilai Pagu</label></div> 
                        <div><label>Cara Pembayaran</label></div> 
                        <div><label>Lokasi Pekerjaan</label></div>                            

                    </div>
                    <div class="col-md-9">
                        <label class="kz-text-gold font-weight-bold">Pengumuman Prakualifikasi, 4 hari lagi</label>
                        <div><label>6640119</label></div>
                        <div><label>Pengadaan Jasa Konsultan Badan Usaha Data</label></div>
                        <div><label>Jasa Konsultasi Badan Usaha</label></div>
                        <div><label>2019-12-31</label></div>
                        <div><label>Lembaga Kebijakan Pengadaan Barang/Jasa Pemerintah</label></div>
                        <div><label>perusahaan Non Kecil</label></div>
                        <div><label>Rp 198.000.000,00</label></div>
                        <label>Rp 200.000.000,00</label>
                        <label>Lumsum</label>
                        <label>Jl. Epicentrum Tengah Lot 11B Jakarta Selatan - Jakarta Selatan (Kota)</label>
                    </div>
                </div>
            </div>
            <div class="col-md-12">
                <hr>
            </div>
            {{-- Yang bagi 2 --}}
            {{-- Competitor --}}
            <div class="col-md-6">
                <div class="card kz-border-0">
                    <div class="card-header kz-border-0 p-b-0 text-center">
                        Riwayat Peserta <label class="label label-white kz-rounded-circle">3</label>
                    </div>
                    <div class="card-block">
                        <div class="table">
                            <table class="table kz-table kz-table-striped kz-table-separated">
                                <tr class="">
                                    <td class="kz-profile-photo">
                                        <img src="{{url('public/')}}/img/photo-220-1.jpg" alt="" />
                                    </td>
                                    <td>
                                        <h5>Kurolangun Perkasa  <i class="kz-text-gold"></i></h5>
                                        <span>NPWP 21.084.549.1-432.000</span>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="kz-profile-photo">
                                        <img src="{{url('public/')}}/img/photo-220-1.jpg" alt="" />
                                    </td>
                                    <td>
                                        <h5>REMBON KARYA NETWORK</h5>
                                        <span>NPWP 81.394.255.4-005.000</span>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="kz-profile-photo">
                                        <img src="{{url('public/')}}/img/photo-220-1.jpg" alt="" />
                                    </td>
                                    <td>
                                        <h5>PT.PARMUD JAYA PERKASA</h5>
                                        <span>NPWP 76.668.026.8-027.000</span>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            {{-- Tahapan --}}
            <div class="col-md-6">
                <div class="card kz-border-0">
                    <div class="card-header kz-border-0 p-b-0 text-center">
                        Tahapan  <label class="label label-white kz-rounded-circle">21</label>
                    </div>
                    <div class="card-block">
                        <div class="table">
                            <table class="table kz-table kz-table-striped kz-table-separated kz-table-text-top">
                                <tr class="kz-win">
                                    <td>
                                        <span class="semibold">Pengumuman Prakualifikasi</span><br>
                                        <span>17 Januari 2020 13:00 - 27 Januari 2020 23:59</span> <br>
                                        <span>Tidak ada Perubahan</span>
                                    </td>
                                    <td>1</td>
                                </tr>
                                <tr>
                                    <td>
                                        <span>Download Dokumen Kualifikasi</span><br>
                                        <span>17 Januari 2020 13:00 - 27 Januari 2020 23:59</span> <br>
                                        <span>Tidak ada Perubahan</span>
                                    </td>
                                    <td>2</td>
                                </tr>
                                <tr>
                                    <td>
                                        <span>Penjelasan Dokumen Prakualifikasi</span><br>
                                        <span>21 Januari 2020 09:00 - 21 Januari 2020 10:30</span> <br>
                                        <span>Tidak ada Perubahan</span>
                                    </td>
                                    <td>3</td>
                                </tr>
                                <tr>
                                    <td>
                                        <span>Kirim Persyaratan Kualifikasi</span><br>
                                        <span>21 Januari 2020 12:00 - 30 Januari 2020 09:00</span> <br>
                                        <span>Tidak ada Perubahan</span>
                                    </td>
                                    <td>4</td>
                                </tr>
                                <tr>
                                    <td>
                                        <span>Evaluasi Dokumentasi Kualifikasi</span><br>
                                        <span>30 Januari 2020 09:01 - 06 Februari 2020 16:00</span> <br>
                                        <span>Tidak ada Perubahan</span>
                                    </td>
                                    <td>5</td>
                                </tr>
                                <tr>
                                    <td>
                                        <span>Pembuktian Kualifikasi</span><br>
                                        <span>14 Februari 2020 09:00 - 18 Februari 2020 16:00</span> <br>
                                        <span>Tidak ada Perubahan</span>
                                    </td>
                                    <td>6</td>
                                </tr>
                                <tr>
                                    <td>
                                        <span>Penetapan Hasil Kualifikasi</span><br>
                                        <span>19 Februari 2020 09:00 - 19 Februari 2020 12:00</span> <br>
                                        <span>Tidak ada Perubahan</span>
                                    </td>
                                    <td>7</td>
                                </tr>
                                <tr>
                                    <td>
                                        <span>Pengumuman Hasil Kualifikasi</span><br>
                                        <span>19 Februari 2020 12:01 - 19 Februari 2020 16:00</span> <br>
                                        <span>Tidak ada Perubahan</span>
                                    </td>
                                    <td>8</td>
                                </tr>
                                <tr>
                                    <td>
                                        <span>Masa Sanggah Prakualifikasi</span><br>
                                        <span>19 Februari 2020 16:01 - 26 Februari 2020 16:00</span> <br>
                                        <span>Tidak ada Perubahan</span>
                                    </td>
                                    <td>9</td>
                                </tr>
                                <tr>
                                    <td>
                                        <span>Download Dokumen Pemilihan</span><br>
                                        <span>27 Februari 2020 00:00 - 06 Maret 2020 23:59</span> <br>
                                        <span>Tidak ada Perubahan</span>
                                    </td>
                                    <td>10</td>
                                </tr>
                                <tr>
                                    <td>
                                        <span>Pemberian Penjelasan</span><br>
                                        <span>02 Maret 2020 09:00 - 02 Maret 2020 10:30</span> <br>
                                        <span>Tidak ada Perubahan</span>
                                    </td>
                                    <td>11</td>
                                </tr>
                                <tr>
                                    <td>
                                        <span>Upload Dokumen Penawaran</span><br>
                                        <span>02 Maret 2020 13:00 - 09 Maret 2020 10:00</span> <br>
                                        <span>Tidak ada Perubahan</span>
                                    </td>
                                    <td>12</td>
                                </tr>
                                <tr>
                                    <td>
                                        <span>Pembukaan dan Evaluasi Penawaran File I:Administrasi dan Teknis</span><br>
                                        <span>09 Maret 2020 10:01 - 16 Maret 2020 16:00</span> <br>
                                        <span>Tidak ada Perubahan</span>
                                    </td>
                                    <td>13</td>
                                </tr>
                                <tr>
                                    <td>
                                        <span>Pengumuman Hasil Evaluasi Administrasi dan Teknis</span><br>
                                        <span>17 Maret 2020 09:00 - 17 Maret 2020 16:00</span> <br>
                                        <span>Tidak ada Perubahan</span>
                                    </td>
                                    <td>14</td>
                                </tr>
                                <tr>
                                    <td>
                                        <span>Pembukaan dan Evaluasi Penawaran File II: Harga</span><br>
                                        <span>18 Maret 2020 09:00 - 18 Maret 2020 16:00</span> <br>
                                        <span>Tidak ada Perubahan</span>
                                    </td>
                                    <td>15</td>
                                </tr>
                                <tr>
                                    <td>
                                        <span>Penetapan Pemenang</span><br>
                                        <span>19 Maret 2020 09:00 - 19 Maret 2020 12:00</span> <br>
                                        <span class="text-primary">1 kali perubahan</span>
                                    </td>
                                    <td>16</td>
                                </tr>
                                <tr>
                                    <td>
                                        <span>Pengumuman Pemenang</span><br>
                                        <span>19 Maret 2020 12:01 - 19 Maret 2020 16:00</span> <br>
                                        <span>Tidak ada Perubahan</span>
                                    </td>
                                    <td>17</td>
                                </tr>
                                <tr>
                                    <td>
                                        <span>Masa Sanggah</span><br>
                                        <span>19 Maret 2020 16:01 - 27 Maret 2020 16:00</span> <br>
                                        <span>Tidak ada Perubahan</span>
                                    </td>
                                    <td>18</td>
                                </tr>
                                <tr>
                                    <td>
                                        <span>Klarifikasi dan Negosiasi Teknik dan Biaya</span><br>
                                        <span>30 Maret 2020 09:00 - 30 Maret 2020 16:00</span> <br>
                                        <span>Tidak ada Perubahan</span>
                                    </td>
                                    <td>19</td>
                                </tr>
                                <tr>
                                    <td>
                                        <span>Surat Penunjukan Penyedia Barang/Jasa</span><br>
                                        <span>31 Maret 2020 09:00 - 15 April 2020 16:00</span> <br>
                                        <span>Tidak ada Perubahan</span>
                                    </td>
                                    <td>20</td>
                                </tr>
                                <tr>
                                    <td>
                                        <span>Penandatangan Kontrak</span><br>
                                        <span>31 Maret 2020 09:00 - 15 April 2020 16:00</span> <br>
                                        <span>Tidak ada Perubahan</span>
                                    </td>
                                    <td>21</td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

</div>
@endsection

@section('scripts') @endsection
