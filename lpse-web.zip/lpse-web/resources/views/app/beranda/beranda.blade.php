@extends('layouts.default')
@section('title', 'Beranda')

@section('styles')
<link rel="stylesheet"
    href="{{url('public/')}}/templates/default/css/separate/vendor/bootstrap-daterangepicker.min.css">
<link href="{{url('public/')}}/templates/default/css/separate/pages/others.min.css" rel="stylesheet" type="text/css">

<style type="text/css">
    hr {
        display: block;
        margin-top: 0.5em;
        margin-bottom: 0.5em;
        margin-left: auto;
        margin-right: auto;
        border-style: inset;
        border-width: 1px;
        color: yellow;
    }

    .kz-sidebar-button {
        width: 90%;
        padding: 2px;
        padding-left: 30px;
        border-radius: 50px;
    }

    .kz-sidebar-title {
        padding: 25px;
    }

    .kz-sidebar-input {
        width: 90%;
    }

    .kz-sidebar-checkbox {
        margin-left: 25px;

    }

    .kz-pagecontent-datepicker {
        height: 70px;
    }

    .kz-cari-button {
        width: 20%;
        padding: 2px;
        border-radius: 50px;
        margin-right: 20px;
    }

    .kz-pagecontent-chart {
        height: 350px;
    }

    .kz-pagecontent-piechart {
        height: 313px;
    }

    .kz-pagecontent-aktifbutton {
        width: 10%;
        padding: 2px;
        border-radius: 50px;
        box-shadow: 5px 5px 15px grey;
    } /* tidak dipakai */

    .kz-table tr:nth-child(even) {
        background-color: #e6e6ff;
    }

    .kz-table .kz-table-rounded {
        border-collapse: collapse;
        border-radius: 1em;
        overflow: hidden;
    }

    .custom-dropdown {
        margin-left: 25px;
        width: 90%;
    }

    .kz-number-input input::-webkit-outer-spin-button,
    input::-webkit-inner-spin-button {
        -webkit-appearance: none;
        margin: 0;
    }

    .kz-label {
    color: white;
    font-family: Arial;
    border-radius: 8px; 
    font-weight: bold; 
    display: inline-block;
    }

    .kz-info {
        background-color: #2196F3;
    } /* Blue */
    .kz-success {
        background-color: #4CAF50;
        } /* Green */

    .kz-overflow {
        white-space: nowrap; 
        width: 80%; 
        overflow: hidden;
        text-overflow: ellipsis;
    }
</style>
@endsection

@section('content')

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card" style="border-radius:50px;">
                <div class="card-block">
                    <div class="col-md-8 offset-md-2">
                        <div class="search">
                        <h2 style="text-align: center;">Pencarian Tender</h2>
                            <div class="form-control-wrapper form-control-icon-right">
                                <input type="text" id="search-tender" class="form-control form-control-rounded"
                                    style="border-color: #0093DD;" placeholder="Masukkan Kata Kunci Nama Paket " value="{{$filter->tender}}">
                                <span id="searchBtn" role="button" onclick="toggle()" class="fa fa-search"></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <input type="hidden" id="dtp_input2" value="/">
    </div>

    <div class="row">
        <div class="col-md-4">
            <form id="form-search" method="GET" action="{{url('/beranda')}}">
                <div class="card">
                    <div class="card-block">
                        <section class="widget widget-simple-sm-fill">
                            <h4><b>Cari lebih detail</b></h4>
                        </section>
                    </div>
                    {{--
                    <span class="kz-sidebar-title semibold">Wilayah</span>
                    <div class="dropdown">
                        <button class="btn dropdown-toggle kz-sidebar-button  kz-sidebar-checkbox" type="button"
                            id="dropdownMenuButton1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"
                            style="border-color: #0093DD; background-color: #ffffff;">
                            Pilih Wilayah:
                        </button>
                        <div class="dropdown-menu custom-dropdown" style="overflow-x: auto; overflow: scroll;"
                            aria-labelledby="dropdownMenuButton1 ">
                            @foreach ($wilayah as $list_wilayah)
                            <a class="dropdown-item" style="text-overflow: ellipsis; overflow: hidden; "
                                href="#">{{$list_wilayah[0]->list_lokasi[0]}}</a>
                            @endforeach
                        </div>
                    </div>

                    <br>
                    <span class="kz-sidebar-title semibold">LPSE</span>
                    <div class="dropdown">
                        <button class="btn dropdown-toggle kz-sidebar-button kz-sidebar-checkbox" type="button"
                            id="dropdownMenuButton2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"
                            style="border-color:  #0093DD; background-color: #ffffff;">
                            Nama LPSE
                        </button>
                        <div class="dropdown-menu custom-dropdown" aria-labelledby="dropdownMenuButton2">
                            <a class="dropdown-item" href="#">Nama LPSE</a>
                            <a class="dropdown-item" href="#">Nama LPSE</a>
                            <a class="dropdown-item" href="#">Nama LPSE</a>
                        </div>
                    </div>
                    <br>
                        <span class="kz-sidebar-title semibold">KBLI</span>
                        <div class="dropdown">
                            <button class="btn dropdown-toggle kz-sidebar-button kz-sidebar-checkbox" type="button" id="dropdownMenuButton3" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"  style="border-color:  #0093DD; background-color: #ffffff;">
                                Pertanian, Kehutanan, dan Perikanan
                            </button>
                            <div class="dropdown-menu custom-dropdown" aria-labelledby="dropdownMenuButton3">
                                <a class="dropdown-item" href="#">Pertanian</a>
                                <a class="dropdown-item" href="#">Kehutanan</a>
                                <a class="dropdown-item" href="#">Perikanan</a>
                            </div>
                        </div>
                    --}}
                    <div><span class="kz-sidebar-title semibold">Kualifikasi Usaha</span>
                        <div class="checkbox-bird kz-sidebar-checkbox">
                            <input type="checkbox" id="check-bird-1" name="kualifikasiUsaha[]"
                                value="Perusahaan Kecil" />
                            <label for="check-bird-1">Perusahaan Kecil</label>
                        </div>
                        <div class="checkbox-bird kz-sidebar-checkbox">
                            <input type="checkbox" id="check-bird-2" name="kualifikasiUsaha[]"
                                value="Perusahaan Non Kecil" />
                            <label for="check-bird-2">Perusahaan Non Kecil</label>
                        </div>
                    </div>
                    <br>
                    <div><span class="kz-sidebar-title semibold">Kategori</span>
                        <div class="checkbox-bird kz-sidebar-checkbox">
                            <input type="checkbox" id="check-bird-3" name="kategori[]" value="Pengadaan Barang" />
                            <label for="check-bird-3">Pengadaan Barang</label>
                        </div>
                        <div class="checkbox-bird kz-sidebar-checkbox">
                            <input type="checkbox" id="check-bird-4" name="kategori[]" value="Pekerjaan Konstruksi" />
                            <label for="check-bird-4">Pekerjaan Konstruksi</label>
                        </div>
                        <div class="checkbox-bird kz-sidebar-checkbox">
                            <input type="checkbox" id="check-bird-5" name="kategori[]"
                                value="Jasa Konsultansi Badan Usaha" />
                            <label for="check-bird-5">Jasa Konsultansi Badan Usaha</label>
                        </div>
                        <div class="checkbox-bird kz-sidebar-checkbox">
                            <input type="checkbox" id="check-bird-6" name="kategori[]"
                                value="Jasa Konsultansi Perorangan" />
                            <label for="check-bird-6">Jasa Konsultansi Perorangan</label>
                        </div>
                        <div class="checkbox-bird kz-sidebar-checkbox">
                            <input type="checkbox" id="check-bird-7" name="kategori[]" value="Jasa Lainnya" />
                            <label for="check-bird-7">Jasa Lainnya</label>
                        </div>
                    </div>
                    <br>
                    <div><span class="kz-sidebar-title semibold">Status Tender</span>
                        <div class="checkbox-bird kz-sidebar-checkbox">
                            <input type="checkbox" id="check-bird-8" name="statusTender[]" value="aktif" />
                            <label for="check-bird-8">Aktif</label>
                        </div>
                        <div class="checkbox-bird kz-sidebar-checkbox">
                            <input type="checkbox" id="check-bird-10" name="statusTender[]" value="selesai" />
                            <label for="check-bird-10">Selesai</label>
                        </div>

                        <br>
                        <div><span class="kz-sidebar-title semibold">Nilai HPS</span>
                            <div class="form-group kz-sidebar-checkbox kz-sidebar-input">
                                <div class="input-group">
                                    <div class="input-group-addon" style="border-color: #0093DD;">Rp</div>
                                    <input type="number" min="0" class="form-control kz-number-input" style="border-color: #0093DD;"
                                        id="exampleInputAmount1" placeholder="Minimum" name="hpsMinimum">
                                </div>
                            </div>
                            <div class="form-group kz-sidebar-checkbox kz-sidebar-input">
                                <div class="input-group">
                                    <div class="input-group-addon" style="border-color: #0093DD;">Rp</div>
                                    <input type="number" min="0" class="form-control kz-number-input" style="border-color: #0093DD;"
                                        id="exampleInputAmount2" placeholder="Maksimum" name="hpsMaximum">
                                </div>
                            </div>

                            <fieldset class="form-group kz-sidebar-checkbox">
                                <button type="submit" class="btn kz-cari-button pull-right">Cari</button>
                            </fieldset>

                        </div>

                    </div>

                </div>
                <input type="hidden" id="tender" name="tender" value="{{$filter->tender}}">
                <input type="hidden" id="daterange" name="daterange" value="{{$filter->daterange}}">
            </form>
        </div>


        <div class="col-md-8">
            <div class="card kz-pagecontent-datepicker">
                <div class="card-block">
                    <div class="row">
                        <div class="col-md-8">
                            <label>Waktu</label>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group pull-right">
                                <div class='input-group date'>
                                    <input id="search-daterange" type="text" class="form-control"
                                        value="{{$filter->daterange}}">
                                    <span class="input-group-addon">
                                        <i class="font-icon font-icon-calend"></i>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <div class="header">
                <div class="card">
                    <div class="kz-pagecontent-chart" id="container1"></div>
                </div>
                <div class="row">
                    <div class="col-sm-3">
                        <article class="statistic-box purple cursor-pointer"
                            onclick="getDetailData('Total Tender', 'total_tender')">
                            <div>
                                <div class="caption">
                                    <div>Total Tender</div>
                                </div>
                                <div class="number">{{$tender_status->total}}</div>
                            </div>
                        </article>
                        <article class="statistic-box green cursor-pointer"
                            onclick="getDetailData('Total Aktif', 'total_aktif')">
                            <div>
                                <div class="caption">
                                    <div>Tender Aktif</div>
                                </div>
                                <div class="number">{{$tender_status->aktif}}</div>
                            </div>
                        </article>
                    </div>
                    <div class="col-sm-3">
                        <article class="statistic-box yellow cursor-pointer"
                            onclick="getDetailData('Total Peserta', 'total_peserta')">
                            <div>
                                <div class="caption">
                                    <div>Total peserta</div>
                                </div>
                                <div class="number">{{$total_peserta}}</div>
                            </div>
                        </article>
                        <article class="statistic-box red cursor-pointer"
                            onclick="getDetailData('Total Tidak Aktif', 'total_tidak_aktif')">
                            <div>
                                <div class="caption">
                                    <div>Tender Tidak Aktif</div>
                                </div>
                                <div class="number">{{$tender_status->tidak_aktif}}</div>
                            </div>
                        </article>
                    </div>
                    <div class="col-sm-6">
                        <section class="card">
                            <div class="kz-pagecontent-piechart" id="container2"></div>
                        </section>
                    </div>
                </div>

                <div class="card">
                    <div class="row">
                        <div class="card-block">
                            <div class="col-md-12 semibold">
                                <span>Peserta Teratas</span>
                            </div>
                            <div class="col-md-12">
                                <h6>Berdasarkan kemenangan berkontrak pada seluruh bidang</h6>
                                {{-- <a href="http://lpse.basarnas.go.id/eproc4/">http://lpse.basarnas.go.id/eproc4/</a> --}}
                            </div>
                            <div class="col-md-12">
                                <table class="kz-table" style="width:100%">
                                    <tbody>
                                        @foreach ($perusahaan_teratas as $var)
                                        <tr>
                                            <td class="kz-table kz-table-rounded p-l-md kz-link" width="40px;"
                                                height="40px;">
                                                <img src="http://localhost/KazeeLPSE/public/img/user(1).png"
                                                    width="25px;" height="25px;" alt="">
                                                <a href="{{url('/profile?namaPerusahaan=' . $var->key)}}">
                                                    {{$var->key}}
                                                </a>
                                                {{-- {{$var->key}} --}}
                                            </td>
                                        </tr>
                                        @endforeach
                                    <tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <label class="semibold" style="padding: 20px 0px 3px 30px; text-align: left; font-size: 25px;">
                        Daftar Tender
                    </label>
                    @foreach ($list_paket as $list)

                    @php
                    $paket = $list->_source;
                    @endphp
                    <div class="row">
                        <div class="col-md-12 card-block p-l-3 p-r-3">
                            <hr>
                        </div>
                        <div class="card-block p-l-3">
                            <div class="row">
                                <div class="col-md-10 semibold">
                                    <span class="kz-overflow">
                                        <a style="font-size: 18px; color: #000000;" href="{{url('/beranda/pencarian')}}">
                                            {{$paket->nama_paket}}
                                        </a>
                                    </span>
                                </div>
                                <div class="col-md-2">
                                    <span class="kz-label kz-success pull-right p-l-1 p-r-1 m-r-2">{{$paket->progres}}</span>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <label>{{$paket->instansi}}</label>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <a href="{{$paket->link}}" target="_blank">{{$paket->link}}</a>
                                </div>
                            </div>
                            <br>
                            <div class="row">
                                <div class="col-md-3">
                                    <div><label style="font-weight: bold;">Tahap</label></div>
                                </div>
                                <div class="col-md-9">
                                    <div>
                                        <label class="p-l-1 p-r-1 kz-label kz-info">
                                            {{isset($paket->tahap_tender_saat_ini->info_tahap_paket) ? $paket->tahap_tender_saat_ini->info_tahap_paket : $paket->tahap_tender_saat_ini->info_tahap_tender}}
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3">
                                    <div><label style="font-weight: bold;">Kode</label></div>
                                </div>
                                <div class="col-md-9">
                                    <div><label>{{$paket->kode_paket}}</label></div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3">
                                    <div><label style="font-weight: bold;">Kategori</label></div>
                                </div>
                                <div class="col-md-9">
                                    <div><label>{{$paket->kategori}}</label></div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3">
                                    <div><label style="font-weight: bold;">Akhir Pendaftaran</label></div>
                                </div>
                                <div class="col-md-9">
                                    <div><label>
                                            {{date("d/m/Y H:i", $paket->akhir_pendaftaran/1000)}}
                                        </label></div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3">
                                    <div><label style="font-weight: bold;">Kualifikasi Usaha</label></div>
                                </div>
                                <div class="col-md-9">
                                    <div><label>{{$paket->kualifikasi_usaha}}</label></div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3">
                                    <div><label style="font-weight: bold;">Nilai HPS</label></div>
                                </div>
                                <div class="col-md-9">
                                    <div><label>Rp {{str_replace("Rp", "", $paket->hps)}}</label></div>
                                </div>
                            </div>

                        </div>
                    </div>
                    @endforeach
                </div>
            </div>
        </div>
    </div>
</div>

{{-- <form id="form-search" method="GET" action="{{url('/beranda')}}">
<input type="hidden" id="tender" name="tender" value="{{$filter->tender}}">
<input type="hidden" id="daterange" name="daterange" value="{{$filter->daterange}}">
</form> --}}

<div class="modal fade" id="modal-detail" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="modal-close" data-dismiss="modal" aria-label="Close">
                    <i class="font-icon-close-2"></i>
                </button>
                <h4 class="modal-title" id="modal-title"></h4>
            </div>
            <div class="modal-body" id="detail-container"></div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
            </div>
        </div>
    </div>
</div>
@endsection

@section('scripts')
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.24.0/moment-with-locales.min.js"></script>

<script src="https://cdn.anychart.com/releases/v8/js/anychart-base.min.js?hcode=c11e6e3cfefb406e8ce8d99fa8368d33">
</script>
<script src="https://cdn.anychart.com/releases/v8/js/anychart-ui.min.js?hcode=c11e6e3cfefb406e8ce8d99fa8368d33">
</script>
<script src="https://cdn.anychart.com/releases/v8/js/anychart-exports.min.js?hcode=c11e6e3cfefb406e8ce8d99fa8368d33">
</script>
<link href="https://cdn.anychart.com/releases/v8/css/anychart-ui.min.css?hcode=c11e6e3cfefb406e8ce8d99fa8368d33"
    type="text/css" rel="stylesheet">
<link href="https://cdn.anychart.com/releases/v8/fonts/css/anychart-font.min.css?hcode=c11e6e3cfefb406e8ce8d99fa8368d33"
    type="text/css" rel="stylesheet">

<script type="text/javascript"
    src="{{url('public/templates/default')}}/js/lib/eonasdan-bootstrap-datetimepicker/bootstrap-datetimepicker.min.js">
</script>
<script src="{{url('public/templates/default')}}/js/lib/clockpicker/bootstrap-clockpicker.min.js"></script>
<script src="{{url('public/templates/default')}}/js/lib/clockpicker/bootstrap-clockpicker-init.js"></script>
<script src="{{url('public/templates/default')}}/js/lib/daterangepicker/daterangepicker.js"></script>
<script src="{{url('public/templates/default')}}/js/lib/bootstrap-select/bootstrap-select.min.js"></script>

<script>
    $('#search-daterange').daterangepicker({
    ranges: {
        'Hari Ini': [moment(), moment()],
        'Kemarin': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
        'Data 7 Hari': [moment().subtract(6, 'days'), moment()],
        'Data 30 Hari': [moment().subtract(29, 'days'), moment()],
        'Data Bulan Ini': [moment().startOf('month'), moment().endOf('month')],
        'Data Bulan Lalu': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
    },
    widgetPositioning: {
        horizontal: 'left'
    },
    "linkedCalendars": true,
    "autoUpdateInput": true,
    "alwaysShowCalendars": false,
    "showWeekNumbers": true,
    "showDropdowns": true,
    "showISOWeekNumbers": true,
    debug: false,
    locale: {
        format: 'DD/MM/YYYY'
    }
    });

    $('#search-tender').keyup(function(e){
        if(e.keyCode == 13)
        {
            const searchTender = $(this).val();

            $('#tender').val(searchTender);
            $('#form-search').submit();
        }
    });

    $('#search-daterange').on('change', function(e){
        const searchDaterange = $(this).val();

        $('#daterange').val(searchDaterange);
        $('#form-search').submit();
    });
</script>

<script>
    anychart.onDocumentReady(function () {
	var dataSet = anychart.data.set(getData());
	var seriesData_1 = dataSet.mapAs({'x': 0, 'value': 1});
	var chart = anychart.line();
	var title = chart.title();
	title.text('Jumlah Tender per Bulan')
	.fontFamily('Proxima Nova')
	.enabled(true)
	.fontSize('20px');
	chart.animation(true);
	//chart.padding([10, 20, 5, 20]);
	chart.crosshair()
	    .enabled(true)
	    .yLabel(false)
	    .yStroke(null);
	chart.tooltip().positionMode('point');

	// chart.yAxis().title('Number of Bottles Sold (thousands)');
	chart.xAxis().labels().padding(5);

	var series_1 = chart.line(seriesData_1);
	series_1.name('Jumlah Tender');
	series_1.hovered().markers()
	    .enabled(true)
	    .type('circle')
	    .size(4);
	series_1.tooltip()
	    .position('right')
	    .anchor('left-center')
	    .offsetX(5)
	    .offsetY(5);

	chart.legend()
		.position('bottom')
	    .enabled(true)
	    .fontSize(13)
	    .padding([15, 0, 10, 0]);

	chart.container('container1');

	chart.listen("pointClick", function(e) {
		const title = `Total Tender Tanggal ${e.target.ae.x}`;

		const date = e.target.ae.x;
		const start = moment(date, 'DD/MM/YYYY 00:00').valueOf();
		const end = moment(date+' 23:59:59', 'DD/MM/YYYY H:m:s').valueOf();

		const range = e.target.ae.x+' - '+end;
		const url = `{{url('ajax/detail-tender')}}?tender={{$filter->tender}}&status=total_tender&gte=${start}&lte=${end}`;

		$('#modal-title').html(title);
	    $('#modal-detail').modal('toggle');

	    getDataDetail(url);
	});

	chart.draw();
	});

	function getData() {
	var array = {!! json_encode($chart) !!};
	return array;
	}
</script>

<script>
    anychart.onDocumentReady(function () {
	// create pie chart with passed data
	var chart = anychart.pie(getData2());
	var title = chart.title();
	title.text('Persentase Kemenangan')
	.fontFamily('Proxima Nova')
	.enabled(true)
	.fontSize('20px');

	// set container id for the chart
	chart.container('container2');
	// initiate chart drawing
	chart.draw();
	chart.legend()
		.position('right')
	    .enabled(true)
	    .fontSize(13)
	    .padding([15, 0, 10, 0]);

	});

	function getData2() {
	var array = {!! json_encode($chart1) !!};
	return array;
	}

</script>

<script>
    function getDetailData(title, status) {
    $('#modal-title').html(title);
    $('#modal-detail').modal('toggle');

    getDataDetail('{{url('ajax/detail-tender')}}?daterange={{$filter->daterange}}&tender={{$filter->tender}}&status='+status);
}


function getDataDetail(url) {
    $('#detail-container').html(`
        <div class="m-y-lg text-center"><i class="fa fa-spinner fa-spin fa-3x fa-fw"></i>
        <br><br><span>Memuat Data...</span></div>
    `);

    $.ajax({
        type: 'GET',
        url: url,
        success: function(data) {
            $('#detail-container').html(data);
        },
        error: function(error) {
            $('#detail-container').html(`<div class="add-customers-screen tbl">
                        <div class="add-customers-screen-in">
                            <div class="add-customers-screen-user">
                                <i class="font-icon fa fa-exclamation-circle text-danger"></i>
                            </div>
                            <h6>Terjadi kesalahan.</h6>
                        </div>
                    </div>`);
        }
    })
}
</script>
@endsection
