@if($total > 0)
<div class="row">
	<section class="card m-x-md">
		<div class="card-block">
			<span class="semibold">Total Data:</span> {{$total}} <br>
			<span class="semibold">Halaman:</span> {{$paginator->current_page }} dari {{$paginator->last_page }}
		</div>
	</section>

	@foreach($data as $key => $var)
		@php
			$val = $var->_source;
		@endphp
		<section class="card m-x-md">
			@if($type == "evaluasi")
				<div class="card-block">
					<div class="row">
						<div class="col-md-4 col-lg-3">
							<label class="semibold">Nama Paket</label>
						</div>
						<div class="col-md-8 col-lg-9">
							<a href="{{$val->link}}" class="normal" target="_blank">{{$val->nama_paket}}</a>
						</div>
					</div>

					<div class="row">
						<div class="col-md-4 col-lg-3">
							<label class="semibold">Tahap</label>
						</div>
						<div class="col-md-8 col-lg-9">
							{{isset($val->tahap_tender_saat_ini->info_tahap_paket) ? $val->tahap_tender_saat_ini->info_tahap_paket : $val->tahap_tender_saat_ini->info_tahap_tender}}
						</div>
					</div>

					<div class="row">
						<div class="col-md-4 col-lg-3">
							<label class="semibold">Kode</label>
						</div>
						<div class="col-md-8 col-lg-9">
							<span>{{$val->kode_paket}}</span>
						</div>
					</div>

					<div class="row">
						<div class="col-md-4 col-lg-3">
							<label class="semibold">Kategori</label>
						</div>
						<div class="col-md-8 col-lg-9">
							<span>{{$val->kategori}}</span>
						</div>
					</div>

					<div class="row">
						<div class="col-md-4 col-lg-3">
							<label class="semibold">Akhir Pendaftaran</label>
						</div>
						<div class="col-md-8 col-lg-9">
							<span>
								{{date("d/m/Y H:i", $val->akhir_pendaftaran/1000)}}
							</span>
						</div>
					</div>

					<div class="row">
						<div class="col-md-4 col-lg-3">
							<label class="semibold">Instansi</label>
						</div>
						<div class="col-md-8 col-lg-9">
							<span>{{$val->instansi}}</span>
						</div>
					</div>

					<div class="row">
						<div class="col-md-4 col-lg-3">
							<label class="semibold">Kualifikasi Usaha</label>
						</div>
						<div class="col-md-8 col-lg-9">
							<span>{{$val->kualifikasi_usaha}}</span>
						</div>
					</div>

					<div class="row">
						<div class="col-md-4 col-lg-3">
							<label class="semibold">Nilai HPS</label>
						</div>
						<div class="col-md-8 col-lg-9">
							<span>{{"Rp " . number_format(intval($val->nilai_hps),2,',','.')}}</span>
						</div>
					</div>

					<div class="row">
						<div class="col-md-4 col-lg-3">
							<label class="semibold">Status Akhir</label>
						</div>
						<div class="col-md-8 col-lg-9">
							@if($val->status_pemenang_akhir == "menang")
								<span class="label label-primary">Menang</span>
							@endif

							@if($val->status_pemenang_akhir == "kalah")
								<span class="label label-danger">Kalah</span>
							@endif
						</div>
					</div>
				</div>
			@endif

			@if($type == "selesai")
				<div class="card-block">
					<div class="row">
						<div class="col-md-4 col-lg-3">
							<label class="semibold">Nama Paket</label>
						</div>
						<div class="col-md-8 col-lg-9">
							<a href="{{$val->link}}" class="normal" target="_blank">{{$val->nama_paket}}</a>
						</div>
					</div>

					<div class="row">
						<div class="col-md-4 col-lg-3">
							<label class="semibold">Tahap</label>
						</div>
						<div class="col-md-8 col-lg-9">
							<span class="label label-success">Selesai</span>
						</div>
					</div>

					<div class="row">
						<div class="col-md-4 col-lg-3">
							<label class="semibold">Kode</label>
						</div>
						<div class="col-md-8 col-lg-9">
							<span>{{$val->kode_paket}}</span>
						</div>
					</div>

					<div class="row">
						<div class="col-md-4 col-lg-3">
							<label class="semibold">Kategori</label>
						</div>
						<div class="col-md-8 col-lg-9">
							<span>{{$val->kategori}}</span>
						</div>
					</div>

					<div class="row">
						<div class="col-md-4 col-lg-3">
							<label class="semibold">Akhir Pendaftaran</label>
						</div>
						<div class="col-md-8 col-lg-9">
							<span>
								@if($val->akhir_pendaftaran)
								{{date("d/m/Y H:i", $val->akhir_pendaftaran/1000)}}
								@else
								-
								@endif
							</span>
						</div>
					</div>

					<div class="row">
						<div class="col-md-4 col-lg-3">
							<label class="semibold">Instansi</label>
						</div>
						<div class="col-md-8 col-lg-9">
							<span>{{$val->instansi}}</span>
						</div>
					</div>

					<div class="row">
						<div class="col-md-4 col-lg-3">
							<label class="semibold">Kualifikasi Usaha</label>
						</div>
						<div class="col-md-8 col-lg-9">
							<span>{{$val->kualifikasi_usaha}}</span>
						</div>
					</div>

					<div class="row">
						<div class="col-md-4 col-lg-3">
							<label class="semibold">Nilai HPS</label>
						</div>
						<div class="col-md-8 col-lg-9">
							<span>{{"Rp " . number_format(intval($val->nilai_hps),2,',','.')}}</span>
						</div>
					</div>
				</div>
			@endif

			@if($type == "pengumuman")
				<div class="card-block">
					<div class="row">
						<div class="col-md-4 col-lg-3">
							<label class="semibold">Nama Paket</label>
						</div>
						<div class="col-md-8 col-lg-9">
							<a href="{{$val->link}}" class="normal" target="_blank">{{$val->nama_paket}}</a>
						</div>
					</div>

					<div class="row">
						<div class="col-md-4 col-lg-3">
							<label class="semibold">Tahap</label>
						</div>
						<div class="col-md-8 col-lg-9">
							{{isset($val->tahap_tender_saat_ini->info_tahap_paket) ? $val->tahap_tender_saat_ini->info_tahap_paket : $val->tahap_tender_saat_ini->info_tahap_tender}}
						</div>
					</div>

					<div class="row">
						<div class="col-md-4 col-lg-3">
							<label class="semibold">Kode</label>
						</div>
						<div class="col-md-8 col-lg-9">
							<span>{{$val->kode_paket}}</span>
						</div>
					</div>

					<div class="row">
						<div class="col-md-4 col-lg-3">
							<label class="semibold">Kategori</label>
						</div>
						<div class="col-md-8 col-lg-9">
							<span>{{$val->kategori}}</span>
						</div>
					</div>

					<div class="row">
						<div class="col-md-4 col-lg-3">
							<label class="semibold">Akhir Pendaftaran</label>
						</div>
						<div class="col-md-8 col-lg-9">
							<span>
								{{date("d/m/Y H:i", $val->akhir_pendaftaran/1000)}}
							</span>
						</div>
					</div>

					<div class="row">
						<div class="col-md-4 col-lg-3">
							<label class="semibold">Instansi</label>
						</div>
						<div class="col-md-8 col-lg-9">
							<span>{{$val->instansi}}</span>
						</div>
					</div>

					<div class="row">
						<div class="col-md-4 col-lg-3">
							<label class="semibold">Kualifikasi Usaha</label>
						</div>
						<div class="col-md-8 col-lg-9">
							<span>{{$val->kualifikasi_usaha ? $val->kualifikasi_usaha : '-'}}</span>
						</div>
					</div>

					<div class="row">
						<div class="col-md-4 col-lg-3">
							<label class="semibold">Info Tender</label>
						</div>
						<div class="col-md-8 col-lg-9">
							<span>{{$val->info}}</span>
						</div>
					</div>

					<div class="row">
						<div class="col-md-4 col-lg-3">
							<label class="semibold">Nilai HPS</label>
						</div>
						<div class="col-md-8 col-lg-9">
							<span>{{"Rp " . number_format(intval($val->nilai_hps),2,',','.')}}</span>
						</div>
					</div>
				</div>
			@endif

			@if($type == "peserta")
				<div class="card-block">
					<div class="row">
						<div class="col-md-4 col-lg-3">
							<label class="semibold">Nama Peserta</label>
						</div>
						<div class="col-md-8 col-lg-9">
							<label class="semibold">{{$val->nama}}</label>
						</div>
					</div>

					<div class="row">
						<div class="col-md-4 col-lg-3">
							<label class="semibold">NPWP</label>
						</div>
						<div class="col-md-8 col-lg-9">
							<span>{{$val->npwp}}</span>
						</div>
					</div>
				</div>
			@endif
		</section>
	@endforeach
	<div class="col-12 mt-3 p-x-md">
	    <nav>
			<ul class="pagination pagination-sm">
				@php
				for ($i=0; $i <= 2; $i++) {
					if($paginator->current_page - $i > 0) $start = $paginator->current_page - $i;
					if($paginator->current_page + $i <= $paginator->last_page) $end = $paginator->current_page + $i;
				}
				@endphp

				@if($paginator->current_page > 1)
				<li class="page-item">
					<a class="page-link" href="javascript:void(0)" onclick="getDataDetail('{{$url}}&page={{$paginator->current_page-1}}')" aria-label="Previous">
						<span aria-hidden="true">«</span>
						<span class="sr-only">Previous</span>
					</a>
				</li>
				@endif
				@for($i = $start; $i <= $end; $i++)
					@if($paginator->current_page == $i)
						<li class="page-item active">
							<a class="page-link cursor-default" href="javascript:void(0)">{{$i}}</a>
						</li>
					@else
						<li class="page-item">
							<a class="page-link" href="#" onclick="getDataDetail('{{$url}}&page={{$i}}')">
								{{$i}}
							</a>
						</li>
					@endif
				@endfor
				@if($paginator->current_page < $paginator->last_page)
				<li class="page-item">
					<a class="page-link" href="javascript:void(0)" onclick="getDataDetail('{{$url}}&page={{$paginator->current_page+1}}')" aria-label="Next">
						<span aria-hidden="true">»</span>
						<span class="sr-only">Next</span>
					</a>
				</li>
				@endif
			</ul>
		</nav>
	</div>
</div>
@else
<div class="add-customers-screen tbl">
    <div class="add-customers-screen-in">
        <div class="add-customers-screen-user">
            <i class="font-icon fa fa-database text-danger"></i>
        </div>
        <h6>Data tidak tersedia.</h6>
    </div>
</div>
@endif