@extends('layouts.default')
@section('title', 'Profile')

@section('page-css')
<link rel="stylesheet" href="{{url('public/')}}/templates/default/css/separate/vendor/bootstrap-daterangepicker.min.css">
<link rel="stylesheet" href="{{url('public/')}}/templates/default/css/separate/pages/profile.min.css">
<link rel="stylesheet" href="{{url('public/')}}/templates/default/css/separate/pages/widgets.min.css">
@endsection

@section('styles')
<link rel="stylesheet" href="{{url('public/')}}/css/profile/default.css">

<style>
.fa-circle.blue{
    color: #00A8FF;
}
.fa-circle.yellow{
    color: #ffcc00;
} 
.foto-profil{
    height:151px;
    background: white;
}
.box-tender{
    font-size: 10px;
}
.caret-red{
    color:  #ff1a1a;
}
.caret-green{
    color: #00ff00;
}
.table-left{
    padding-left: 15px !important;
}
.table-right{
    padding-right: 15px !important;   
}
.box-statistic1{
    border-radius: 20px;
    background-image: linear-gradient(#2acb2a, #177117); 
}
.box-statistic2{
    border-radius: 20px;
    background-image: linear-gradient(#fc2020, #861313); 
}
.box-statistic3{
    border-radius: 20px;
    background-image: linear-gradient(#fcc426, #9f5d01); 
}
.box-statistic4{
    border-radius: 20px;
    background-image: linear-gradient(#5a86e6, #485f92); 
}
.statistic-box .number{
    font-size: 40px !important; 
}
.card-waktu{
    height: 50px;   
}
.kz-pageprofilcard{
    shape-rendering: 250px !important;
}
.kz-table-desc {
    padding-top: 0 !important; 
}
.widget-accordion .panel-heading a[aria-expanded=true]{
    color:black !important;
}
.radius{
    border-radius: 0;
    border: 0;
    padding-bottom: 0; 
}
.kz-shadow{
    box-shadow: 0 8px 24px #d0dae2;
}
</style>

@endsection

@section('content')
<div class="container">
    <div class="row p-t-0"" >
        <!-- Search Bar -->
        <div class="col-md-12">
            <div class="card kz-shadow m-b-1">
                {{-- @foreach ($nama as $name) --}}
                <div class="card col-md-6" style="padding: 7px;">
                    <p class="mt-12">
                    <h5 style="margin-left: 15px;" > <i class="fa fa-circle blue"></i>  t</h5>
                    </p>
                </div>
                {{-- @endforeach --}}
                <div class="card col-md-6" style="padding: 7px;">
                    <p class="mt-12">
                    <h5 style="margin-left: 15px;"> <i class="fa fa-circle yellow"></i>   u</h5>
                    </p>
                </div>       
                
                
            </div>
        </div>
        <!-- Profile-->
        <div class="col-md-12">
            <div class="card kz-shadow m-b-1" style="border-radius: 0 0 20px 20px ">
                <div class="card-block" style="padding: 0 0.9em 0 0.9em;">
                    <div class="row m-b-1">
                        <div class="col-md-6">
                             <div class="col-md-4 foto-profil">
                                <section class="kz-border-0 m-b-0">
                                    <div class="profile-card">
                                        <div class="profile-card-photo" style="width: 79px; height: 63px;">
                                            <img src="{{url('public/img/user(1).png')}}">
                                        </div>
                                        <div class="profile-card-name text-right m-t-1">#1</div>
                                    </div>
                                    <!--.profile-card-->
                                </section>
                                <!--.box-typical-->
                            </div>
                            <!--.col-->
                            <div class="col-md-8">
                                <div class="row">
                                    <div class="col-md-12" style="padding-top:15px;">
                                    <h4> <b>tel</b> </h4>
                                    </div>
                                </div>

                                <div class="row" style="margin-top: 0">
                                    <div class="col-md-12 card m-b-0 radius" >
                                        <div>
                                            <b>
                                            <h6 style="margin-bottom: 9px;
                                                margin-top: 10px;"><b>Bidang</b></h6>
                                            <p style="margin-bottom:0.4rem;">Pengadaan Barang, Jasa Lainnya, Pekerjaan
                                                Konstruksi.
                                                Jasa Konsultansi Badan Usaha.
                                            </p>
                                            </b>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="col-md-4 foto-profil">
                                <section class="kz-border-0 m-b-0">
                                    <div class="profile-card">
                                        <div class="profile-card-photo" style="width: 79px; height: 63px;">
                                            <img src="{{url('public/img/user(1).png')}}">
                                        </div>
                                        <div class="profile-card-name text-right m-t-1">#2</div>
                                    </div>
                                    <!--.profile-card-->
                                </section>
                                <!--.box-typical-->
                            </div>
                            <!--.col-->
                            <div class="col-md-8">
                                <div class="row">
                                    <div class="col-md-12" style="padding-top:15px;">
                                        <h4> <b>Binokular</b> </h4>
                                    </div>
                                </div>

                                <div class="row" style="margin-top: 0">
                                    <div class="col-md-12 card m-b-0 radius" >
                                        <div>
                                            <b>
                                            <h6 style="margin-bottom: 9px;
                                                margin-top: 10px;"><b>Bidang</b></h6>
                                            <p style="margin-bottom:0.4rem;">Pengadaan Barang, Jasa Lainnya, Pekerjaan
                                                Konstruksi.
                                                Jasa Konsultansi Badan Usaha.
                                            </p>
                                            </b>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    {{-- <div class="row" style=""> --}}
                        <b>
                        <div class="card col-md-2 m-b-0 radius">
                            <div class="text-center">
                                <span class="box-tender">Tender Diikuti</span><br>
                                <p class="mt-12" style="margin-top: 20px">
                                    7.763    <i class="fa fa-caret-down caret-red" ></i>   7.763
                                </p>
                            </div>
                        </div>
                        <div class="card col-md-2 m-b-0 radius">
                            <div class="text-center">
                                <span class="box-tender">Dalam Proses</span>
                                <p class="mt-12" style="margin-top: 20px">
                                    163
                                    <i class="fa fa-caret-down caret-red"></i>
                                    100
                                </p>
                            </div>
                        </div>
                        <div class="card col-md-2 m-b-0 radius">
                            <div class="text-center">
                                <span class="box-tender">Tender Dimenangkan</span><br>
                                <p class="mt-12" style="margin-top: 20px">
                                    32.78% 
                                    <i class="fa fa-caret-up caret-green"></i>
                                    33.57%
                                </p>
                            </div>
                        </div>
                        </b>
                        <div class="col-md-6">
                            <div class="row">
                                <div class="card kz-border-0 m-b-0">
                                    <div class="card-block p-t-0 p-b-0">
                                        <div class="col-md-6">
                                            <span class="label label-danger m-b-1"> K</span>
                                                7163
                                                <i class="fa fa-caret-down caret-red"></i>
                                                100 
                                        </div>
                                        <div class="col-md-6 m-b-1">
                                                <span class="label label-danger"> B</span>
                                                7163
                                                <i class="fa fa-caret-down caret-red"></i>
                                                100
                                        </div>
                                        <div class="col-md-6 m-b-1">
                                           <span class="label label-primary"> A</span>
                                                7163
                                                <i class="fa fa-caret-down caret-red"></i>
                                                100
                                        </div>
                                        <div class="col-md-6 m-b-1">
                                            <span class="label label-primary">T</span>
                                                7163
                                                <i class="fa fa-caret-down caret-red"></i>
                                                100
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    {{-- </div> --}}

                </div>
            </div>

    <!-- Card -->
    <div class="row">
        <div class="col-md-12" style="padding:0px;">
            <div class="card kz-bg-transparent border-0 m-b-1">
                <div class="card-block" style="padding:0px;">
                    <div class="col-md-3 col-sm-6">
                        <article class="statistic-box m-b-0 box-statistic1 kz-shadow">
                            <div>
                                <div class="caption">
                                    <div>Menang</div>
                                </div>
                                <div class="number kz-number">
                                   7163
                                    <i class="fa fa-caret-down caret-red"></i>
                                    100
                                </div>
                            </div>
                        </article>
                    </div>
                    <!--.col-->
                    <div class="col-md-3 col-sm-6">
                        <article class="statistic-box m-b-0 box-statistic2 kz-shadow">
                            <div>
                                <div class="caption">
                                    <div>Kalah</div>
                                </div>
                                <div class="number kz-number">
                                    7163
                                    <i class="fa fa-caret-down caret-red"></i>
                                    100
                                </div>
                            </div>
                        </article>
                    </div>
                    <!--.col-->
                    <div class="col-md-3 col-sm-6">
                        <article class="statistic-box m-b-0 box-statistic3 kz-shadow">
                            <div>
                                <div class="caption">
                                    <div>Selesai</div>
                                </div>
                                <div class="number kz-number">
                                    7163
                                    <i class="fa fa-caret-down caret-red"></i>
                                    100
                                </div>
                            </div>
                        </article>
                    </div>
                    <!--.col-->
                    <div class="col-md-3 col-sm-6">
                        <article class="statistic-box m-b-0 box-statistic4 kz-shadow">
                            <div>
                                <div class="caption">
                                    <div>Rataan HPS</div>
                                </div>
                                <div class="number kz-number">
                                    80%
                                    <i class="fa fa-caret-up caret-green"></i>
                                    82%
                                </div>
                            </div>
                        </article>
                    </div>
                    <!--.col-->
                </div>
            </div>
        </div>
    </div>


    <div class="row">
        <!-- kalender -->
        <div class="col-md-12">
            <div class="card kz-border-0 kz-shadow m-b-1" style="padding: 7px;">
                <div class="col-md-6">
                    <h5 class="" style="margin-top:7px;">Waktu</h5>
                </div>
                <div class="offset-8 kzcalen">
                    <div class="form-group m-b-0">
                        <div class="input-group date">
                            <input id="daterange2" type="text" value="01/01/2020 - 01/31/2020"
                                class="form-control media-middle" style="font-size: 11px;">
                            <span class="input-group-addon">
                                <i class="font-icon font-icon-calend"></i>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Grafik 1 -->
        <div class="col-md-12">
            <div class="card kz-shadow m-b-1">
                <div class="kz-pageprofilcard" style="height: 400px" id="container" ></div>
            </div>
        </div>
        <!-- Grafik 2 -->
        <div class="col-md-12">
            <div class="card kz-shadow m-b-1">
                <div class="kz-pageprofilcard" style="height: 400px" id="container1" ></div>
            </div>
        </div>
        <!-- Kategori -->
        <div class="col-md-12">
            <section class="box-typical box-typical-max-280 kz-shadow m-b-1"">
                <header class="box-typical-header">
                    <div class="tbl-row">
                        <div class="tbl-cell">
                            <h3 style="margin-bottom: 0px;">Kategori</h3>
                            <small class="kz-table-desc">Berdasarkan Jumlah kemenangan</small>
                        </div>
                    </div>
                </header>
                <section class="widget widget-accordion" id="accordion" role="tablist" aria-multiselectable="true">
                    <article class="panel">
                        <div class="panel-heading " role="tab" id="headingOne">
                            <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true"
                                aria-controls="collapseOne" class="collapsed">
                                <div class="tbl">
                                    <div class="tbl-row">
                                        <div class="col-md-5">
                                            Jasa Lainnya
                                        </div>
                                        <div class="col-md-6 text-right">
                                            1500 Menang
                                            <i class="fa fa-caret-up caret-green"></i>
                                            1507 Menang
                                        </div>
                                        <div class="col-md-1 text-right">
                                            #5
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </article>
                    <article class="panel">
                        <div class="panel-heading" role="tab" id="headingOne">
                            <a data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false"
                                aria-controls="collapseTwo" class="collapsed">
                                <div class="tbl">
                                    <div class="tbl-row">
                                        <div class="col-md-5 col-sm-5">
                                            Pengadaan Barang
                                        </div>
                                        <div class="col-md-6 text-right">
                                            1500 Menang
                                            <i class="fa fa-caret-up caret-green"></i>
                                            1507 Menang
                                        </div>
                                        <div class="col-md-1 col-sm-1 text-right">
                                            #14
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </article>
                    <article class="panel">
                        <div class="panel-heading" role="tab" id="headingThree">
                            <a data-toggle="collapse" data-parent="#accordion" href="#collapseThree"
                                aria-expanded="false" aria-controls="collapseThree" class="collapsed">
                                <div class="tbl">
                                    <div class="tbl-row">
                                        <div class="col-md-5 col-sm-5">
                                            Jasa Konsultansi Badan Usaha
                                        </div>
                                        <div class="col-md-6 text-right">
                                            1500 Menang
                                            <i class="fa fa-caret-down caret-red"></i>
                                            1400 Menang
                                        </div>
                                        <div class="col-md-1 col-sm-1 text-right">
                                            #7
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </article>
                    <article class="panel">
                        <div class="panel-heading" role="tab" id="headingFour">
                            <a data-toggle="collapse" data-parent="#accordion" href="#collapseFour"
                                aria-expanded="false" aria-controls="collapseFour" class="collapsed">
                                <div class="tbl">
                                    <div class="tbl-row">
                                        <div class="col-md-5 col-sm-5">
                                            Pekerjaan Konstruksi
                                        </div>
                                        <div class="col-md-6 text-right">
                                            1500 Menang
                                            <i class="fa fa-caret-down caret-red"></i>
                                            1400 Menang
                                        </div>
                                        <div class="col-md-1 col-sm-1 text-right">
                                            #2
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </article>
                    <article class="panel">
                        <div class="panel-heading" role="tab" id="headingFive">
                            <a data-toggle="collapse" data-parent="#accordion" href="#collapseFive"
                                aria-expanded="false" aria-controls="collapseFive" class="collapsed">
                                <div class="tbl">
                                    <div class="tbl-row">
                                        <div class="col-md-5 col-sm-5">
                                            Jasa Konstultansi Perorangan
                                        </div>
                                        <div class="col-md-6 text-right">
                                            1500 Menang
                                            <i class="fa fa-caret-down caret-red"></i>
                                            1400 Menang
                                        </div>
                                        <div class="col-md-1 col-sm-1 text-right">
                                            #10
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </article>
                </section>
            </section>
        </div>
        <!-- Tender Teratas -->
        <div class="col-md-12">
            <section class="box-typical box-typical-max-280 kz-border-0 kz-shadow m-b-1">
                <header class="box-typical-header">
                    <div class="tbl-row">
                        <div class="tbl-cell">
                            <h3 style="margin-bottom: 0px;">Tender Teratas</h3>
                            <small class="kz-table-desc">Berdasarkan nilai HPS tertinggi</small>
                        </div>
                    </div>
                </header>
                <div class="table-responsive">
                    <table class="table table-hover table-striped kz-border-0 container">
                        <tbody>
                            <tr>
                                <td class="table-left">
                                    Pengadaan Penyediaan Jasa Jaringan Komunikasi Data Tender Ulang
                                </td>
                                <td class="text-right table-right">
                                    Rp 245,20 M
                                    <i class="fa fa-circle blue"></i> 
                                </td>
                            </tr>
                            <tr>
                                <td class="table-left">
                                    Penyediaan Jasa Jaringan Komunikasi Data Tender Ulang
                                </td>
                                <td class="text-right table-right">
                                    Rp 233,47 M
                                    <i class="fa fa-circle yellow"></i> 
                                </td>
                            </tr>
                            <tr>
                                <td class="table-left">
                                    Penyedia Jasa Jaringan Komunikasi Data
                                </td>
                                <td class="text-right table-right">
                                    Rp 229,89 M
                                    <i class="fa fa-circle blue"></i> 
                                </td>
                            </tr>
                            <tr>
                                <td class="table-left">
                                    Penyedia Jasa Jaringan Komunikasi Data Tender Ulang
                                </td>
                                <td class="text-right table-right">
                                    Rp 225,33 M
                                    <i class="fa fa-circle blue"></i> 
                                </td>
                            </tr>
                            <tr>
                                <td class="table-left">
                                    Pengadaan Kegiatan Upgrade dan Pemindahan Adhyaksa Monitoring Center
                                </td>
                                <td class="text-right table-right">
                                    Rp 160,22 M
                                    <i class="fa fa-circle yellow"></i> 
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <!--.box-typical-body-->
            </section>
        </div>
        <!-- Kompetitor -->
        <div class="col-md-12">
           <div class="row">
                <div class="col-md-6">
                     <section class="box-typical  kz-border-0 kz-shadow m-b-1"">
                        <header class="box-typical-header">
                            <div class="tbl-row">
                               <div class="tbl-cell">
                                    <h3 style="margin-bottom: 0px;">Kompetitor Telkomsel</h3>
                                    <small class="kz-table-desc">Berdasarkan kemenangan pada instansi dan kategori
                                            yang
                                            sama</small>
                                </div>
                            </div>
                        </header>
                        <div class="box-typical-body">
                            <div class="table-responsive">
                                <table class="table table-hover table-striped">
                                    <tbody>
                                        <tr>
                                            <td class="table-left">
                                                PT. Abadi Laju Sejahtera
                                            </td>
                                            <td class="text-right table-right">
                                                1.167 Menang
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="table-left">
                                                PT. Rajawali Nusindo
                                            </td>
                                            <td class="text-right table-right">
                                                1.057 Menang
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="table-left">
                                                PT. Scalarindo Utama Consult
                                            </td>
                                            <td class="text-right table-right">
                                                852 Menang
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="table-left">
                                                PT. Adizha Marathon
                                            </td>
                                            <td class="text-right table-right">
                                                832 Menang
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="table-left">
                                                PT. Intimulya Multikencana
                                            </td>
                                            <td class="text-right table-right">
                                                729 Menang
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <!--.box-typical-body-->
                    </section>
                </div>
                <div class="col-md-6">
                     <section class="box-typical  kz-border-0 kz-shadow m-b-1"">
                        <header class="box-typical-header">
                            <div class="tbl-row">
                               <div class="tbl-cell">
                                    <h3 style="margin-bottom: 0px;">Kompetitor Binokular</h3>
                                    <small class="kz-table-desc">Berdasarkan kemenangan pada instansi dan kategori
                                            yang
                                            sama</small>
                                </div>
                            </div>
                        </header>
                        <div class="box-typical-body">
                            <div class="table-responsive">
                                <table class="table table-hover table-striped">
                                    <tbody>
                                        <tr>
                                            <td class="table-left">
                                                PT. Abadi Laju Sejahtera
                                            </td>
                                            <td class="text-right table-right">
                                                1.167 Menang
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="table-left">
                                                PT. Rajawali Nusindo
                                            </td>
                                            <td class="text-right table-right">
                                                1.057 Menang
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="table-left">
                                                PT. Scalarindo Utama Consult
                                            </td>
                                            <td class="text-right table-right">
                                                852 Menang
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="table-left">
                                                PT. Adizha Marathon
                                            </td>
                                            <td class="text-right table-right">
                                                832 Menang
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="table-left">
                                                PT. Intimulya Multikencana
                                            </td>
                                            <td class="text-right table-right">
                                                729 Menang
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <!--.box-typical-body-->
                    </section>
                </div>
           </div>
        </div>
    </div>
</div>
@endsection

@section('scripts')
<script type="text/javascript" src="{{url('public/templates/default')}}/js/lib/moment/moment-with-locales.min.js">
</script>
<script type="text/javascript"
    src="{{url('public/templates/default')}}/js/lib/eonasdan-bootstrap-datetimepicker/bootstrap-datetimepicker.min.js">
</script>
<script src="{{url('public/templates/default')}}/js/lib/clockpicker/bootstrap-clockpicker.min.js"></script>
<script src="{{url('public/templates/default')}}/js/lib/clockpicker/bootstrap-clockpicker-init.js"></script>
<script src="{{url('public/templates/default')}}/js/lib/daterangepicker/daterangepicker.js"></script>
<script src="{{url('public/templates/default')}}/js/lib/bootstrap-select/bootstrap-select.min.js"></script>

<script type="text/javascript" src="{{url('public/templates/default')}}/js/lib/jqueryui/jquery-ui.min.js"></script>
<script type="text/javascript" src="{{url('public/templates/default')}}/js/lib/lobipanel/lobipanel.min.js"></script>
<script type="text/javascript" src="{{url('public/templates/default')}}/js/lib/match-height/jquery.matchHeight.min.js">
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js">
</script>
<script type="text/javascript" src="{{url('public/')}}/js/profile/chart.js"></script>

<script src="{{url('public/templates/default')}}/js/lib/jqueryui/jquery-ui.min.js"></script>
<script src="https://cdn.anychart.com/releases/v8/js/anychart-base.min.js?hcode=c11e6e3cfefb406e8ce8d99fa8368d33">
</script>
<script src="https://cdn.anychart.com/releases/v8/js/anychart-ui.min.js?hcode=c11e6e3cfefb406e8ce8d99fa8368d33">
</script>
<script src="https://cdn.anychart.com/releases/v8/js/anychart-exports.min.js?hcode=c11e6e3cfefb406e8ce8d99fa8368d33">
</script>
<script
    src="https://cdn.anychart.com/releases/v8/js/anychart-data-adapter.min.js?hcode=c11e6e3cfefb406e8ce8d99fa8368d33">
</script>
<script src="https://cdn.anychart.com/js/v8/graphics.min.js"></script>

<script>
    $(document).ready(function(){
        loadChart();
        loadCalendar();
    });

    function loadChart() {
        anychart.onDocumentReady(function () {
            // create data set on our data
            var dataSet = anychart.data.set(getData());

            // map data for the first series, take x from the zero column and value from the first column of data set
            var seriesData_1 = dataSet.mapAs({ 'x': 0, 'value': 1 });

            // map data for the second series, take x from the zero column and value from the second column of data set
            var seriesData_2 = dataSet.mapAs({ 'x': 0, 'value': 2 });
            // create line chart
            var chart = anychart.line();

            // install theme
            anychart.theme(customTheme);

            // turn on chart animation
            chart.animation(true);

            // set chart padding
            chart.padding([10, 20, 5, 20]);

            // turn on the crosshair
            chart.crosshair()
                .enabled(true)
                .yLabel(false)
                .yStroke(null);

            // set tooltip mode to point
            chart.tooltip().positionMode('point');

            // set chart title text settings
            var title = chart.title();
            title.text('Pergerakan Aktivitas Tender Aktif');
            title.fontFamily('Proxima Nova');
            title.enabled(true);
            title.fontSize('24px')

            // set yAxis title
            // chart.yAxis().title('Number of Bottles Sold (thousands)');
            // chart.xAxis().labels().padding(5);

            // create first series with mapped data
            var series_1 = chart.line(seriesData_1);
            series_1.name('Tender Aktif');
            series_1.hovered().markers()
                .enabled(true)
                .type('circle')
                .size(4);
            series_1.stroke({
                color: "#00A8FF"
            });
            series_1.tooltip()
                .position('right')
                .anchor('left-center')
                .offsetX(5)
                .offsetY(5);

            // create second series with mapped data
            var series_2 = chart.line(seriesData_2);
            series_2.name('Tender Dimenangkan');
            series_2.hovered().markers()
                .enabled(true)
                .type('circle')
                .size(4);
            series_2.stroke({
                color: "#ffcc00"
            });
            series_2.tooltip()
                .position('right')
                .anchor('left-center')
                .offsetX(5)
                .offsetY(5);

            // turn the legend on
            // chart.legend()
            //     .enabled(true)
            //     .fontFamily('Proxima Nova')
            //     .fontSize(13)
            //     .position('bottom')
            //     .align('center')
            //     .padding([30, 0, 10, 0]);

            // set container id for the chart
            chart.container('container');
            // initiate chart drawing
            chart.draw();
        });

        function getData() {
            return [
                ['Jan', 20, 11],
                ['Feb', 41, 24],
                ['Mar', 23, 11],
                ['Apr', 42, 32],
                ['Mei', 53, 52],
                ['Jun', 57, 42],
                ['Jul', 11, 7],
                ['Agu', 35, 15],
                ['Sep', 24, 22],
                ['Okt', 52, 43],
                ['Nov', 33, 22],
                ['Des', 21, 13]
            ]
        }
    }
</script>

<script>
    $(document).ready(function(){
        loadChart1();
        loadCalendar();
    });

    function loadChart1() {
        anychart.onDocumentReady(function () {
            // create data set on our data
            var dataSet = anychart.data.set(getData());

            // map data for the first series, take x from the zero column and value from the first column of data set
            var seriesData_1 = dataSet.mapAs({ 'x': 0, 'value': 1 });

            // map data for the second series, take x from the zero column and value from the second column of data set
            var seriesData_2 = dataSet.mapAs({ 'x': 0, 'value': 2 });
            // create line chart
            var chart = anychart.line();

            // install theme
            anychart.theme(customTheme);

            // turn on chart animation
            chart.animation(true);

            // set chart padding
            chart.padding([10, 20, 5, 20]);

            // turn on the crosshair
            chart.crosshair()
                .enabled(true)
                .yLabel(false)
                .yStroke(null);

            // set tooltip mode to point
            chart.tooltip().positionMode('point');

            // set chart title text settings
            var title = chart.title();
            title.text('Pergerakan Aktivitas Menang Tender');
            title.fontFamily('Proxima Nova');
            title.enabled(true);
            title.fontSize('24px')

            // set yAxis title
            // chart.yAxis().title('Number of Bottles Sold (thousands)');
            // chart.xAxis().labels().padding(5);

            // create first series with mapped data
            var series_1 = chart.line(seriesData_1);
            series_1.name('Tender Aktif');
            series_1.hovered().markers()
                .enabled(true)
                .type('circle')
                .size(4);
            series_1.stroke({
                color: "#ffcc00"
            });
            series_1.tooltip()
                .position('right')
                .anchor('left-center')
                .offsetX(5)
                .offsetY(5);

            // create second series with mapped data
            var series_2 = chart.line(seriesData_2);
            series_2.name('Tender Dimenangkan');
            series_2.hovered().markers()
                .enabled(true)
                .type('circle')
                .size(4);
            series_2.stroke({
                color: "#00A8FF"
            });
            series_2.tooltip()
                .position('right')
                .anchor('left-center')
                .offsetX(5)
                .offsetY(5);

            // turn the legend on
            chart.legend()
                // .enabled(true)
                // .fontFamily('Proxima Nova')
                // .fontSize(13)
                // .position('bottom')
                // .align('center')
                // .padding([30, 0, 10, 0]);

            // set container id for the chart
            chart.container('container1');
            // initiate chart drawing
            chart.draw();
        });

        function getData() {
            return [
                ['Jan', 20, 11],
                ['Feb', 41, 24],
                ['Mar', 23, 11],
                ['Apr', 42, 32],
                ['Mei', 53, 52],
                ['Jun', 57, 42],
                ['Jul', 11, 7],
                ['Agu', 35, 15],
                ['Sep', 24, 22],
                ['Okt', 52, 43],
                ['Nov', 33, 22],
                ['Des', 21, 13]
            ]
        }
    }
</script>

<script>
    function loadCalendar() {
        $(function () {
            function cb(start, end) {
                $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
            }
            cb(moment().subtract(29, 'days'), moment());

            $('#daterange').daterangepicker({
                "timePicker": true,
                ranges: {
                    'Today': [moment(), moment()],
                    'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                    'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                    'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                    'This Month': [moment().startOf('month'), moment().endOf('month')],
                    'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
                },
                "linkedCalendars": false,
                "autoUpdateInput": false,
                "alwaysShowCalendars": true,
                "showWeekNumbers": true,
                "showDropdowns": true,
                "showISOWeekNumbers": true
            });

            $('#daterange2').daterangepicker();

            $('#daterange3').daterangepicker({
                singleDatePicker: true,
                showDropdowns: true
            });

            $('#daterange').on('show.daterangepicker', function (ev, picker) {
                /*$('.daterangepicker select').selectpicker({
                    size: 10
                });*/
            });

            /* ==========================================================================
            Datepicker
            ========================================================================== */

            $('.datetimepicker-1').datetimepicker({
                widgetPositioning: {
                    horizontal: 'right',

                },
                debug: false
            });

            $('.datetimepicker-2').datetimepicker({
                widgetPositioning: {
                    horizontal: 'right'
                },
                format: 'LT',
                debug: false
            });
        });
    }
</script>
@endsection
