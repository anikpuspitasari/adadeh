@extends('layouts.default')
@section('title', 'Profile')

@section('page-css')
<link rel="stylesheet" href="{{url('public/')}}/templates/default/css/separate/vendor/bootstrap-daterangepicker.min.css">
<link rel="stylesheet" href="{{url('public/')}}/templates/default/css/separate/pages/profile.min.css">
<link rel="stylesheet" href="{{url('public/')}}/templates/default/css/separate/pages/widgets.min.css">
<link href="{{url('public/')}}/templates/default/css/separate/pages/others.min.css" rel="stylesheet" type="text/css">
@endsection

@section('styles')
<link rel="stylesheet" href="{{url('public/')}}/css/profile/default.css">

<style>
        .fa-circle.blue{
            color: #00A8FF;
        }
        .detail-profil{
            border-top: 0 !important;
        }
        .btn-search{
            border-radius: 50px;
            margin-left: 40%;
        }
        .foto-profil{
            border-radius: 20px 0 0 0;
            border: 1px solid rgba(0,0,0,.125);
            height:149px;
            background: white;
        }
        .box-tender{
            font-size: 10px;
        }
        .table-left{
            padding-left: 15px !important;
        }
        .table-right{
            padding-right: 15px !important;
        }
        .box-statistic1{
            border-radius: 20px;
            background-image: linear-gradient(#2acb2a, #177117);
        }
        .box-statistic2{
            border-radius: 20px;
            background-image: linear-gradient(#fc2020, #861313);
        }
        .box-statistic3{
            border-radius: 20px;
            background-image: linear-gradient(#fcc426, #9f5d01);
        }
        .box-statistic4{
            border-radius: 20px;
            background-image: linear-gradient(#5a86e6, #485f92);
        }
        .card-waktu{
            height: 50px;
        }
        .kz-pageprofilcard{
            shape-rendering: 250px !important;
        }
        .kz-table-desc {
            padding-top: 0 !important;
        }
        .widget-accordion .panel-heading a[aria-expanded=true]{
            color:black !important;
        }
        .radius{
            border-radius: 0;
        }
        .kz-shadow{
            box-shadow: 0 8px 24px #d0dae2;
        }

        .cursor-pointer{
            cursor: pointer;
        }
        /* input[type=text] {
        width: 100%;
        padding: 12px 20px;
        margin: 8px 0;
        box-sizing: border-box;
        } */
</style>

@endsection

@section('content')
<div class="container">
    <div class="row p-t-0">
        {{-- <!-- Search Bar sebelum Search-->
        <div id="container2" style="display:block;">
            <div class="row">
                <div class="col-md-12">
                    <div class="card" style="border-radius:50px;">
                        <div class="card-block">
                            <div class="col-md-8 offset-md-2">
                                <div class="search">
                                    <div class="form-control-wrapper form-control-icon-right">
                                        <input type="text" id="search-namaPerusahaan" class="form-control form-control-rounded"
                                            placeholder="Cari nama perusahaan di sini" value="{{$filter->namaPerusahaan}}">
                                        <span id="searchBtn" role="button" onclick="toggle()" class="fa fa-search"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <input type="hidden" id="dtp_input2" value="/" ondblclick="show">
            </div>
        </div> --}}

        

        <!-- Search Bar setelah Search-->
        <div class="row"  id="container3" >
            <div class="col-md-12">
                <div class="card kz-shadow m-b-1">
                    <div class="card col-md-6" style="padding: 3px;" > 
                        <div style="margin-top:16px;">

                            <h5 style="margin-left: 15px;margin-bottom:11px;s">
                                
                                <div class="input-group">
                                    <span class="input-group-addon" id="basic-addon1" style="background-color: transparent;
                                    border: none;"><i class="fa fa-circle blue"></i></span>
                                    <input style="border:none;" class="form-control" type="text" id="search-namaPerusahaan"  placeholder="Cari Nama Perusahaan Disini" value="{{$filter->namaPerusahaan}}">
                                </div>
                                {{-- <input style="border:none;" class="form-control" type="text" id="search-namaPerusahaan"  placeholder="Cari nama perusahaannnnnnnnnnnnnnnnnnnn" value="{{$filter->namaPerusahaan}}">
                                <span id="searchBtn" role="button" onclick="toggle()"></span> --}}
                            </h5>
                        </div>
                        
                            {{-- <p class="mt-12">
                            <h5 style="margin-left: 15px;"> <i class="fa fa-circle blue"></i>{{$nama}}</h5>
                            </p> --}}
                    </div>
                
                    <div class="card col-md-6">
                        <p class="mt-12"> 
                            <div class="" onclick="show()" id="edit2" style="height: 37px;">
                                <i class="fa fa-plus" style="padding: 13px;"></i>    Bandingkan
                            </div>
                            <form action="{{url('/profile/komparasi')}}" id="form-komparasi" method="get"> 
                            <div class="input-group" style="display: none;" id="edit1">
                                <span class="input-group-addon" id="basic-addon1" style="background-color: transparent;
                                border: none;"><i class="fa fa-circle yellow"></i></span>
                                <input style="border:none;" class="form-control" type="text" id="search-namaPerusahaan2" placeholder="Masukan Perusahaan Disini">
                            </div>
                            <input type="hidden" name="namaPerusahaan1" id="namaPerusahaanKomparas1">
                            <input type="hidden" name="namaPerusahaan2" id="namaPerusahaanKomparasi2">
                            {{-- <button type="submit">Submit</button> --}}
                            </form>
                        </p>
                    </div>

                    {{-- <div class="card col-md-6" style="padding: 7px;">
                        <p class="mt-12"> 
                            <a href="{{url('/profile/komparasi')}}"><h5 style="margin-left: 15px;"><i class="fa fa-plus"></i>    Bandingkan</h5></a>
                        </p>
                    </div> --}}
                </div>
            </div>
        </div>
    </div>

    <div id="container1" style="display:block;" class="row">


        <!-- Profile-->
        <div class="row">
            <div class="col-md-12">
                <div class="card kz-shadow m-b-1" style="border-radius: 20px 20px 70px 20px">
                    <div class="card-block" style="padding-bottom: 0em; padding-top: 0px; padding-left: 0.9em; padding-right: 0.9em">
                        <div class="row">
                            <div class="col-md-2 foto-profil" style="border-top-width: 0px;">
                                <section class="box-typical kz-border-0 m-b-0">
                                    <div class="profile-card">
                                        <div class="profile-card-photo" style="width: 79px; height: 63px;">
                                            <img src="{{url('public/img/user(1).png')}}">
                                            <div class="profile-card-name text-right m-t-0">#1</div>
                                            <!-- <h2>Rank <br>
                                            #1</h2> -->
                                        </div>
                                    </div>
                                </section>
                            </div>

                            <div class="col-md-10">
                                <div class="row">
                                    <div class="col-md-12" style="padding-top:15px;">
                                        <h4> <b>{{$nama}}</b> </h4>
                                    </div>
                                </div>

                                <div class="row" style="margin-top: 0">
                                    <div class="col-md-6 card m-b-0 radius" style="height: 89px" >
                                        <div>
                                            <b>
                                            <h6 style="margin-bottom: 9px; margin-top: 10px;"><b>Bidang</b></h6>
                                            <p style="margin-bottom:0.4rem;">{{$kategori}}
                                            </p>
                                            </b>
                                        </div>
                                    </div>
                                    <b>
                                        <div class="card col-md-2 m-b-0 radius">
                                            <div class="text-center">
                                                <span class="box-tender">Tender Diikuti</span>
                                                <p class="mt-12">
                                                    <h3> {{$diikuti}} </h3>
                                                </p>
                                            </div>
                                        </div>
                                        <div class="card col-md-2 m-b-0 radius">
                                            <div class="text-center">
                                                <span class="box-tender">Dalam Proses</span>
                                                <p class="mt-12">
                                                    <h3>{{$dalamproses}}</h3>
                                                </p>
                                            </div>
                                        </div>
                                        <div class="card col-md-2 m-b-0 radius">
                                            <div class="text-center">
                                                <span class="box-tender">Tender Dimenangkan</span>
                                                <p class="mt-12">
                                                    <h3>{{round($dimenangkan,2)}}%</h3>
                                                    {{-- <a href="{{url('/profile?namaPerusahaan=' . $var->key)}}"> --}}
                                                </p>
                                            </div>
                                        </div>
                                    </b>
                                </div>
                            </div>
                        </div>
                        
                        <!--row-->
                        <div class="row">
                            <div class="col-md-6">
                                <div class="table table-responsive m-b-0">
                                    <table class="table kz-table-borderless table-xs">
                                        <tr>
                                            <th class="detail-profil"> NPWP </th>
                                            <td class="detail-profil"> {{$npwp}} </td>
                                        </tr>
                                        <tr>
                                            <th class="detail-profil"> Alamat </th>
                                            <td class="detail-profil"> {{$alamat}}</td>
                                        </tr>
                                        <tr>
                                            <th class="detail-profil"> Kontak </th>
                                            <td class="detail-profil"> - </td>
                                        </tr>
                                    </table>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="row m-b-0">
                                    <div class="card kz-border-0 m-b-0" style="border-radius: 0 0 20px 0">
                                        <div class="card-block">
                                            <div class="col-md-6 m-b-1 m-t-1" title="Evaluasi Kualifikasi">
                                                <span class="label label-danger"> K</span> Evaluasi Kualifikasi {{$evaluasi_kualifikasi}} </span>
                                            </div>
                                            <div class="col-md-6 m-b-1 m-t-1" title="Pembuktian Kualifikasi">
                                                 <span class="label label-danger"> B</span> Pembuktian Kualifikasi {{$pembuktian_kualifikasi}} </span>
                                            </div>
                                            <div class="col-md-6 m-b-1 m-t-1" title="Evaluasi Administrasi">
                                               <span class="label label-primary"> A</span> Evaluasi Administrasi {{$evaluasi_administrasi}} </span>
                                            </div>
                                            <div class="col-md-6 m-b-1 m-t-1" title="Evaluasi Teknis">
                                                <span class="label label-primary">T</span> Evaluasi Teknis {{$evaluasi_teknis}}</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Card -->
        <div class="row">
            <div class="col-md-12" style="padding:0px;">
                <div class="card kz-bg-transparent border-0 m-b-1">
                    <div class="card-block" style="padding:0px;">
                        <div class="col-md-3 col-sm-6">
                            <article class="statistic-box m-b-0 box-statistic1 kz-shadow cursor-pointer" onclick="getDetailTender('menang')">
                                <div>
                                    <div class="caption">
                                        <div>Menang</div>
                                    </div>
                                    <div class="number">{{$status_akhir->menang}}</div>
                                </div>
                            </article>
                        </div>
                        <!--.col-->
                        <div class="col-md-3 col-sm-6">
                            <article class="statistic-box m-b-0 box-statistic2 kz-shadow cursor-pointer" onclick="getDetailTender('kalah')">
                                <div>
                                    <div class="caption">
                                        <div>Kalah</div>
                                    </div>
                                    <div class="number">{{$status_akhir->kalah}}</div>
                                </div>
                            </article>
                        </div>
                        <!--.col-->
                        <div class="col-md-3 col-sm-6">
                            <article class="statistic-box m-b-0 box-statistic3 kz-shadow cursor-pointer" onclick="getDetailTender('selesai')">
                                <div>
                                    <div class="caption">
                                        <div>Selesai</div>
                                    </div>
                                    <div class="number">{{$selesai}}</div>
                                </div>
                            </article>
                        </div>
                        <!--.col-->
                        <div class="col-md-3 col-sm-6">
                            <article class="statistic-box m-b-0 box-statistic4 kz-shadow">
                                <div>
                                    <div class="caption">
                                        <div>Rataan HPS</div>
                                    </div>
                                    <div class="number">{{round($rataanhps,2)}}%</div>
                                </div>
                            </article>
                        </div>
                        <!--.col-->
                    </div>
                </div>
            </div>
        </div>


        <!-- kalender -->
        <div class="row">
            <div class="col-md-12">
                <div class="card kz-border-0 kz-shadow m-b-1" style="padding: 7px;">
                    <div class="col-md-6">
                        <h5 class="" style="margin-top:7px;">Waktu</h5>
                    </div>
                    <div class="offset-8 kzcalen">
                        <div class="form-group m-b-0">
                            <div class="input-group date">
                                <input id="search-daterange" type="text" value="{{$filter->daterange}}"
                                    class="form-control media-middle" style="font-size: 11px;">
                                <span class="input-group-addon">
                                    <i class="font-icon font-icon-calend"></i>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <!-- Grafik -->
            <div class="col-md-12">
                <div class="card kz-shadow m-b-1">
                    <div class="kz-pageprofilcard" style="height: 400px" id="container" ></div>
                </div>
            </div>
            <!-- Kompetitor -->
            <div class="col-md-12">
                <section class="box-typical  kz-border-0 kz-shadow m-b-1"">
                    <header class="box-typical-header">
                        <div class="tbl-row">
                           <div class="tbl-cell">
                                <h3 style="margin-bottom: 0px;">Kompetitor</h3>
                                <small class="kz-table-desc">Berdasarkan kemenangan pada instansi dan kategori
                                        yang
                                        sama</small>
                            </div>
                        </div>
                    </header>
                    <div class="box-typical-body">
                        <div class="table-responsive">
                            <table class="table table-hover table-striped">
                                <tbody>
                                    @foreach ($tabel as $tabel_kompetitor)
                                    <tr>
                                        <td class="table-left kz-link">
                                            <a href="{{url('/profile?namaPerusahaan=' . $tabel_kompetitor->nama)}}">
                                                {{$tabel_kompetitor->nama}}
                                            </a>
                                        </td>
                                        <td class="text-right table-right">
                                            {{$tabel_kompetitor->menang}} Menang
                                        </td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!--.box-typical-body-->
                </section>
            </div>
             <!-- Top Tender -->
            <div class="col-md-12">
                <section class="box-typical box-typical-max-280 kz-border-0 kz-shadow m-b-1">
                    <header class="box-typical-header">
                        <div class="tbl-row">
                            <div class="tbl-cell">
                                <h3 style="margin-bottom: 0px;">Tender Teratas</h3>
                                <small class="kz-table-desc">Berdasarkan nilai HPS tertinggi</small>
                            </div>
                        </div>
                    </header>
                    <div class="table-responsive">
                        <table class="table table-hover table-striped kz-border-0 container">
                            <tbody>
                                 @foreach ($tender_teratas as $tb)
                                 
                                 @php
                                     $tender = $tb->detail->hits->hits[0]->_source;
                                    //  dd($tender);
                                 @endphp
                                <tr>
                                    <td class="table-left">
                                        <a style="font-size: 18px; color: #000000;"
                                        href="{{url("/beranda/pencarian?kodePaket=$tender->kode_paket")}}">
                                        {{$tender->nama_paket}}
                                        </a>   
                                    </td>
                                    <td class="text-right table-right">
                                        Rp. {{ number_format($tender->nilai_hps, 0, ".", ",")}}
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    <!--.box-typical-body-->
                </section>
            </div>
            <!-- Kategori -->
            <div class="col-md-12">
                <section class="box-typical box-typical-max-280 kz-shadow m-b-1"">
                    <header class="box-typical-header">
                        <div class="tbl-row">
                            <div class="tbl-cell">
                                <h3 style="margin-bottom: 0px;">Kategori</h3>
                                <small class="kz-table-desc">Berdasarkan Jumlah kemenangan</small>
                            </div>
                        </div>
                    </header>

                    <section class="widget widget-accordion" id="accordion" role="tablist" aria-multiselectable="true">
                       @foreach($hasil_kategori as $key => $val)
                        <article class="panel">
                            <div class="panel-heading " role="tab" id="heading{{$key}}">
                                <a data-toggle="collapse" data-parent="#accordion" href="#collapse{{$key}}" aria-expanded="true" aria-controls="collapse{{$key}}" class="collapsed">
                                    <div class="tbl">
                                        <div class="tbl-row">
                                            <div class="col-md-5 col-sm-5">
                                                {{$val->key}}
                                            </div>
                                            <div class="col-md-4 col-sm-4">
                                                <div class="progress-with-amount">
                                                    <progress class="progress progress-no-margin" value="{{$val->doc_count}}"
                                                        max="{{$total_tender_kategori}}"></progress>
                                                </div>
                                            </div>
                                            <div class="col-md-2">
                                                {{$val->doc_count}} Menang
                                           </div>
                                            <div class="col-md-1 text-right">
                                                #7
                                            </div>
                                        </div>
                                        <i class="font-icon font-icon-arrow-down"></i>
                                    </div>
                                </a>
                            </div>
                           {{--  <div id="collapse{{$key}}" class="panel-collapse collapse" role="tabpanel"
                                aria-labelledby="heading{{$key}}" aria-expanded="false" style="height: 0px;">
                                <div class="panel-collapse-in">
                                    <div class="table-responsive">
                                        <table class="table table-striped">
                                            <tr>
                                                <td class="table-photo">
                                                    <img src="{{url('public/templates/default')}}/img/photo-64-1.jpg" alt=""
                                                        data-toggle="tooltip" data-placement="bottom" title=""
                                                        data-original-title="Nicholas<br/>Barrett">
                                                </td>
                                                <td>
                                                    <div>Pengamatan Sumber daya</div>
                                                    <div><small>Tulisan Kecil</small></div>
                                                </td>
                                                <td>
                                                    <i class="fa fa-calendar-check-o"></i>
                                                    kalendar
                                                </td>
                                                <td>
                                                    Rp 1,25 M
                                                </td>
                                                <td class="text-right">
                                                    <span
                                                        class="label label-pill label-warning kz-label-kategori">Selesai</span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="table-photo">
                                                    <img src="{{url('public/templates/default')}}/img/photo-64-1.jpg" alt=""
                                                        data-toggle="tooltip" data-placement="bottom" title=""
                                                        data-original-title="Nicholas<br/>Barrett">
                                                </td>
                                                <td>
                                                    <div>Pengamatan Sumber daya</div>
                                                    <div><small>Tulisan Kecil</small></div>
                                                </td>
                                                <td>
                                                    <i class="fa fa-calendar-check-o"></i>
                                                    kalendar
                                                </td>
                                                <td>
                                                    Rp 1,25 M
                                                </td>
                                                <td class="text-right">
                                                    <span
                                                        class="label label-pill label-success kz-label-kategori">Berjalan</span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="table-photo">
                                                    <img src="{{url('public/templates/default')}}/img/photo-64-1.jpg" alt=""
                                                        data-toggle="tooltip" data-placement="bottom" title=""
                                                        data-original-title="Nicholas<br/>Barrett">
                                                </td>
                                                <td>
                                                    <div>Pengamatan Sumber daya</div>
                                                    <div><small>Tulisan Kecil</small></div>
                                                </td>
                                                <td>
                                                    <i class="fa fa-calendar-check-o"></i>
                                                    kalendar
                                                </td>
                                                <td>
                                                    Rp 1,25 M
                                                </td>
                                                <td class="text-right">
                                                    <span
                                                        class="label label-pill label-warning kz-label-kategori">Selesai</span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="table-photo">
                                                    <img src="{{url('public/templates/default')}}/img/photo-64-1.jpg" alt=""
                                                        data-toggle="tooltip" data-placement="bottom" title=""
                                                        data-original-title="Nicholas<br/>Barrett">
                                                </td>
                                                <td>
                                                    <div>Pengamatan Sumber daya</div>
                                                    <div><small>Tulisan Kecil</small></div>
                                                </td>
                                                <td>
                                                    <i class="fa fa-calendar-check-o"></i>
                                                    kalendar
                                                </td>
                                                <td>
                                                    Rp 1,25 M
                                                </td>
                                                <td class="text-right">
                                                    <span
                                                        class="label label-pill label-warning kz-label-kategori">Selesai</span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="table-photo">
                                                    <img src="{{url('public/templates/default')}}/img/photo-64-1.jpg" alt=""
                                                        data-toggle="tooltip" data-placement="bottom" title=""
                                                        data-original-title="Nicholas<br/>Barrett">
                                                </td>
                                                <td>
                                                    <div>Pengamatan Sumber daya</div>
                                                    <div><small>Tulisan Kecil</small></div>
                                                </td>
                                                <td>
                                                    <i class="fa fa-calendar-check-o"></i>
                                                    kalendar
                                                </td>
                                                <td>
                                                    Rp 1,25 M
                                                </td>
                                                <td class="text-right">
                                                    <span
                                                        class="label label-pill label-warning kz-label-kategori">Selesai</span>
                                                </td>
                                            </tr>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            @endforeach --}}
                        </article>
                        @endforeach
                    </section>
                </section>
            </div>
        </div>
    </div>
</div>

<form id="form-search" method="GET" action="{{url('/profile')}}">
    <input type="hidden" id="namaPerusahaan" name="namaPerusahaan" value="{{$filter->namaPerusahaan}}">
    <input type="hidden" id="daterange" name="daterange" value="{{$filter->daterange}}">

</form>

<div class="modal fade" id="detail-tender" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="modal-close" data-dismiss="modal" aria-label="Close">
                    <i class="font-icon-close-2"></i>
                </button>
                <h4 class="modal-title" id="modal-tender-title"></h4>
            </div>
            <div class="modal-body" id="detail-container"></div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
            </div>
        </div>
    </div>
</div>
{{-- {{dd($filter)}} --}}
@endsection

@section('scripts')
<script type="text/javascript" src="{{url('public/templates/default')}}/js/lib/moment/moment-with-locales.min.js">
</script>
<script type="text/javascript"
    src="{{url('public/templates/default')}}/js/lib/eonasdan-bootstrap-datetimepicker/bootstrap-datetimepicker.min.js">
</script>
<script src="{{url('public/templates/default')}}/js/lib/daterangepicker/daterangepicker.js"></script>
<script src="{{url('public/templates/default')}}/js/lib/bootstrap-select/bootstrap-select.min.js"></script>

<script type="text/javascript" src="{{url('public/templates/default')}}/js/lib/jqueryui/jquery-ui.min.js"></script>
<script type="text/javascript" src="{{url('public/')}}/js/profile/chart.js"></script>

<script src="https://cdn.anychart.com/releases/v8/js/anychart-base.min.js?hcode=c11e6e3cfefb406e8ce8d99fa8368d33">
</script>
<script src="https://cdn.anychart.com/releases/v8/js/anychart-ui.min.js?hcode=c11e6e3cfefb406e8ce8d99fa8368d33">
</script>
<script src="https://cdn.anychart.com/releases/v8/js/anychart-exports.min.js?hcode=c11e6e3cfefb406e8ce8d99fa8368d33">
</script>
<script
    src="https://cdn.anychart.com/releases/v8/js/anychart-data-adapter.min.js?hcode=c11e6e3cfefb406e8ce8d99fa8368d33">
</script>
<script src="https://cdn.anychart.com/js/v8/graphics.min.js"></script>

<script>
    $(document).ready(function(){
        fetchData();

    });

    $('#search-daterange').daterangepicker({
        ranges: {
            'Hari Ini': [moment(), moment()],
            'Kemarin': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
            'Data 7 Hari': [moment().subtract(6, 'days'), moment()],
            'Data 30 Hari': [moment().subtract(29, 'days'), moment()],
            'Data Bulan Ini': [moment().startOf('month'), moment().endOf('month')],
            'Data Bulan Lalu': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        },
        widgetPositioning: {
            horizontal: 'left'
        },
        "linkedCalendars": true,
        "autoUpdateInput": true,
        "alwaysShowCalendars": false,
        "showWeekNumbers": true,
        "showDropdowns": true,
        "showISOWeekNumbers": true,
        debug: false,
        locale: {
            format: 'DD/MM/YYYY'
        }
    });

    $('#search-namaPerusahaan').keyup(function(e){
        if(e.keyCode == 13)
        {
            const searchNamaPerusahaan = $(this).val();

            $('#namaPerusahaan').val(searchNamaPerusahaan);
            $('#namaPerusahaan1').val(searchNamaPerusahaan);
            $('#form-search').submit();
        }
    });

    $('#search-namaPerusahaan2').keyup(function(e){
        if(e.keyCode == 13)
        {
            const searchNamaPerusahaan = $(this).val();

            $('#namaPerusahaan2').val(searchNamaPerusahaan);
            $('#form-komparasi').submit();
            // return komparasi;
        }
    });

    $('#search-daterange').on('change', function(e){
        const searchDaterange = $(this).val();

        $('#daterange').val(searchDaterange);
        $('#form-search').submit();
    });

    function fetchData() {
        $.ajax({
            type: 'GET',
            url: '{{url('/profile/chart')}}?daterange={{$filter->daterange}}&namaPerusahaan={{$filter->namaPerusahaan}}',
            success: function(data) {
                loadChart(data);
            }
        });
    }

    function loadChart(data) {
        anychart.onDocumentReady(function () {
            // create data set on our data
            var dataSet = anychart.data.set(getData(data));
            // console.log("loadChart",dataSet);

            // map data for the first series, take x from the zero column and value from the first column of data set
            var seriesData_1 = dataSet.mapAs({ 'x': 0, 'value': 1 });

            // map data for the second series, take x from the zero column and value from the second column of data set
            var seriesData_2 = dataSet.mapAs({ 'x': 0, 'value': 2 });
            // create line chart
            var chart = anychart.line();

            // chart.addSeries(seriesData_1, seriesData_2);

            // install theme
            anychart.theme(customTheme);

            // turn on chart animation
            chart.animation(true);

            // set chart padding
            chart.padding([10, 20, 5, 20]);

            // turn on the crosshair
            chart.crosshair()
                .enabled(true)
                .yLabel(false)
                .yStroke(null);

            // set tooltip mode to point
            chart.tooltip().positionMode('point');

            // set chart title text settings
            var title = chart.title();
            title.text('Pergerakan Aktivitas');
            title.fontFamily('Proxima Nova');
            title.enabled(true);
            title.fontSize('24px')

            // set yAxis title
            // chart.yAxis().title('Number of Bottles Sold (thousands)');
            // chart.xAxis().labels().padding(5);

            // create first series with mapped data
            // var series_1 = chart.line(seriesData_1);
            // series_1.name('Tender Aktif');
            // series_1.hovered().markers()
            //     .enabled(true)
            //     .type('circle')
            //     .size(4);
            // series_1.tooltip()
            //     .position('right')
            //     .anchor('left-center')
            //     .offsetX(5)
            //     .offsetY(5);

            // create second series with mapped data
            var series_2 = chart.line(seriesData_2);
            series_2.name('Tender Dimenangkan');
            series_2.hovered().markers()
                .enabled(true)
                .type('circle')
                .size(4);
            series_2.stroke({
                color: "#177117"
            });
            series_2.tooltip()
                .position('right')
                .anchor('left-center')
                .offsetX(5)
                .offsetY(5);

            // turn the legend on
            chart.legend()
                .enabled(true)
                .fontFamily('Proxima Nova')
                .fontSize(13)
                .position('bottom')
                .align('center')
                .padding([30, 0, 10, 0]);

            // set container id for the chart
            chart.container('container');
            // initiate chart drawing
            chart.draw();
        });

        function getData(data) {

            return data;

            console.log(data);
        }   
    }
    function show()
        {
            $('#edit1').show();
            $('#edit2').hide();
        }
</script>

{{-- Toggle page --}}
<script>
    var input = document.getElementById("search-namaPerusahaan");

    input.addEventListener("keyup", function(event) {
        if (event.keyCode === 13) {
            event.preventDefault();
            document.getElementById("myBtn").click();
        }
    });

    function toggle() {
        var x = document.getElementById("container1");
        var z = document.getElementById("container2");

        if (x.style.display === "block") {
            x.style.display = "block";
        }
        var y = document.getElementById("container3");
        if (y.style.display === "none") {
            x.style.display = "block";
            y.style.display = "block";
            z.style.display = "none";
            // x.style.display = "block";
        }
    }
</script>

<script>
function getDetailTender(status) {
    $('#modal-tender-title').html(`Detail ${status}`);
    $('#detail-tender').modal('toggle');

    getDataDetail('{{url('ajax/detail-tender')}}?daterange={{$filter->daterange}}&nama-perusahaan={{$filter->namaPerusahaan}}&status='+status);
}


function getDataDetail(url) {
    $('#detail-container').html(`
        <div class="m-y-lg text-center"><i class="fa fa-spinner fa-spin fa-3x fa-fw"></i>
        <br><br><span>Memuat Data...</span></div>
    `);

    $.ajax({
        type: 'GET',
        url: url,
        success: function(data) {
            $('#detail-container').html(data);
        },
        error: function(error) {
            $('#detail-container').html(`<div class="add-customers-screen tbl">
                        <div class="add-customers-screen-in">
                            <div class="add-customers-screen-user">
                                <i class="font-icon fa fa-exclamation-circle text-danger"></i>
                            </div>
                            <h6>Terjadi kesalahan.</h6>
                        </div>
                    </div>`);
        }
    })
}
</script>
@endsection
