<table id="dataPeserta" class="kz-table table">
    <tbody>
        @if ($isi == [] )
        <tr>
            <td class="kz-table" style="padding-left:15px" colspan="2">
                <center>Data yang anda cari tidak ada</center>
            </td>
        </tr>
        @else
        @foreach ($isi as $index=>$perusahaan)
        <tr>
            <td class="kz-link" style="padding-left:15px;">
                {{$index+1}}.
                <a href="{{url('/profile?namaPerusahaan=' . $perusahaan->key)}}">
                    {{$perusahaan->key}}
                </a>
            </td>
            @if ($status == "hps")
            <td class="text-right" style="padding-right:15px">
                RP {{ number_format($perusahaan->jumlah->value, 0, ".", ",")}}
            </td>
            @elseif ($status == "menang")
            <td class="text-right" style="padding-right:15px">
                {{$perusahaan->doc_count}} Menang
            </td>
            @elseif ($status == "hpsSementara")
            <td class="text-right" style="padding-right:15px">
                RP 0
            </td>
            @else
            <td class="text-right" style="padding-right:15px">
                0 Menang
            </td>
            @endif
        </tr>
        @endforeach
        @endif
    </tbody>
</table>
{{-- <nav class="pull-right">
    <ul class="pagination pagination-sm">
        <li class="page-item">
            <a class="page-link" href="#" aria-label="Previous">
                <span aria-hidden="true">&laquo;</span>
                <span class="sr-only">Previous</span>
            </a>
        </li>
        <li class="page-item"><a class="page-link" href="#" onclick="getData('{{$url}}&page=1')">1</a></li>
        <li class="page-item"><a class="page-link" href="#" onclick="getData('{{$url}}&page=2')">2</a></li>
        <li class="page-item"><a class="page-link" href="#" onclick="getData('{{$url}}&page=3')">3</a></li>
        <li class="page-item">
            <a class="page-link" href="#" aria-label="Next">
                <span aria-hidden="true">&raquo;</span>
                <span class="sr-only">Next</span>
            </a>
        </li>
    </ul>
</nav> --}}
<nav class="pull-right">
    <ul class="pagination pagination-sm">
        @php
        for ($i=0; $i <= 2; $i++) {
            if($paginator->current_page - $i > 0) $start = $paginator->current_page - $i;
            if($paginator->current_page + $i <= $paginator->last_page) $end = $paginator->current_page + $i;
        }
        @endphp

        @if($paginator->current_page > 1)
        <li class="page-item">
            <a class="page-link" href="javascript:void(0)" onclick="getData('{{$url}}&page={{$paginator->current_page-1}}')" aria-label="Previous">
                <span aria-hidden="true">«</span>
                <span class="sr-only">Previous</span>
            </a>
        </li>
        @endif
        @for($i = $start; $i <= $end; $i++)
            @if($paginator->current_page == $i)
                <li class="page-item active">
                    <a class="page-link cursor-default" href="javascript:void(0)">{{$i}}</a>
                </li>
            @else
                <li class="page-item">
                    <a class="page-link" href="#" onclick="getData('{{$url}}&page={{$i}}')">
                        {{$i}}
                    </a>
                </li>
            @endif
        @endfor
        @if($paginator->current_page < $paginator->last_page)
        <li class="page-item">
            <a class="page-link" href="javascript:void(0)" onclick="getData('{{$url}}&page={{$paginator->current_page+1}}')" aria-label="Next">
                <span aria-hidden="true">»</span>
                <span class="sr-only">Next</span>
            </a>
        </li>
        @endif
    </ul>
</nav>
