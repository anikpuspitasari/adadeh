@extends('layouts.default')
@section('title', 'Peserta')

@section('styles')
<link rel="stylesheet"
    href="{{url('public/')}}/templates/default/css/separate/vendor/bootstrap-daterangepicker.min.css">
<link rel="stylesheet"
    href="{{url('public/')}}/templates/default/css/separate/vendor/bootstrap-select/bootstrap-select.min.css">
<link rel="stylesheet" href="{{url('public/')}}/templates/default/css/separate/vendor/tags_editor.min.css">
<link rel="stylesheet" href="{{url('public/')}}/templates/default/css/separate/vendor/select2.min.css">
<style type="text/css">
    .kz-sidebar-title {
        padding: 25px;
    }

    .kz-sidebar-checkbox {
        margin-left: 25px;
        margin-top: 10px;
    }

    .kz-pagecontent-aktifbutton {
        width: 80%;
        padding: 2px;
        border-radius: 50px;
    }

    .kz-table tr:nth-child(even) {
        background-color: #e6e6ff;
    }

    .kz-table .kz-table-rounded {
        border-collapse: collapse;
        border-radius: 1em;
        overflow: hidden;
    }

    .kz-position-sidebar {
        position: fixed;
        width: 30%;
    }

    .kz-cari-button {
        width: 20%;
        padding: 2px;
        border-radius: 50px;
        margin-right: 20px;
    }

    /*
    .kz-dropdown, .kz-dropdown option{
        margin-left: 25px;
        margin-top: 10px;
        padding-left: 25px;
        padding-right: 25px;
    } */
    .kz-borderactive {
        border-color: blue;
    }
</style>
@endsection

@section('content')
<div class="container-fluid">
    <div class="row">
        <form action="./peserta" method="get" name="myform">
            <div class="col-md-4 col-sm-4">
                <div class="card kz-position-sidebar">
                    <div class="card-block ">
                        <div>
                            <span class="kz-sidebar-title">Filter Peserta Tender</span>
                        </div>
                        <div>
                            <div class="p-r-1 kz-sidebar-checkbox">
                                <select name="tipe" class="bootstrap-select bootstrap-select-arrow kz-dropdown">
                                    @if ($tipe == "Kemenangan Tertinggi")
                                    <option selected>Kemenangan Terbanyak</option>
                                    @else
                                    <option>Kemenangan Terbanyak</option>
                                    @endif
                                    @if ($tipe == "Total HPS Tertinggi")
                                    <option selected>Total HPS Tertinggi</option>
                                    @else
                                    <option>Total HPS Tertinggi</option>
                                    @endif
                                </select>
                            </div>
                        </div> <br />
                        <div>
                            <span class="kz-sidebar-title">Kualifikasi Usaha</span>
                            <div class="checkbox-bird kz-sidebar-checkbox">
                                @if (isset($PerusahaanKecil))
                                <input type="checkbox" name="kualifikasiUsaha[]" id="check-bird-1"
                                    value="Perusahaan Kecil" checked />
                                @else
                                <input type="checkbox" name="kualifikasiUsaha[]" id="check-bird-1"
                                    value="Perusahaan Kecil" />
                                @endif
                                <label for="check-bird-1">Perusahaan Kecil</label>
                            </div>
                            <div class="checkbox-bird kz-sidebar-checkbox">
                                @if (isset($PerusahaanNonKecil))
                                <input type="checkbox" name="kualifikasiUsaha[]" id="check-bird-2"
                                    value="Perusahaan Non Kecil" checked />
                                @else
                                <input type="checkbox" name="kualifikasiUsaha[]" id="check-bird-2"
                                    value="Perusahaan Non Kecil" />
                                @endif
                                <label for="check-bird-2">Perusahaan Non Kecil</label>
                            </div>
                            <div><span class="kz-sidebar-title">Kategori</span>
                                <div class="p-r-1 kz-sidebar-checkbox">
                                    <select name="kategori" class="bootstrap-select bootstrap-select-arrow kz-dropdown">
                                        @if ($kategori == null || $kategori == "Semua Kategori")
                                        <option selected>Semua Kategori</option>
                                        @else
                                        <option>Semua Kategori</option>
                                        @endif
                                        @if ($kategori == "Pengadaan Barang")
                                        <option selected>Pengadaan Barang</option>
                                        @else
                                        <option>Pengadaan Barang</option>
                                        @endif
                                        @if ($kategori == "Pekerjaan Konstruksi")
                                        <option selected>Pekerjaan Konstruksi</option>
                                        @else
                                        <option>Pekerjaan Konstruksi</option>
                                        @endif
                                        @if ($kategori == "Jasa Konsultasi Badan Usaha")
                                        <option selected>Jasa Konsultasi Badan Usaha</option>
                                        @else
                                        <option>Jasa Konsultasi Badan Usaha</option>
                                        @endif
                                        @if ($kategori == "Jasa Konsultasi Perorangan")
                                        <option selected>Jasa Konsultasi Perorangan</option>
                                        @else
                                        <option>Jasa Konsultasi Perorangan</option>
                                        @endif
                                        @if ($kategori == "Jasa Lainnya")
                                        <option selected>Jasa Lainnya</option>
                                        @else
                                        <option>Jasa Lainnya</option>
                                        @endif
                                    </select>
                                </div>
                            </div>
                        </div>
                        <fieldset class="form-group kz-sidebar-checkbox">
                            <button type="submit" value="submit" class="btn kz-cari-button pull-right">Cari</button>
                        </fieldset>
                    </div>
                </div>
            </div>

            <div class="col-md-8">
                <div class="card">
                    <div class="tbl-cell-title">
                        <center style="font-size: 17pt; font-weight: bold; margin: 15px;">Peringkat Peserta Tender Tahun
                            2018-2019</center>
                        <div class="search" style="margin:15px">
                            <div class="form-control-wrapper form-control-icon-left">
                                <input type="text" id="cari" class="form-control form-control-rounded"
                                    placeholder="Cari Nama Peserta Tender" name="namaPerusahaan"
                                    value="{{$filter->namaPerusahaan}}">
                                <span id="searchBtn" role="button" onclick="myform.submit()"
                                    class="fa fa-search"></span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card clearfix">
                    <section class="box-typical box-typical-max-280 m-b-0 kz-border-0">
                        <header class="box-typical-header">
                            <div class="tbl-row">
                                <div class="tbl-cell tbl-cell-title" style="font-size: 15pt; font-weight: bold;">
                                    Peringkat Peserta Tender<br />
                                    @if ($tipe == "Total HPS Tertinggi")
                                    <small style="font-size: 9pt;">Peringkat Peserta berdasarkan Total HPS
                                        Tertinggi</small>
                                    @else
                                    <small style="font-size: 9pt;">Peringkat Peserta berdasarkan Kemenangan
                                        Terbanyak</small>
                                    @endif
                                </div>
                            </div>
                        </header>
                        <div class="table table-responsive">
                            {{-- <table id="dataPeserta" class="kz-table table">
                                    <tbody>
                                        @if ($isi == [] )
                                        <tr>
                                            <td class="kz-table" style="padding-left:15px" colspan="2">
                                                <center>Data yang anda cari tidak ada</center>
                                            </td>
                                        </tr>
                                        @else
                                        @foreach ($isi as $index=>$perusahaan)
                                        <tr>
                                            <td class="kz-link" style="padding-left:15px;">
                                                {{$index+1}}.
                                <a href="{{url('/profile?namaPerusahaan=' . $perusahaan->key)}}">
                                    {{$perusahaan->key}}
                                </a>
                                </td>
                                @if ($status == "hps")
                                <td class="text-right" style="padding-right:15px">
                                    RP {{ number_format($perusahaan->jumlah->value, 0, ".", ",")}}
                                </td>
                                @elseif ($status == "menang")
                                <td class="text-right" style="padding-right:15px">
                                    {{$perusahaan->doc_count}} Menang
                                </td>
                                @elseif ($status == "hpsSementara")
                                <td class="text-right" style="padding-right:15px">
                                    RP 0
                                </td>
                                @else
                                <td class="text-right" style="padding-right:15px">
                                    0 Menang
                                </td>
                                @endif
                                </tr>
                                @endforeach
                                @endif
                                </tbody>
                                </table>
                            --}}
                            <div id="dataPeserta">
                            </div>
                        </div>
                    </section>
                </div>
            </div>
        </form>
    </div>
</div>

@endsection

@section('scripts')

<script src="{{url('public/templates/default')}}/js/lib/bootstrap-select/bootstrap-select.min.js"></script>
<script src="{{url('public/templates/default')}}/js/lib/jquery-tag-editor/jquery.tag-editor.min.js"></script>
<script src="{{url('public/templates/default')}}/js/lib/jquery-tag-editor/jquery.caret.min.js"></script>
<script src="{{url('public/templates/default')}}/js/lib/select2/select2.full.min.js"></script>

<script>
    $(document).ready(function(){
        getData(encodeURI('{{url('peserta/detailPeserta')}}?tipe={{$tipe}}&kategori={{$filter->kategori}}&namaPerusahaan={{$filter->namaPerusahaan}}&kualifikasiUsaha[]={{$PerusahaanKecil}}&kualifikasiUsaha[]={{$PerusahaanNonKecil}}'));
        // getData(encodeURI('{{url('peserta/detailPeserta')}}?tipe={{$tipe}}&kategori={{$filter->kategori}}&$namaPerusahaan={{$filter->namaPerusahaan}}&kualifikasiUsaha[]={{$PerusahaanKecil}}&kualifikasiUsaha[]{{$PerusahaanNonKecil}}'));
    });

    function getData(url) {
        $('#dataPeserta').html(`
            <div class="m-y-lg text-center"><i class="fa fa-spinner fa-spin fa-3x fa-fw"></i>
            <br><br><span>Memuat Data...</span></div>
        `);

        $.ajax({
            type: 'GET',
            url: url,
            success: function(data) {
                $('#dataPeserta').html(data);
            },
            error: function(error) {
                $('#dataPeserta').html(`
                <table id="dataPeserta" class="kz-table table">
                    <tbody>
                        <tr>
                            <td class="kz-table" style="padding-left:15px" colspan="2">
                                <center>Data yang anda cari tidak ada</center>
                            </td>
                        </tr>
                    </tbody>
                </table>
                `);
            }
        })
    };

</script>

@endsection
