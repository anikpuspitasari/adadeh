@extends('layouts.default')
@section('title', 'Pengaturan Notifikasi')

@section('page-css')
@endsection

@section('styles')
<style type="text/css">
    .filter-column {
        padding-right: 5px;
        padding-left: 5px;
    }

    .btn.btn-active{
        background-color: #00a8ff;
    }
</style>
@endsection

@section('content')

<div class="container-fluid">
    <div class="col-md-8 offset-md-2">
        <div class="row">
            <div class="card">
                <div class="card-block">
                    <div class="tbl tbl-responsive">
                        <table id="example" class="table table-striped" style="width:100%">
                            <thead>
                                <th colspan="3">Daftar Notifikasi</th>
                            </thead>
                            <tbody>
                                @foreach($listnotifikasi as $setting=> $val)
                                <tr style="display: none;" id="edit1" action="#" method="POST">
                                    @csrf
                                    @method('PUT')
                                    <td scope="row">
                                        1
                                    </td>
                                    <td class="tbl">
                                        <div class="tbl-row">
                                            <div class="col-md-3 p-t-1">
                                                <div class="form-group">
                                                    <div class="form-control-wrapper">
                                                        <input type="text" value="" id="input" placeholder="Media Monitoring" 
                                                            class="form-control form-control-rounded"
                                                             style="font-size: 0.75em;">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-3 p-t-1">
                                                <span>Rentang Nilai HPS</span>
                                            </div>
                                            <div class="col-md-3 p-t-1">Kualifikasi Usaha</div>
                                            <div class="col-md-3 p-t-1">Status Notifikasi</div>
                                        </div>
                                        <div class="tbl-row">
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <div class="form-control-wrapper" style="height: 10px;">
                                                        <input type="text" id="input" value="" 
                                                            class="form-control form-control-rounded"
                                                            placeholder="Media Monitoring" style="font-size: 0.75em;">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <input type="text" id="input" value="" 
                                                        class="form-control form-control-rounded"
                                                        placeholder="RP Minimal" style="font-size: 0.75em;">
                                                </div>
                                                <div class="form-group">
                                                    <input type="text" id="input" value="" class="form-control form-control-rounded" placeholder="RP Maximal" style="font-size: 0.75em;">
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <div class="form-control-wrapper">
                                                        <button type="button" 
                                                            class="btn btn-rounded btn-secondary btn-kualifikasi" style="font-size: 0.75em; width:100%;">Perusahaan Kecil
                                                        </button>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <div class="form-control-wrapper">
                                                        <button type="button" 
                                                            class="btn btn-rounded btn-secondary btn-kualifikasi" style="font-size: 0.75em; width:100%;padding-left:0.5rem;padding-right:0.5rem;">Perusahaan
                                                                Non Kecil
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="checkbox-toggle">
                                                    <input type="checkbox" value="" id="check-toggle-1" checked />
                                                    <label for="check-toggle-1">Aktif</label>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <button class="btn btn-rounded" style="width:100%" action="submit" onclick="simpan()">
                                            Simpan
                                        </button>
                                    </td>
                                </tr>
                                <tr id="edit2">
                                    <td>2</td>
                                    <td>
                                        <h4 class="m-b-0">Pagar Bangunan</h4>
                                        <span>Rp 5.000.000.000 - Rp 100.000.000.000</span> <br />
                                        <span>Perusahaan Non Kecil</span>
                                    </td>
                                    <td style="font-size:2em;">
                                        <button class="btn btn-rounded btn-edit" onclick="show()">
                                            <i class="fa fa-edit"></i>
                                        </button>
                                        <button class="btn btn-rounded">
                                            <i class="fa fa-trash"></i>

                                        </button>
                                    </td>
                                </tr>    
                                @endforeach
                                
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<div class="col-md-2"></div>







@endsection

@section('scripts') 
<script type="text/javascript">
    function show()
    {
        $('#edit1').show();
        $('#edit2').hide();
    }
    function simpan()
    {
        $('#edit2').show();
        $('#edit1').hide();
    }
    
    $('.btn-kualifikasi').click(function(){
        console.log('Kualifikasi')
        $('.btn-kualifikasi').removeClass('btn-active');
        $(this).addClass('btn-active');
    })
</script>
@endsection
