
@extends('layouts.default')
@section('title', 'Notifikasi Page')

@section('styles')
<style type="text/css">
	.kz.label{
		background-color: gold;
		width: 35%;
		border-radius:40px;
		font-color : white;
		font-size: 0.75em;
	}
</style>>

@endsection

@section('content')

<div class="container" id="container1">
	<div class="row">
		<div class="col-md-2"></div>
		<div class="col-md-8">
			<div class="card">
				<div class="card-block">
					<thead>
						<span><b>Notifikasi Anda</b></span>
						<a href="{{url('/notifikasi/setting')}}" class="pull-right" style="color:blue;"><small>Pengaturan Notifikasi</small></a>		
					</thead>
					<table id="example" class="table table-striped" style="width:100%">
						<tbody>
							@foreach($listnotifikasi as $notifikasi)
								@if ($notifikasi->read_at == Null)
								<tr style="background-color: #e6e6ff">
								@else
								<tr>
								@endif
								<td width="10%">
									<img src="http://localhost/KazeeLPSE/public/img/user(1).png">
								</td>
								<td width="90%">
									@if ($notifikasi->read_at == Null) 
									<b>{{$notifikasi->data['nama_notifikasi']}}</b><br/>
									@else
									{{$notifikasi->data['nama_notifikasi']}}<br/>
									@endif
									<small>Lembaga Kebijakan Pengadaan Barang/Jasa Pemerintah</small><br/>
									<small>Jasa Lainnya | Perusahaan Non Kecil | Rp 198.000.000,00 | </small>
									<label class="kz label"><center>Pengumuman Prakualifikasi, 4 hari lagi</center></label><br/>
								</td>
							</tr>
							@endforeach
							<tr>
								<td width="10%">
									<img src="http://localhost/KazeeLPSE/public/img/user(1).png">
								</td>
								<td width="90%">
									<b>Tender Media Monitoring (berasal dari nama notifikasi)</b><br/>
									<small>Lembaga Kebijakan Pengadaan Barang/Jasa Pemerintah</small><br/>
									<small>Jasa Lainnya | Perusahaan Non Kecil | Rp 198.000.000,00 | </small>
									<label class="kz label"><center>Pengumuman Prakualifikasi, 4 hari lagi</center></label><br/>
								</td>
							</tr>
						</tbody>
					</table>
				</div>	
			</div>
		</div>
		<div class="col-md-2"></div>	
	</div>
</div>
@endsection
@section('scripts') 
@endsection