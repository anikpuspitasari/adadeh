@extends('layouts.default')
@section('title', 'Analisa')

@section('page-css')
<link rel="stylesheet"
href="{{url('public/')}}/templates/default/css/separate/vendor/bootstrap-daterangepicker.min.css">
<link href="https://cdn.anychart.com/releases/v8/css/anychart-ui.min.css?hcode=c11e6e3cfefb406e8ce8d99fa8368d33"
type="text/css" rel="stylesheet">
<link href="https://cdn.anychart.com/releases/v8/fonts/css/anychart-font.min.css?hcode=c11e6e3cfefb406e8ce8d99fa8368d33"
type="text/css" rel="stylesheet">
<link rel="stylesheet" href="{{url('public/')}}/templates/default/css/separate/pages/widgets.min.css">
@endsection

@section('styles')

<link rel="stylesheet" href="{{url('public/')}}/css/analisa/analisa.css">
<style>
    h5{
        font-family: Proxima Nova,
        font-size: 24px;
        text-align: center;
        padding-left: 35%;
    }
    td{
        font-weight: bold;
    }
    .kz-pagecontent-chart{
		height: 350px;
    }
    .kz-pagecontent-datepicker{
		height: 70px;
	}
	.btn-cari{
		background-color: white;
		margin-left: 15px;
		margin-right: 15px;
	}

</style>
@endsection

@section('content')
<form id="form-search" method="GET" action="{{url('/analisa/pencarian')}}"  name="myform">
<div class="container">
    <!-- Search Bar -->
    <div id="container4">
    <div class="row">
        <div class="col-md-12">
            <div class="card" style="border-radius:50px;">
                <div class="card-block">
                    {{-- Title --}}
                    <div class="col-md-12">
                        <h3 class="m-b-0" style="text-align: center;">Data Tender Tahun 2018-2019</h3><br>
                    </div>
                    <div class="col-md-8 offset-md-2">
                        <div class="search">
                            <div class="form-control-wrapper form-control-icon-left">
                                <input type="text" id="search-tender" class="form-control form-control-rounded"
                                    placeholder="Masukkan keyword tender disini" value="{{$filter->tender}}">
                                <span id="searchBtn" role="button" onclick="toggle()" class="fa fa-search"></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <input type="hidden" id="dtp_input2" value="/">
    </div>
    </div>

</form>
    {{-- Ini buat pasca search --}}
    <div id="container2"class="row"  style="padding-bottom: 0px;">
        <!-- Filter -->
        <div class="col-md-12">
            <section class="widget widget-accordion" id="accordion" role="tablist" aria-multiselectable="true" style="margin-bottom: 5px;">
                <article class="panel">

                    <div class="panel-heading " role="tab" id="heading{{-- {{$index}} --}}">
                        <a data-toggle="collapse" data-parent="#accordion" href="#collapse{{-- {{$index}} --}}" aria-expanded="true"
                            aria-controls="collapse{{-- {{$index}} --}}" class="collapsed">
                            <div class="tbl">
                                <label style="padding-left: 15px;"> Pilih Filter</label>
                                <i class="font-icon font-icon-arrow-down"></i>
                            </div>
                        </a>
                    </div>

                    {{-- @foreach($hasil_kategori as $hk) --}}
                    <div id="collapse{{-- {{$index}} --}}" class="panel-collapse collapse" role="tabpanel"
                        aria-labelledby="heading{{-- {{$index}} --}}" aria-expanded="false" style="height: 0px;">
                        <div class="panel-collapse-in">
                            <div class="table-responsive">
                                {{-- Search Tool --}}
                                {{-- <form action="{{url('/analisa/pencarian')}}" method="get" name="myform"> --}}
                                <div class="col-md-8">
                                    <div class="card">
                                        <div class="card-block">
                                            <div class="row">
                                                <div class="col-md-6 m-b-2">
                                                    <div class="row">
                                                        <div class=col-md-12>
                                                            <p>Rentang Nilai HPS</p>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <div class="form-control-wrapper">
                                                                <input type="text" class="form-control form-control-rounded" value="{{$filter->hpsMinimum}}" name="hpsMinimum" 
                                                                    placeholder="Rp Minimal">
                                                                </span>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-control-wrapper">
                                                                <input type="text" class="form-control form-control-rounded" value="{{$filter->hpsMaximum}}" name="hpsMaximum" 
                                                                    placeholder="Rp Maksimal">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-6">
                                                    <div class="row ">
                                                        <div class="col-md-12">
                                                            <p>Kualifikasi Usaha</p>
                                                        </div>
                                                    </div>

                                                    <div class="row" >
                                                        <div class="btn-cari" data-toggle="buttons">
                                                            <label class="btn btn-outline-primary btn-rounded col-md-5 kz-btn" >
                                                                <input type="radio" name="{{-- kualifikasi_usaha --}}" id="Perusahaan Kecil" value="{{$filter->kualifikasiUsaha}}" autocomplete="off" 
                                                                    checked><small>Perusahaan Kecil</small>
                                                            </label>
                                                            <label class="col-md-1" style="padding-left: 10px;"></label>
                                                            <label class="btn btn-outline-primary btn-rounded col-md-6 kz-btn">
                                                                <input type="radio" name="{{-- kualifikasi_usaha --}}" value="{{$filter->kualifikasiUsaha}}" id="Perusahaan Non Kecil"
                                                                    autocomplete="off"><small>Perusahaan
                                                                    Non Kecil</small>
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <p class="m-b-0" style="margin-top: 5px;margin-bottom:5px; ">Waktu</p>
                                                </div>
                                                <div class="col-md-">
                                                    <div class="form-group m-b-0">
                                                        <div class="input-group date">
                                                            <input id="search-daterange" type="text"value="{{$filter->daterange}}" class="form-control"
                                                                style="font-size: 11px;">
                                                            <span class="input-group-addon">
                                                                <i class="font-icon font-icon-calend"></i>
                                                            </span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="text-md-center">
                                                        <button type="button" class="btn btn-primary btn-rounded" value="submit" onclick="myform.submit()">Cari</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                {{-- Notifikasi --}}
                                <div class="col-md-4">
                                    <div class="card text-center">
                                        <div class="card-block">
                                            <div>
                                                <p>Simpan Sebagai Notifikasi</p>
                                            </div>
                                            <div class="col-md-8 offset-md-2">
                                                <form class="form-control-wrapper" method="post" action="{{url('Notifikasi/sendNotifikasi')}}" >
                                                    @csrf
                                                    <input type="text" class="form-control form-control-rounded text-center" placeholder="Nama Notifikasi" name="nama_notifikasi">
                                                    </span>
                                                    <br>
                                                    <div class="col-md-12">
                                                        <div class="text-md-center">
                                                            <button type="submit" class="btn btn-primary btn-rounded" >Simpan</button>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                {{-- </form> --}}
                                <!-- Kalender -->
                                {{-- <div class="col-md-9">
                                    <h6 class="m-b-0" style="margin-top: 5px;margin-bottom:5px; ">Waktu</h6>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group m-b-0">
                                        <div class="input-group date">
                                            <input id="search-daterange" type="text"value="{{$filter->daterange}}" class="form-control"
                                                style="font-size: 11px;">
                                            <span class="input-group-addon">
                                                <i class="font-icon font-icon-calend"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div> --}}
                            </div>
                        </div>
                    </div>
                    {{-- @endforeach --}}
                </article>
            </section>
        </div>

        <!-- Grafik -->
        <div class="col-md-12">
            <div class="card" style="margin-bottom: 5px;" >
                <div class="kz-pagecontent-chart" id="chart_jumlah">
                </div>
            </div>
        </div>
        {{-- <div class="col-md-12">
            <div class="card">
                    <div class="card-block">
                        <div class="col-md-9">
                            <h5 class="m-b-0">Peserta Pemenang Tender</h5>
                        </div>
                        <div class="col-md-3">
                            <div class="card kz-pagecontent-datepicker m-b-0">
                                <div class="input-group date">
                                    <input id="search-daterange" type="text" value="{{$filter->daterange}}" class="form-control"
                                        style="font-size: 11px;">
                                    <span class="input-group-addon">
                                        <i class="font-icon font-icon-calend"></i>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                <div class="kz-pagecontent-chart" id="chart_pemenang_tender">
                </div>
            </div>
        </div> --}}
        <!-- Top Tender -->
        <div class="col-md-12">
            <section class="box-typical box-typical-max-280  kz-border-0" style="margin-bottom: 5px;">
                <header class="box-typical-header">
                    <div class="tbl-row">
                        <div class="tbl-cell tbl-cell-title">
                            <h3 style="font-size: 20px;">Tender Teratas<br /></h3><small>Berdasarkan nilai HPS tertinggi</small>
                        </div>
                    </div>
                </header>
                <div class="table-responsive">
                    <table class="table table-hover table-striped kz-border-0">
                        <tbody>
                            @foreach ($tender_teratas as $tabel_tender_teratas)
                            <tr>
                                <td style="padding-left:15px; padding-right:20px;">
                                    {{$tabel_tender_teratas[0]}} <br/>
                                    <small>{{$tabel_tender_teratas[1]}}</small>
                                </td>
                                <td class="text-right" style="padding-right:15px;padding-left: 0px;">
                                    Rp.{{ number_format($tabel_tender_teratas[2], 0, ".", ",")}}
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
                <!--.box-typical-body-->
            </section>
        </div>
        <!-- Kompetitor -->
        <div class="col-md-12">
            <section class="box-typical  kz-border-0 ">
                <header class="box-typical-header">
                    <div class="tbl-row">
                        <div class="tbl-cell tbl-cell-title">
                            <h3 style="font-size: 20px;">Kompetitor<br /></h3><small>Berdasarkan kemenangan pada instansi dan kategori yang sama</small>
                        </div>
                    </div>
                </header>
                <div class="table-responsive">
                    <table class="table table-hover table-striped">
                        <tbody>
                            @foreach ($tabel as $tabel_kompetitor)
                            <tr>
                                <td style="padding-left:15px" class="kz-link">
                                    <a href="{{url('profile?namaPerusahaan='.$tabel_kompetitor[0])}}">{{$tabel_kompetitor[0]}}</a>
                                </td>
                                <td class="text-right" style="padding-right:15px">
                                    {{$tabel_kompetitor[1]}} Menang
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
                <!--.box-typical-body-->
            </section>
        </div>

    </div>
</div>

{{-- <form id="form-search" method="GET" action="{{url('/analisa/pencarian')}}"> --}}
    <input type="hidden" id="tender" name="tender" value="{{$filter->tender}}">
    <input type="hidden" id="daterange" name="daterange" value="{{$filter->daterange}}">
</form>
@endsection

@section('scripts')
<script type="text/javascript" src="{{url('public/templates/default')}}/js/lib/moment/moment-with-locales.min.js">
</script>
<script type="text/javascript"
    src="{{url('public/templates/default')}}/js/lib/eonasdan-bootstrap-datetimepicker/bootstrap-datetimepicker.min.js">
</script>
<script src="{{url('public/templates/default')}}/js/lib/clockpicker/bootstrap-clockpicker.min.js"></script>
<script src="{{url('public/templates/default')}}/js/lib/clockpicker/bootstrap-clockpicker-init.js"></script>
<script src="{{url('public/templates/default')}}/js/lib/daterangepicker/daterangepicker.js"></script>
<script src="{{url('public/templates/default')}}/js/lib/bootstrap-select/bootstrap-select.min.js"></script>

<script src="{{url('public/templates/default')}}/js/lib/jqueryui/jquery-ui.min.js"></script>
<script src="https://cdn.anychart.com/js/v8/graphics.min.js"></script>

<script src="https://cdn.anychart.com/releases/v8/js/anychart-base.min.js?hcode=c11e6e3cfefb406e8ce8d99fa8368d33">
</script>
<script src="https://cdn.anychart.com/releases/v8/js/anychart-ui.min.js?hcode=c11e6e3cfefb406e8ce8d99fa8368d33">
</script>
<script src="https://cdn.anychart.com/releases/v8/js/anychart-exports.min.js?hcode=c11e6e3cfefb406e8ce8d99fa8368d33">
</script>
<script
    src="https://cdn.anychart.com/releases/v8/js/anychart-data-adapter.min.js?hcode=c11e6e3cfefb406e8ce8d99fa8368d33">
</script>


{{-- Ajax meureun --}}
<script>
    $(document).ready(function(){
        // loadChart1();
        // loadChart2();
        // loadCalendar();
    });
</script>

{{-- Chart 1 --}}
<script>
	anychart.onDocumentReady(function () {
	var dataSet = anychart.data.set(getData());
	var seriesData_1 = dataSet.mapAs({'x': 0, 'value': 1});
	var chart = anychart.line();
	var title = chart.title();
	title.text('Jumlah Tender per Bulan')
	.fontFamily('Proxima Nova')
	.enabled(true)
	.fontSize('24px');
	chart.animation(true);
	//chart.padding([10, 20, 5, 20]);
	chart.crosshair()
	    .enabled(true)
	    .yLabel(false)
	    .yStroke(null);
	chart.tooltip().positionMode('point');

	// chart.yAxis().title('Number of Bottles Sold (thousands)');
	chart.xAxis().labels().padding(5);

	var series_1 = chart.line(seriesData_1);
	series_1.name('jumlah');
	series_1.hovered().markers()
	    .enabled(true)
	    .type('circle')
	    .size(4);
	series_1.tooltip()
	    .position('right')
	    .anchor('left-center')
	    .offsetX(5)
	    .offsetY(5);

	chart.legend()
		.position('bottom')
	    .enabled(true)
	    .fontSize(13)
	    .padding([15, 0, 10, 0]);

	chart.container('chart_jumlah');

	chart.draw();
	});

	function getData() {
	var array = {!! json_encode($chart) !!};
	return array;
	}
</script>

{{-- Chart 2 --}}

<script>
        anychart.onDocumentReady(function () {
            // create stage
            var stage = anychart.graphics.create('chart');

            // The data used in this sample can be obtained from the CDN
            // https://cdn.anychart.com/anydata/bitcoin/result.json
            anychart.data.loadJsonFile('https://cdn.anychart.com/anydata/bitcoin/result.json', function (data) {
                // create column chart
                var chart = anychart.column();
                // set chart padding
                chart.padding([20, 0, 15, 20])
                        // set chart bounds
                        .bounds(0, 0, '100%', '100%');

                // set chart title text settings
                var chartTitle = chart.title();
                // chartTitle.enabled(true)
                //         .fontSize(15)
                //         .text('Peserta Pemenang Tender')
                //         .useHtml(true);
                chartTitle.padding().bottom(15);

                // create data set on our data
                var dataSet = anychart.data.set(data.lineChartData);

                // create ordinal scale
                var linearScale = anychart.scales.linear();
                linearScale.minimum(0);

                // create line series
                var lineSeries = chart.line(dataSet.mapAs({value: 'capitalization'}));
                // set series name
                lineSeries.name('Capitalization');
                lineSeries.markers(true)
                        .stroke('1.5 #60727b');
                // set line series labels settings
                lineSeries.labels().format('{%Value}');
                // set line series tooltip settings
                lineSeries.tooltip().format('Jumlah: {%Value}');

                // create column series
                var columnSeries = chart.column(dataSet.mapAs({value: 'dominance'}));
                // set series name
                columnSeries.name('Market Share')
                        .fill('#7bc0f7')
                        // set y-scale
                        .yScale(linearScale);
                // set column series tooltip settings
                columnSeries.tooltip().format('Market Share: {%Value}%');
                labels = columnSeries.labels();
                labels.enabled(true);
                labels.offsetY(-30);
                labels.fontColor('Black');

                // set settings for the first y-axis
                var firstYAxis = chart.yAxis(0);
                firstYAxis.title('').orientation('right');
                firstYAxis.labels().format('{%Value}{groupsSeparator:., decimalsCount:3}');

                // set settings for the second y-axis
                var secondYAxis = chart.yAxis(1);
                secondYAxis.scale(linearScale)
                        .orientation('left')
                //         .title('Market Share');
                secondYAxis.labels()
                        .format('{%Value}');

                // set chart tooltip settings
                chart.tooltip()
                        .displayMode('union')
                        // format title tooltip
                        .titleFormat(function () {
                            return this.x + ' ' + this.name.split('.')[0]
                        });

                // turn on legend
                chart.legend(false);

                // set hover mode
                chart.interactivity().hoverMode('by-x');

                // set container for the chart
                chart.container('chart_pemenang_tender');

                // initiate chart drawing
                chart.draw();

                // set output date format
                anychart.format.outputDateFormat('dd MMM yyyy');
            });
        });

        function getData() {
		var array = {!! json_encode($chart) !!};
		return array;
		}
</script>

{{-- Load Calendar --}}
<script>
    $('#search-daterange').daterangepicker({
        ranges: {
            'Hari Ini': [moment(), moment()],
            'Kemarin': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
            'Data 7 Hari': [moment().subtract(6, 'days'), moment()],
            'Data 30 Hari': [moment().subtract(29, 'days'), moment()],
            'Data Bulan Ini': [moment().startOf('month'), moment().endOf('month')],
            'Data Bulan Lalu': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        },
        widgetPositioning: {
            horizontal: 'left'
        },
        "linkedCalendars": true,
        "autoUpdateInput": true,
        "alwaysShowCalendars": false,
        "showWeekNumbers": true,
        "showDropdowns": true,
        "showISOWeekNumbers": true,
        debug: false,
        locale: {
            format: 'DD/MM/YYYY'
        }
    });

    $('#search-tender').keyup(function(e){
        if(e.keyCode == 13)
        {
            const searchTender = $(this).val();

            $('#tender').val(searchTender);
            $('#form-search').submit();
        }
    });

    $('#search-daterange').on('change', function(e){
        const searchDaterange = $(this).val();

        $('#daterange').val(searchDaterange);
        $('#form-search').submit();
    });
</script>

<script type="text/javascript">
var acc = document.getElementsByClassName("accordion");
var i;

for (i = 0; i < acc.length; i++) {
  acc[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var panel = this.nextElementSibling;
    if (panel.style.maxHeight) {
      panel.style.maxHeight = null;
    } else {
      panel.style.maxHeight = panel.scrollHeight + "px";
    }
  });
}
</script>

@endsection
