@extends('layouts.default')
@section('title', 'Analisa')

@section('page-css')
@endsection

@section('styles')

<link rel="stylesheet" href="{{url('public/')}}/css/analisa/analisa.css">
<style>
    h5{
        font-family: Proxima Nova,
        font-size: 24px;
        text-align: center;
        padding-left: 35%;
    }
    td{
        font-weight: bold;
    }
</style>
@endsection

@section('content')
<div class="container">
    <!-- Search Bar -->
    <div class="row">
        <div class="col-md-12">
            <div class="card" style="border-radius:50px;">
                <div class="card-block">
                    <div class="col-md-8 offset-md-2">
                        <div class="search">
                        <h2 style="text-align: center;">Analisa Tender</h2>
                            <div class="form-control-wrapper form-control-icon-left">
                                <input type="text" id="search-tender" class="form-control form-control-rounded" placeholder="Masukkan keyword tender disini" value="{{$filter->tender}}">
                                <span id="searchBtn" role="button" onclick="toggle()" class="fa fa-search"></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <input type="hidden" id="dtp_input2" value="/">
    </div>
    <!-- <div class="row">
        Top Tender 
        <div class="col-md-12">
            <section class="box-typical box-typical-max-280  kz-border-0 ">
                <header class="box-typical-header">
                    <div class="tbl-row">
                        <div class="tbl-cell tbl-cell-title">
                            <h3 style="font-size: 20px;">Tender Perusahaan Non Kecil**<br /></h3><small>Peserta terbanyak berdasarkan
                                    KBLI</small>
                        </div>
                    </div>
                </header>
                <div class="table-responsive">
                    <table class="table table-hover table-striped kz-border-0">
                        {{-- <tbody>
                            @foreach ($isi as $nama)
                            <tr>
                                <td style="padding-left:15px">
                                    {{$nama}}
                                </td>
                                <td class="text-right" style="padding-right:15px">
                                    42.536 Peserta
                                </td>
                            </tr>
                            @endforeach
                        </tbody> --}}
                    </table>
                </div>
                box-typical-body
            </section>
        </div>
         Kompetitor 
        <div class="col-md-12">
            <section class="box-typical  kz-border-0 ">
                <header class="box-typical-header">
                    <div class="tbl-row">
                        <div class="tbl-cell tbl-cell-title">
                            <h3 style="font-size: 20px;">Tender Perusahaan Kecil**<br /></h3><small>Peserta terbanyak berdasarkan KBLI</small>
                        </div>
                    </div>
                </header>
                <div class="table-responsive">
                    <table class="table table-hover table-striped">
                        {{-- <tbody>
                            @foreach ($isi1 as $nama)
                            <tr>
                                <td style="padding-left:15px">
                                    {{$nama}}
                                </td>
                                <td class="text-right" style="padding-right:15px">
                                    42.536 Peserta
                                </td>
                            </tr>
                            @endforeach
                        </tbody> --}}
                    </table>
                </div>
                box-typical-body
            </section>
        </div> -->
    </div>
</div>


<form id="form-search" method="GET" action="{{url('/analisa/pencarian')}}">
    <input type="hidden" id="tender" name="tender" value="{{$filter->tender}}">
    <input type="hidden" id="daterange" name="daterange" value="{{$filter->daterange}}">
</form>

@endsection

@section('scripts')
<script type="text/javascript" src="{{url('public/templates/default')}}/js/lib/moment/moment-with-locales.min.js">
</script>
<script type="text/javascript" src="{{url('public/templates/default')}}/js/lib/eonasdan-bootstrap-datetimepicker/bootstrap-datetimepicker.min.js"></script>
<script src="{{url('public/templates/default')}}/js/lib/clockpicker/bootstrap-clockpicker.min.js"></script>
<script src="{{url('public/templates/default')}}/js/lib/clockpicker/bootstrap-clockpicker-init.js"></script>
<script src="{{url('public/templates/default')}}/js/lib/daterangepicker/daterangepicker.js"></script>
<script src="{{url('public/templates/default')}}/js/lib/bootstrap-select/bootstrap-select.min.js"></script>

{{-- Toggle page --}}
<script>
$('#search-daterange').daterangepicker({
    ranges: {
        'Hari Ini': [moment(), moment()],
        'Kemarin': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
        'Data 7 Hari': [moment().subtract(6, 'days'), moment()],
        'Data 30 Hari': [moment().subtract(29, 'days'), moment()],
        'Data Bulan Ini': [moment().startOf('month'), moment().endOf('month')],
        'Data Bulan Lalu': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
    },
    widgetPositioning: {
        horizontal: 'left'
    },
    "linkedCalendars": true,
    "autoUpdateInput": true,
    "alwaysShowCalendars": false,
    "showWeekNumbers": true,
    "showDropdowns": true,
    "showISOWeekNumbers": true,
    debug: false,
    locale: {
        format: 'DD/MM/YYYY'
    }
});

$('#search-tender').keyup(function(e){
    if(e.keyCode == 13)
    {
        const searchTender = $(this).val();

        $('#tender').val(searchTender);
        $('#form-search').submit();
    }
});

$('#search-daterange').on('change', function(e){
    const searchDaterange = $(this).val();

    $('#daterange').val(searchDaterange);
    $('#form-search').submit();
});
</script>


@endsection
