@extends('layouts.default')
@section('title', 'Test Page')

@section('page-css')
@endsection

@section('styles')
@endsection

@section('content')

@endsection

@section('scripts') @endsection
